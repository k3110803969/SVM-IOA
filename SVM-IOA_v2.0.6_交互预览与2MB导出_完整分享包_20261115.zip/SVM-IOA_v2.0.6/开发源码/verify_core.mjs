// Optional developer check: node verify_core.mjs. No npm dependencies required.
import fs from 'node:fs';import vm from 'node:vm';import {fileURLToPath} from 'node:url';import path from 'node:path';import assert from 'node:assert/strict';
const root=path.dirname(fileURLToPath(import.meta.url)),ctx=vm.createContext({window:{},setTimeout,console});
for(const f of ['lib','ml','stats','engine'])vm.runInContext(fs.readFileSync(path.join(root,'web/js/'+f+'.js'),'utf8'),ctx);
const E=ctx.window.Engine;let x=[1,1];E.region([[0,0],[1,0],[0,1]],{region:'hull'}).project(x);assert(x[0]+x[1]<=1+1e-8);
x=[100,100];E.region([[2,2],[4,4]],{region:'box',total:5}).project(x);assert(Math.abs(x[0]+x[1]-5)<1e-8&&x.every(v=>v>=2&&v<=4));
assert.equal(E.wilcoxon([1,2,3,4,5]).p,.0625);
const model=ctx.window.ML.trainSVR([[0],[0],[1],[2],[3],[4]],[0,2,1,2,3,4],{C:5,gamma:.5,eps:.1,standardize:true});
assert(model.solver.converged);const restored=E.restore(E.pack(model));assert(Math.abs(restored.predict([1.5])-model.predict([1.5]))<1e-10);
const lhs=E.latinHypercube(24,3,0);for(let j=0;j<3;j++)assert.equal(new Set(lhs.map(r=>Math.floor(r[j]*24))).size,24);
console.log('v'+E.VERSION+': convex hull, original-unit total, Wilcoxon, duplicate-input SVR and model recovery checks passed.');
