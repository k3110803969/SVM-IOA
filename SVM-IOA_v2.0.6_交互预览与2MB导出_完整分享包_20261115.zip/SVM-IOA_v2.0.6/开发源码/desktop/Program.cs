using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
[assembly: AssemblyTitle("SVM-IOA 机器学习配比优化平台")]
[assembly: AssemblyProduct("SVM-IOA")]
[assembly: AssemblyDescription("SVR 建模与配比优化平台 2.0.6")]
[assembly: AssemblyVersion("2.0.6.0")]
[assembly: AssemblyFileVersion("2.0.6.0")]
[assembly: AssemblyInformationalVersion("2.0.6")]
internal static class Program {
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(IntPtr value);
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] static extern bool SetDllDirectory(string path);
  [STAThread] static void Main() {
    AppDomain.CurrentDomain.AssemblyResolve += Resolve;
    try {try{SetProcessDpiAwarenessContext(new IntPtr(-4));}catch{SetProcessDPIAware();} Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);string root=Extract();SetDllDirectory(root);Run(root);}
    catch(Exception ex){MessageBox.Show("启动失败："+ex.Message,"SVM-IOA v2.0.6",MessageBoxButtons.OK,MessageBoxIcon.Error);}
  }
  static Assembly Resolve(object sender, ResolveEventArgs e) {
    string name=new AssemblyName(e.Name).Name+".dll";
    if(name!="Microsoft.Web.WebView2.Core.dll"&&name!="Microsoft.Web.WebView2.WinForms.dll")return null;
    using(Stream s=Assembly.GetExecutingAssembly().GetManifestResourceStream(name)) {if(s==null)return null;using(var m=new MemoryStream()){s.CopyTo(m);return Assembly.Load(m.ToArray());}}
  }
  internal static string Extract() {
    string hash;using(var sha=SHA256.Create())using(var f=File.OpenRead(Assembly.GetExecutingAssembly().Location)){hash=BitConverter.ToString(sha.ComputeHash(f)).Replace("-","").Substring(0,16);}
    string root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"SVM-IOA","v2.0.6","runtime-"+hash);
    if(File.Exists(Path.Combine(root,".ready")))return root;
    Directory.CreateDirectory(root);var asm=Assembly.GetExecutingAssembly();
    foreach(string name in asm.GetManifestResourceNames()) {
      if(name.StartsWith("Microsoft.Web."))continue;
      string target=Path.GetFullPath(Path.Combine(root,name.Replace('/',Path.DirectorySeparatorChar)));
      if(!target.StartsWith(root+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))throw new IOException("无效资源路径");
      Directory.CreateDirectory(Path.GetDirectoryName(target));using(Stream s=asm.GetManifestResourceStream(name))using(var file=File.Create(target)){s.CopyTo(file);}
    }
    File.WriteAllText(Path.Combine(root,".ready"),"2.0.6");return root;
  }
  [MethodImpl(MethodImplOptions.NoInlining)] static void Run(string root) {Application.Run(new AppWindow(root));}
}
internal sealed class AppWindow:Form {
  readonly WebView2 web=new WebView2();readonly string root;bool ready=false,closing=false;
  internal AppWindow(string path){root=path;Icon=System.Drawing.Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location);Text="SVM-IOA 机器学习配比优化平台 v2.0.6";AutoScaleMode=AutoScaleMode.Dpi;Width=1380;Height=920;MinimumSize=new System.Drawing.Size(1000,700);StartPosition=FormStartPosition.CenterScreen;WindowState=FormWindowState.Maximized;web.Dock=DockStyle.Fill;Controls.Add(web);Load+=OnLoad;FormClosing+=OnClosing;}
  async void OnLoad(object sender,EventArgs e){
    try {
      string profile=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"SVM-IOA","v2.0.0","WebView2");
      var env=await CoreWebView2Environment.CreateAsync(null,profile,null);await web.EnsureCoreWebView2Async(env);
      web.CoreWebView2.Settings.IsStatusBarEnabled=false;web.CoreWebView2.Settings.AreDevToolsEnabled=false;
      web.CoreWebView2.SetVirtualHostNameToFolderMapping("svmioa.local",Path.Combine(root,"web"),CoreWebView2HostResourceAccessKind.DenyCors);
      web.CoreWebView2.DownloadStarting+=OnDownload;
      web.CoreWebView2.NewWindowRequested+=(s,a)=>{a.Handled=true;Uri u;if(Uri.TryCreate(a.Uri,UriKind.Absolute,out u)&&(u.Scheme=="https"||u.Scheme=="http")){if(u.Host=="svmioa.local")web.CoreWebView2.Navigate(u.AbsoluteUri);else Process.Start(new ProcessStartInfo(u.AbsoluteUri){UseShellExecute=true});}};
      web.CoreWebView2.NavigationCompleted+=(s,a)=>{ready=a.IsSuccess;if(!a.IsSuccess)MessageBox.Show(this,"页面加载失败："+a.WebErrorStatus+"。请重新打开程序。",Text);};
      web.CoreWebView2.Navigate("https://svmioa.local/index.html");
    }catch(Exception ex){MessageBox.Show(this,"无法启动内置浏览器。请确认已安装 Microsoft Edge WebView2 运行时。\n\n"+ex.Message+"\n\n官方安装地址：https://developer.microsoft.com/microsoft-edge/webview2/",Text,MessageBoxButtons.OK,MessageBoxIcon.Error);}
  }
  void OnDownload(object sender,CoreWebView2DownloadStartingEventArgs e){
    var def=e.GetDeferral();try{using(var dlg=new SaveFileDialog()){dlg.FileName=Path.GetFileName(e.ResultFilePath);dlg.Filter="所有文件|*.*";dlg.Title="保存导出文件";if(dlg.ShowDialog(this)==DialogResult.OK){e.ResultFilePath=dlg.FileName;e.Handled=true;}else e.Cancel=true;}}finally{def.Complete();}
  }
  async void OnClosing(object sender,FormClosingEventArgs e){if(closing||!ready)return;e.Cancel=true;try{await web.ExecuteScriptAsync("if(window.flushProject)window.flushProject();");}catch{}closing=true;Close();}
}
