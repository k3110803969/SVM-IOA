$ErrorActionPreference = 'Stop'
$sourceRoot = $PSScriptRoot
$compilerPath = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compilerPath)) { throw '需要 64 位 .NET Framework C# 编译器。' }
$outputRoot = Join-Path $sourceRoot 'dist'
New-Item -ItemType Directory -Path $outputRoot -Force | Out-Null
$compileArgs = @('/nologo', '/target:winexe', '/platform:x64', '/optimize+', '/codepage:65001', ('/out:' + (Join-Path $outputRoot 'SVM-IOA_v2.0.6.exe')))
foreach ($name in @('System.dll', 'System.Core.dll', 'System.Drawing.dll', 'System.Windows.Forms.dll')) { $compileArgs += '/reference:' + $name }
foreach ($name in @('Microsoft.Web.WebView2.Core.dll', 'Microsoft.Web.WebView2.WinForms.dll')) {
    $dependencyPath = Join-Path $sourceRoot ('desktop\deps\' + $name)
    $compileArgs += '/reference:' + $dependencyPath
    $compileArgs += '/resource:' + $dependencyPath + ',' + $name
}
$compileArgs += '/resource:' + (Join-Path $sourceRoot 'desktop\deps\WebView2Loader.dll') + ',WebView2Loader.dll'
$webRoot = Join-Path $sourceRoot 'web'
foreach ($resourceFile in (Get-ChildItem -LiteralPath $webRoot -File -Recurse | Sort-Object FullName)) {
    $resourceName = 'web/' + $resourceFile.FullName.Substring($webRoot.Length + 1).Replace('\', '/')
    $compileArgs += '/resource:' + $resourceFile.FullName + ',' + $resourceName
}
$compileArgs += '/win32icon:' + (Join-Path $sourceRoot 'desktop\app.ico')
$compileArgs += Join-Path $sourceRoot 'desktop\Program.cs'
& $compilerPath @compileArgs
if ($LASTEXITCODE -ne 0) { throw '编译失败。' }
Write-Host ('已生成：' + (Join-Path $outputRoot 'SVM-IOA_v2.0.6.exe'))
