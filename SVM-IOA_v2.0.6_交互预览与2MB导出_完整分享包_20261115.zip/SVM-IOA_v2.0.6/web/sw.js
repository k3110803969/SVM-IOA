// Service Worker：缓存应用外壳，使「添加到主屏幕」后可离线使用
const CACHE = 'svm-ioa-v2.0.6-20261115';
const ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './css/styles.css',
  './js/lib.js',
  './js/image-export.js',
  './js/interaction-export.js',
  './js/charts.js',
  './js/dataio.js',
  './js/ml.js',
  './js/stats.js',
  './js/engine.js',
  './js/upgrade.js',
  './js/mlflow.js',
  './js/trace-ui.js',
  './js/surface-read.js',
  './js/worker.js',
  './js/pdp.js',
  './js/app.js',
  './js/pwa.js',
  './icons/favicon-32.png',
  './icons/icon-180.png',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE).then(cache => cache.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  // 联网时优先取新文件（保证更新能生效），离线时回退到缓存
  event.respondWith(
    fetch(req).then(res => {
      const copy = res.clone();
      caches.open(CACHE).then(cache => cache.put(req, copy)).catch(() => {});
      return res;
    }).catch(() => caches.match(req).then(hit => hit || caches.match('./index.html')))
  );
});
