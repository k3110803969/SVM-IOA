/* Numeric reading of SVR surfaces. 3D selection explicitly snaps to a visible mesh node. */
const SurfaceRead=(()=>{
  let geometry=null,selected=null,source=null,base=null;
  function paint(canvas,g,p){if(!p)return;const ctx=canvas.getContext('2d'),dpr=canvas.width/g.w,[x,y]=g.project(p.x,p.y,p.value);ctx.save();ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.strokeStyle='#b95c00';ctx.lineWidth=1;ctx.setLineDash([4,4]);ctx.beginPath();ctx.moveTo(x-22,y);ctx.lineTo(x+22,y);ctx.moveTo(x,y-22);ctx.lineTo(x,y+22);ctx.stroke();ctx.setLineDash([]);ctx.beginPath();ctx.arc(x,y,7,0,Math.PI*2);ctx.fillStyle='#fff';ctx.fill();ctx.lineWidth=2.4;ctx.stroke();ctx.beginPath();ctx.arc(x,y,3,0,Math.PI*2);ctx.fillStyle='#d36a00';ctx.fill();
    ctx.font='12px "Microsoft YaHei",sans-serif';const label=(State.pdp?.mode==='pdp'?'PDP ':'SVR ')+fmt(p.value,2)+' '+(State.dataset?.unit||''),width=ctx.measureText(label).width+24,lx=Math.max(8,Math.min(g.w-width-8,x+12)),ly=y>42?y-31:y+13;ctx.fillStyle='#944800';ctx.fillRect(lx,ly,width,25);ctx.fillStyle='#fff';ctx.textAlign='left';ctx.textBaseline='middle';ctx.fillText(label,lx+8,ly+12);ctx.restore();
  }
  for(const key of ['pdp2d','surface3d']){const original=Charts[key];Charts[key]=function(canvas,o){const g=original(canvas,o);if(canvas.id==='chart-pdp2d'){geometry=g;base=document.createElement('canvas');base.width=canvas.width;base.height=canvas.height;base.getContext('2d').drawImage(canvas,0,0);}if(o.readMarker)paint(canvas,g,o.readMarker);return g;};}
  function reset(){selected=null;const c=$('#chart-pdp2d');if(c){delete c.dataset.readValue;delete c.dataset.readX;delete c.dataset.readY;}if(State.figureExport)delete State.figureExport.args.readMarker;}
  const originalInvalidate=invalidateAnalysis;invalidateAnalysis=function(){reset();source=null;geometry=null;base=null;originalInvalidate();if($('#surface-read-result'))$('#surface-read-result').textContent='数据或模型已更新，请重新计算曲面。';};
  function redrawMarker(){const canvas=$('#chart-pdp2d');if(!geometry||!base)return;const ctx=canvas.getContext('2d');ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(base,0,0);ctx.restore();if(selected)paint(canvas,geometry,selected);}
  function details(){if(!selected)return;const r=State.pdp,p=selected,canvas=$('#chart-pdp2d');canvas.dataset.readValue=String(p.value);canvas.dataset.readX=String(p.x);canvas.dataset.readY=String(p.y);
    const ft=ftEnsure(),data=getXY(),held=r.mode==='hold'?State.dataset.xIdx.map((_,i)=>i).filter(i=>i!==r.j&&i!==r.k).map(i=>ftName(i)+'='+fmt(ft.held[i],4)).join('，'):'其余因素按全部'+data.X.length+'条样本取平均';
    $('#surface-read-result').textContent=p.method+'：'+ftName(r.j)+'='+fmt(p.x,4)+'，'+ftName(r.k)+'='+fmt(p.y,4)+'；'+(held||'无其他因素')+'；'+(r.mode==='hold'?'SVR预测响应':'SVR平均预测响应（PDP）')+'='+fmt(p.value,4)+' '+(State.dataset.unit||'')+'。这是模型预测值，非实测值。';
    if(State.figureExport)State.figureExport.args.readMarker={x:p.x,y:p.y,value:p.value};redrawMarker();
  }
  function read(x,y,method){const r=State.pdp;if(!r||!State.model)throw Error('请先计算曲面');const xv=r.p2.xv,yv=r.p2.yv;
    if(!Number.isFinite(x)||!Number.isFinite(y)||x<xv[0]||x>xv.at(-1)||y<yv[0]||y>yv.at(-1))throw Error('请输入当前坐标轴范围内的有效数值');
    let value;if(r.mode==='hold'){const row=ftBaseRow(ftEnsure());row[r.j]=x;row[r.k]=y;value=State.model.predict(row);}else{const data=getXY();let sum=0;for(const row of data.X){const q=row.slice();q[r.j]=x;q[r.k]=y;sum+=State.model.predict(q);}value=sum/data.X.length;}
    if(!Number.isFinite(value))throw Error('预测值无效');selected={x,y,value,method};$('#surface-x').value=String(x);$('#surface-y').value=String(y);details();return selected;
  }
  const originalRender=renderPdp;renderPdp=function(){originalRender();const r=State.pdp;if(!r)return;
    if(source!==r){source=r;reset();$('#surface-x').value=String((r.p2.xv[0]+r.p2.xv.at(-1))/2);$('#surface-y').value=String((r.p2.yv[0]+r.p2.yv.at(-1))/2);$('#surface-read-result').textContent='输入两个轴的值查询，或点击图形读值。';}
    $('#surface-x-label').textContent=ftName(r.j);$('#surface-y-label').textContent=ftName(r.k);
    for(const[id,arr]of [['surface-x',r.p2.xv],['surface-y',r.p2.yv]]){$('#'+id).min=arr[0];$('#'+id).max=arr.at(-1);}
    $('#surface-read-help').textContent=(geometry?.kind==='3d'?'3D：点击曲面，选取所点面片最近的网格节点并高亮；精确配比请在下方输入。':'2D：点击等值线图内任意位置，读取该处SVR预测值；黑色线上的数字为等值线强度。')+' 图形不自动套用寻优的总量约束，单项范围内的组合也可能超出实测点凸包。';
    if(selected)details();
  };
  function triangle(p,a,b,c){const cross=(u,v,w)=>(u[0]-w[0])*(v[1]-w[1])-(v[0]-w[0])*(u[1]-w[1]),area=cross(a,b,c);if(Math.abs(area)<1e-8)return false;const u=cross(p,b,c)/area,v=cross(a,p,c)/area,w=1-u-v;return u>=-1e-7&&v>=-1e-7&&w>=-1e-7;}
  function pick(px,py){const g=geometry;if(!g)return null;if(g.kind==='contour')return g.unproject(px,py);const p=[px,py];
    // Reverse painter order means the foremost actually painted face wins.
    for(let i=g.faces.length-1;i>=0;i--){const f=g.faces[i],s=f.screen;if(triangle(p,s[0],s[1],s[2])||triangle(p,s[0],s[2],s[3])){let k=0,d=Infinity;for(let j=0;j<4;j++){const dd=(s[j][0]-px)**2+(s[j][1]-py)**2;if(dd<d){d=dd;k=j;}}return f.samples[k].slice(0,2);}}
    return null;
  }
  document.addEventListener('DOMContentLoaded',()=>{
    $('#surface-query').addEventListener('click',()=>{try{read(finiteCell($('#surface-x').value),finiteCell($('#surface-y').value),'输入精确查询');}catch(e){$('#surface-read-result').textContent=e.message;}});
    $('#surface-clear').addEventListener('click',()=>{reset();redrawMarker();$('#surface-read-result').textContent='已清除选点。输入两个轴的值查询，或点击图形读值。';});
    $('#chart-pdp2d').addEventListener('click',event=>{if(!State.pdp||!geometry)return;const c=event.currentTarget,b=c.getBoundingClientRect(),q=pick((event.clientX-b.left)*geometry.w/b.width,(event.clientY-b.top)*geometry.h/b.height);if(!q){$('#surface-read-result').textContent=selected?'本次未命中图形，保留原选点。请点击曲面或在下方输入精确配比。':'未命中图形。请点击曲面或等值线图内部。';return;}try{read(q[0],q[1],geometry.kind==='3d'?'3D网格节点读值':'2D坐标读值');}catch(e){$('#surface-read-result').textContent=e.message;}});
    for(const id of ['surface-x','surface-y'])$('#'+id).addEventListener('keydown',e=>{if(e.key==='Enter')$('#surface-query').click();});
  });
  return {read,pick};
})();
