// ---------- 界面逻辑 ----------
const sleep = ms => new Promise(r => setTimeout(r, ms));

const ALGO_DEF = {
  PSO: {
    title: 'PSO 参数',
    fields: [
      ['p-np', '种群规模 Np', 40], ['p-max', '最大迭代 Nmax', 60],
      ['p-c1', '学习因子 c1', 2], ['p-c2', '学习因子 c2', 2],
      ['p-wmax', '惯性权重 wmax', 0.9], ['p-wmin', '惯性权重 wmin', 0.4]
    ],
    desc: `
      <div class="pr-block"><h4>粒子群算法（PSO）</h4>
      <p>模拟鸟群觅食中的竞争与协作：每个粒子代表一组固化剂配比，具有位置 x 与速度 v。粒子依据自身历史最优 x<sub>p,best</sub> 与群体全局最优 x<sub>g,best</sub> 迭代更新速度与位置，
      并采用线性递减的惯性权重 w（由 w<sub>max</sub> 递减至 w<sub>min</sub>）平衡前期全局探索与后期局部收敛。</p></div>
      <div class="pr-block"><h4>更新公式</h4>
      <p>v<sub>j</sub><sup>i+1</sup> = w·v<sub>j</sub><sup>i</sup> + c<sub>1</sub>r<sub>1</sub>(x<sub>pj,best</sub> − x<sub>j</sub><sup>i</sup>) + c<sub>2</sub>r<sub>2</sub>(x<sub>gj,best</sub> − x<sub>j</sub><sup>i</sup>)<br>
      x<sub>j</sub><sup>i+1</sup> = x<sub>j</sub><sup>i</sup> + v<sub>j</sub><sup>i+1</sup>，其中 c<sub>1</sub>=c<sub>2</sub>=2，r<sub>1</sub>、r<sub>2</sub>∈[0,1]。</p></div>`
  },
  WSO: {
    title: 'WSO 参数',
    fields: [
      ['w-np', '种群规模 N', 25], ['w-max', '最大迭代 tmax', 70],
      ['w-pmin', '运动权重 pmin', 0.5], ['w-pmax', '运动权重 pmax', 2.5],
      ['w-a0', '随机运动基准 a0', 6], ['w-a1', '衰减因子 a1', 100], ['w-a2', '群体增长 a2', 0.0005]
    ],
    desc: `
      <div class="pr-block"><h4>白鲨优化算法（WSO）</h4>
      <p>模拟白鲨的随机游走探索、向最优猎物定向移动与群体协同捕食三种行为。速度按收缩因子 μ 与运动权重 p<sub>1</sub>、p<sub>2</sub> 更新，使个体在自身历史最优与全局最优之间平衡探索与开发。</p></div>
      <div class="pr-block"><h4>关键机制</h4>
      <p>v<sub>i</sub><sup>k+1</sup> = μ[v<sub>i</sub><sup>k</sup> + p<sub>1</sub>(u<sub>best,i</sub> − u<sub>i</sub><sup>k</sup>)c<sub>1</sub> + p<sub>2</sub>(g<sub>best</sub> − u<sub>i</sub><sup>k</sup>)c<sub>2</sub>]，μ 由 τ=4.125 确定；<br>
      p<sub>1</sub>、p<sub>2</sub> 随迭代呈指数衰减；随机运动概率 Mv = 1/(a<sub>0</sub>+e<sup>(t<sub>max</sub>/2−t)/a<sub>1</sub></sup>)，群体行为概率 Ss = |1 − e<sup>−a<sub>2</sub>t/t<sub>max</sub></sup>|。</p></div>`
  }
};

// ---------- 导航 ----------
function navigate(page) {
  let daTab = null;
  if (page === 'sig') { page = 'result'; daTab = 'sig'; }
  $$('.page').forEach(p => p.classList.toggle('active', p.id === 'page-' + page));
  $$('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.page === page));
  document.body.classList.toggle('pdp-wide', false);
  $('#main').scrollTop = 0;
  requestAnimationFrame(redrawCharts);
  // 进入可视化页且模型已就绪时，自动算一次，省得看到空图
  if (page === 'result' && State.model && !State.pdp) {
    renderFactorTool();
    recomputeSurface(false);
  }
  // 进入数据分析页时刷新方差分析表
  if (page === 'result' && typeof daGo === 'function') daGo(daTab || 'iter');
  const sr = document.getElementById('submenu-result');
  if (sr && page !== 'result') sr.classList.remove('open');
  // 进入显著性页且已有数据时，自动算一次
  if (page === 'sig' && State.dataset && !State.sig) renderSig();
}

function refreshChecklist() {
  $('#chk-data').classList.toggle('on', !!State.dataset);
  $('#chk-model').classList.toggle('on', !!State.model);
  $('#chk-updated').classList.toggle('on', !!State.result);
}

// ---------- 通知 ----------
function pushNotice(text) {
  const time = new Date().toLocaleString('zh-CN', { hour12: false });
  State.notices.unshift({ text, time, read: false });
  if (State.notices.length > 30) State.notices.length = 30;
  renderNotices();
}

function renderNotices() {
  const list = $('#notify-list');
  if (!list) return;
  list.innerHTML = State.notices.length
    ? State.notices.map(n => `<li>${n.text}<span class="t">${n.time}</span></li>`).join('')
    : '<li class="empty">暂无通知</li>';
  $('#notify-dot').style.display = State.notices.some(n => !n.read) ? '' : 'none';
}

function toggleNotices(force) {
  const panel = $('#notify-panel');
  const open = force === undefined ? !panel.classList.contains('open') : force;
  panel.classList.toggle('open', open);
  if (open) {
    State.notices.forEach(n => { n.read = true; });
    renderNotices();
  }
}

// ---------- 弹窗 ----------
function openModal(title, bodyHtml, footHtml) {
  $('#modal-title').textContent = title;
  $('#modal-body').innerHTML = bodyHtml;
  $('#modal-foot').innerHTML = footHtml || '';
  $('#mask').classList.add('open');
  document.body.classList.add('modal-open');
}

function closeModal() {
  $('#mask').classList.remove('open');
  document.body.classList.remove('modal-open');
}

function openHelp() {
  openModal('相关操作指引', `
    <ol class="help-list">
      <li><b>数据管理</b>：点击「数据导入」选择 .xlsx / .csv 文件，或点「载入示例数据」。表单里选择响应列与输入变量个数后点「确定」。</li>
      <li><b>模型设置</b>：设定 C、γ、ε，勾选网格搜索即可自动寻优；点「训练模型」查看 R²、RMSE 与预测对比图。</li>
      <li><b>算法选择</b>：切换 PSO / WSO，设置种群规模、迭代次数、目标函数与变量上下界。</li>
      <li><b>配比计算</b>：点「确定」开始寻优，进度与实时日志会同步刷新。</li>
      <li><b>数据分析</b>：迭代结果（带色标的收敛曲线）、方差分析与可视化分析。</li>
        <li><b>可视化分析</b>：在因子工具里选两个因子作为 X1 / X2 轴，其余因子用滑块固定，等值线图即时更新；也可「跳转至运行」查看某次试验、「表单…」精确录入取值，或改用偏依赖（PDP）看平均规律。图形支持导出 PNG 或 TIFF。</li>
    </ol>
    <p class="ops-text" style="padding-left:0;margin-top:12px">提示：在「设置」中填写随机种子后，计算结果可以完全复现。</p>
  `, `<button class="btn primary" id="modal-ok">知道了</button>`);
  $('#modal-ok').addEventListener('click', closeModal);
}

function openAbout() {
  const ds = State.dataset;
  openModal('关于本系统', `
    <div class="about-row"><span>系统名称</span><b>SVM-IOA 机器学习配比优化平台</b></div>
      <div class="about-row"><span>版本</span><b>v2.0.6</b></div>
    <div class="about-row"><span>预测模型</span><b>SVM（ε-SVR，RBF 核，SMO 求解）</b></div>
    <div class="about-row"><span>优化算法</span><b>PSO / WSO</b></div>
    <div class="about-row"><span>参数寻优</span><b>网格搜索 + 交叉验证</b></div>
    <div class="about-row"><span>当前样本</span><b>${ds ? ds.rows.length + ' 条' : '未导入'}</b></div>
      <div class="about-row"><span>可视化分析</span><b>因子工具（等值线 / 3D 曲面 / 偏依赖 PDP）</b></div>
      <div class="about-row"><span>运行方式</span><b>全部在本机计算，不联网</b></div>
  `, `<button class="btn primary" id="modal-ok">知道了</button>`);
  $('#modal-ok').addEventListener('click', closeModal);
}

// ---------- 设置 ----------
function openSettings() {
  const s = State.settings;
  openModal('设置', `
    <label class="field"><span>随机种子</span>
      <input type="text" id="set-seed" placeholder="留空 = 每次随机" value="${s.seed ?? ''}"></label>
    <p class="modal-note">填写整数后，网格搜索、PSO、WSO 的结果可完全复现。</p>
    <label class="field"><span>结果小数位</span>
      <select id="set-decimals">
        ${[1, 2, 3, 4].map(n => `<option value="${n}"${n === s.decimals ? ' selected' : ''}>${n} 位</option>`).join('')}
      </select></label>
    <label class="field"><span>导出文件名</span>
      <input type="text" id="set-prefix" value="${s.exportPrefix}"></label>
    <p class="modal-note">例如 ${s.exportPrefix || 'svm-ioa'}-result.csv。</p>
    <label class="field check"><input type="checkbox" id="set-anim"${s.animation ? ' checked' : ''}><span>计算时播放进度动画</span></label>
  `, `
    <button class="btn" id="set-reset">恢复默认</button>
    <button class="btn" id="set-cancel">取消</button>
    <button class="btn primary" id="set-save">保存</button>
  `);
  $('#set-cancel').addEventListener('click', closeModal);
  $('#set-reset').addEventListener('click', () => {
    State.settings = { seed: null, decimals: 2, exportPrefix: 'svm-ioa', animation: true };
    setSeed(null); refreshNumbers(); openSettings();
    toast('已恢复默认设置');
  });
  $('#set-save').addEventListener('click', () => {
    const seed = setSeed($('#set-seed').value.trim());
    State.settings.decimals = parseInt($('#set-decimals').value, 10) || 2;
    State.settings.exportPrefix = ($('#set-prefix').value.trim() || 'svm-ioa');
    State.settings.animation = $('#set-anim').checked;
    refreshNumbers();
    closeModal();
    pushNotice('系统设置已更新');
    toast(seed ? `设置已保存，随机种子 = ${seed}` : '设置已保存');
  });
}

function refreshNumbers() {
  if (State.model) {
    $('#tr-C').textContent = fmt(State.model.C, 4);
    $('#tr-gamma').textContent = fmt(State.model.gamma, 4);
    $('#tr-r2').textContent = fmt(State.model.r2, 4);
    $('#tr-rmse').textContent = fmt(State.model.rmse);
    $('#tr-sv').textContent = State.model.sv + ' / ' + State.model.n;
    $('#ov-r2').textContent = fmt(State.model.r2, 4);
  }
  if (State.result) renderResult();
}

// ---------- 方案信息 ----------
function renderPlan() {
  const m = State.meta, ds = State.dataset;
  const parts = [
    `方案：<b>${escHtml(String(m.name || ''))}</b>`,
    `类型 <b>${escHtml(String(m.type || ''))}</b>`,
    `龄期 <b>${escHtml(String(m.age || '7 d'))}</b>`,
    `地区 <b>${escHtml(String(m.region || '-'))}</b>`,
    `强度单位 <b>${escHtml(String(m.unit || ''))}</b>`,
    `制作内容 <b>${escHtml(String(m.content || '最优配比计算'))}</b>`
  ];
  if (ds) parts.push(`样本 <b>${ds.rows.length}</b> 条`, `输入变量 <b>${ds.xIdx.length}</b> 个`);
  $('#plan-summary').innerHTML = parts.join(' · ');
}

function applyVarCount(n) {
  const ds = State.dataset;
  if (!ds || !ds.numericIdx) return;
  const ignored = (ds.roles || []).map((r, i) => (r === 'ignore' ? i : -1)).filter(i => i >= 0);
  const pool = ds.numericIdx.filter(i => i !== ds.yIdx && !ignored.includes(i));
  ds.xIdx = pool.slice(0, Math.max(1, Math.min(n, pool.length)));
}

// ---------- 数据管理 ----------
function setDataset(ds) {
  State.dataset = ds;
  State.model = null;
  State.pdp = null;
  State.sig = null;
  State.sigPerm = null;
  State.sigCoding = null;
  if ($('#sig-coding-table')) $('#sig-coding-table').innerHTML = '';
  $('#ov-samples').textContent = ds.rows.length;
  $('#ov-vars').textContent = ds.xIdx.length;
  $('#ov-r2').textContent = '--';
  $('#ov-model').textContent = '未训练';
  if ($('#f-file')) $('#f-file').value = ds.name + '.csv';
  if ($('#f-name')) $('#f-name').value = ds.name;
  // 方案名跟随数据名（导入时即文件名），避免顶部方案栏停留在默认值
  State.meta = Object.assign({}, State.meta, { name: ds.name });
  ds.name = ds.name;
  if ($('#home-plan')) $('#home-plan').textContent = '当前方案：' + ds.name + '（' + ds.rows.length + ' 条）';
  renderDataTable();
  if (typeof autoFillBounds === 'function') autoFillBounds(ds);
  refreshChecklist();
  if (typeof renderRoles === 'function') renderRoles();
  if (typeof renderPlan === 'function') renderPlan();
  if (typeof renderFactorTool === 'function') renderFactorTool();
}

function renderDataTable() {
  const ds = State.dataset, table = $('#data-table');
  if (!ds) { table.innerHTML = ''; $('#data-count').textContent = '共 0 条'; return; }
  const head = ds.headers.map((h, i) => {
    let role = '';
    if (i === ds.yIdx) role = '<span class="role y">响应</span>';
    else if (ds.xIdx.includes(i)) role = '<span class="role x">输入</span>';
    return `<th>${h}${role}</th>`;
  }).join('');
  const body = ds.rows.slice(0, 200).map(r =>
    '<tr>' + ds.headers.map((_, i) => `<td>${r[i] ?? ''}</td>`).join('') + '</tr>'
  ).join('');
  table.innerHTML = `<thead><tr>${head}</tr></thead><tbody>${body}</tbody>`;
  $('#data-count').textContent = `共 ${ds.rows.length} 条`;
}

// 判断某列是否是"序号 / 编号"这类无信息列：
// 名称像 Run/No./ID/序号，或取值恰好是 1,2,3,… 的连续整数
function isIndexLikeColumn(header, vals, position) {
  const h = String(header == null ? '' : header).trim();
  if (/^(run|no\.?|num|id|index|sample|序号|编号|试验号|试样号|组号|序号列)$/i.test(h)) return true;
  // 没有名字线索时，只把"第一列且恰好是 1,2,3,… 连续整数"当作序号，
  // 避免把恰好取 1,2,3… 的真实因子（如温度梯度）误判
  if (position !== 0 || vals.length < 3) return false;
  let prev = null;
  for (const v of vals) {
    if (!isFinite(v) || Math.abs(v - Math.round(v)) > 1e-9) return false;
    if (prev !== null && v !== prev + 1) return false;
    prev = v;
  }
  return vals[0] === 1;
}

// 自动识别列角色：响应列优先看名称关键词，其次取最后一个非序号数值列
function detectRoles(headers, rows) {
  const n = headers.length;
  const cols = headers.map((_, i) => rows.map(r => finiteCell(r[i])));
  const numeric = cols.map(v => v.filter(x => isFinite(x)).length >= rows.length * 0.6);
  const idxLike = cols.map((v, i) => numeric[i] && isIndexLikeColumn(headers[i], v.filter(x => isFinite(x)), i));
  const constant = cols.map(v => {
    const f = v.filter(x => isFinite(x));
    return f.length > 0 && Math.max(...f) === Math.min(...f);
  });

  let yIdx = -1;
  for (let i = 0; i < n; i++) {
    if (numeric[i] && !idxLike[i] && /qu|ucs|strength|强度|response|target|result|响应/i.test(String(headers[i]))) { yIdx = i; break; }
  }
  if (yIdx < 0) { for (let i = n - 1; i >= 0; i--) if (numeric[i] && !idxLike[i]) { yIdx = i; break; } }
  if (yIdx < 0) { for (let i = n - 1; i >= 0; i--) if (numeric[i]) { yIdx = i; break; } }

  const roles = headers.map((h, i) => {
    if (!numeric[i]) return 'ignore';
    if (i === yIdx) return 'y';
    if (idxLike[i] || constant[i]) return 'ignore';
    return 'x';
  });
  // 兜底：如果一个输入都没剩下，就把除响应外的数值列都当输入
  if (!roles.includes('x')) {
    for (let i = 0; i < n; i++) if (numeric[i] && i !== yIdx) roles[i] = 'x';
  }
  const xIdx = roles.map((r, i) => (r === 'x' ? i : -1)).filter(i => i >= 0);
  const numericIdx = numeric.map((ok, i) => (ok ? i : -1)).filter(i => i >= 0);
  return { roles, xIdx, yIdx, numericIdx };
}

function autoDataset(grid, name) {
  const headers = grid[0].map((h, i) => String(h || `列${i + 1}`));
  const rows = grid.slice(1);
  const det = detectRoles(headers, rows);
  return { headers, rows, xIdx: det.xIdx, yIdx: det.yIdx, numericIdx: det.numericIdx, roles: det.roles, name: name || '导入数据', unit: 'kPa' };
}

// ---------- 列角色编辑 ----------
function renderRoles() {
  const ds = State.dataset, t = $('#role-table');
  if (!t) return;
  if (!ds) { t.innerHTML = ''; return; }
  const roles = ds.roles || ds.headers.map((_, i) => (i === ds.yIdx ? 'y' : (ds.xIdx.includes(i) ? 'x' : 'ignore')));
  const head = '<thead><tr><th>列名</th><th>角色</th><th>识别</th></tr></thead>';
  const body = ds.headers.map((h, i) => {
    const isNum = (ds.numericIdx || []).includes(i);
    const sel = `<select class="role-sel" data-i="${i}"${isNum ? '' : ' disabled'}>
        <option value="x"${roles[i] === 'x' ? ' selected' : ''}>输入因子</option>
        <option value="y"${roles[i] === 'y' ? ' selected' : ''}>响应</option>
        <option value="ignore"${roles[i] === 'ignore' ? ' selected' : ''}>忽略</option>
      </select>`;
    return `<tr><td>${escHtml(h)}</td><td>${sel}</td><td class="muted">${isNum ? '数值列' : '文本列（自动忽略）'}</td></tr>`;
  }).join('');
  t.innerHTML = head + '<tbody>' + body + '</tbody>';
}

function applyRoles() {
  const ds = State.dataset;
  if (!ds) { toast('请先导入数据'); return; }
  const sels = $$('#role-table select.role-sel');
  if (!sels.length) { toast('没有可设置的列'); return; }
  const roles = ds.headers.map(() => 'ignore');
  sels.forEach(s => { roles[Number(s.dataset.i)] = s.value; });
  const yCount = roles.filter(r => r === 'y').length;
  if (yCount !== 1) { toast('必须且只能有一列设为「响应」'); return; }
  const xIdx = roles.map((r, i) => (r === 'x' ? i : -1)).filter(i => i >= 0);
  if (!xIdx.length) { toast('至少需要一个输入因子'); return; }
  ds.roles = roles;
  ds.xIdx = xIdx;
  ds.yIdx = roles.indexOf('y');
  State.model = null; State.pdp = null; State.sig = null; State.sigPerm = null; State.sigCoding = null;
  $('#ov-vars').textContent = ds.xIdx.length;
  $('#ov-r2').textContent = '--';
  $('#ov-model').textContent = '未训练';
  renderDataTable();
  renderRoles();
  refreshChecklist();
  if (typeof renderPlan === 'function') renderPlan();
  if (typeof renderFactorTool === 'function') renderFactorTool();
  toast(`列角色已更新：${xIdx.length} 个输入 + 1 个响应`);
}

function bindRoles() {
  const btn = $('#role-apply');
  if (btn) btn.addEventListener('click', applyRoles);
  const reset = $('#role-reset');
  if (reset) reset.addEventListener('click', () => {
    const ds = State.dataset;
    if (!ds) { toast('请先导入数据'); return; }
    const det = detectRoles(ds.headers, ds.rows);
    ds.roles = det.roles; ds.xIdx = det.xIdx; ds.yIdx = det.yIdx;
    State.model = null; State.sig = null; State.sigCoding = null; State.sigPerm = null;
    $('#ov-vars').textContent = ds.xIdx.length;
    renderDataTable(); renderRoles(); refreshChecklist();
    toast('已恢复自动识别');
  });
}

async function handleFile(file) {
  try {
    const grid = await DataIO.readFile(file);
    if (grid.length < 3) throw new Error('数据行数过少');
    setDataset(autoDataset(grid, file.name.replace(/\.(csv|xlsx)$/i, '')));
    if (typeof dwGo === 'function') dwGo(4);
    renderPlan();
    pushNotice(`数据导入成功：${file.name}（${State.dataset.rows.length} 条）`);
    toast('数据导入成功，共 ' + State.dataset.rows.length + ' 条');
    navigate('data');
  } catch (e) { toast('导入失败：' + e.message, 3200); }
}

// ---------- 模型设置 ----------
function getXY() {
  const ds = State.dataset;
  if (!ds) return null;
  const X = [], y = [];
  ds.rows.forEach(r => {
    const xv = ds.xIdx.map(i => parseFloat(r[i]));
    const yv = parseFloat(r[ds.yIdx]);
    if (xv.every(isFinite) && isFinite(yv)) { X.push(xv); y.push(yv); }
  });
  return { X, y };
}

async function trainModel() {
  const d = getXY();
  if (!d || d.X.length < 4) { toast('请先导入足够的数据（≥4 条）'); return null; }
  const { X, y } = d;
  const eps = parseFloat($('#m-eps').value) || 0.0001;
  const stdOn = $('#m-standard').checked;
  let C = parseFloat($('#m-C').value), gamma = parseFloat($('#m-gamma').value);

  if ($('#m-grid').checked) {
    const CList = $('#m-gridC').value.split(',').map(Number).filter(isFinite);
    const GList = $('#m-gridG').value.split(',').map(Number).filter(isFinite);
    const folds = parseInt($('#m-cv').value, 10) || 5;
    const g = ML.gridSearchCV(X, y, { CList, GList, eps, folds, standardize: stdOn });
    C = g.C; gamma = g.gamma;
    $('#m-C').value = C; $('#m-gamma').value = gamma;
  }

  const split = parseFloat($('#m-split').value);
  const n = X.length;
  const order = shuffleIdx(n);
  const nTrain = split >= 1 ? n : Math.max(3, Math.round(n * split));
  const trIdx = order.slice(0, nTrain), teIdx = order.slice(nTrain);

  const model = ML.trainSVR(trIdx.map(i => X[i]), trIdx.map(i => y[i]),
    { C, gamma, eps, standardize: stdOn });

  const actual = [], pred = [];
  const trPred = trIdx.map(i => model.predict(X[i]));
  const tePred = teIdx.map(i => model.predict(X[i]));
  trIdx.forEach(i => actual.push(y[i]));
  teIdx.forEach(i => actual.push(y[i]));
  pred.push(...trPred, ...tePred);

  State.model = {
    ...model, C, gamma, eps,
    r2: ML.r2(actual, pred), rmse: ML.rmse(actual, pred),
    sv: model.svIdx.length, points: { actual, pred, trainCount: trIdx.length }
  };

  $('#tr-C').textContent = fmt(C, 4);
  $('#tr-gamma').textContent = fmt(gamma, 4);
  $('#tr-r2').textContent = fmt(State.model.r2, 4);
  $('#tr-rmse').textContent = fmt(State.model.rmse, 2);
  $('#tr-sv').textContent = State.model.sv + ' / ' + n;
  $('#ov-r2').textContent = fmt(State.model.r2, 4);
  $('#ov-model').textContent = '已训练';

  Charts.parity($('#chart-train'), {
    actual: State.model.points.actual, pred: State.model.points.pred,
    trainCount: State.model.points.trainCount, xLabel: '实测值', yLabel: '预测值'
  });
  State.pdp = null;
  renderFactorTool();
  refreshChecklist();
  toast(`模型训练完成：C=${fmt(C, 4)}, γ=${fmt(gamma, 4)}, R²=${fmt(State.model.r2, 4)}`);
  return State.model;
}

// ---------- 算法选择 ----------
function renderAlgo() {
  const a = ALGO_DEF[State.algo];
  $('#algo-title').textContent = a.title;
  const saved = State.algoParams || {};
  $('#algo-params').innerHTML = a.fields.map(([id, label, def]) =>
    `<label class="field"><span>${label}</span><input type="number" step="any" id="${id}" value="${saved[id] ?? def}"></label>`
  ).join('');
  $('#algo-desc').innerHTML = a.desc;
  $$('.algo-tab').forEach(t => t.classList.toggle('active', t.dataset.algo === State.algo));
}

function collectAlgoParams() {
  const p = {};
  ALGO_DEF[State.algo].fields.forEach(([id]) => {
    const el = $('#' + id); if (el) p[id] = parseFloat(el.value);
  });
  State.algoParams = p;
  return p;
}

// ---------- 配比计算 ----------
function setRing(pct) {
  const circ = 2 * Math.PI * 66;
  $('#ring-fg').style.strokeDashoffset = String(circ * (1 - pct / 100));
  $('#ring-pct').textContent = Math.round(pct) + '%';
}

function pushLogLine(text) {
  const el = $('#log-stream');
  el.classList.add('show');
  el.textContent += (el.textContent ? '\n' : '') + text;
  el.scrollTop = el.scrollHeight;
}

function addLogRow(dateStr) {
  const body = $('#log-body');
  if (!body) return;
  const empty = body.querySelector('.log-empty');
  if (empty) empty.remove();
  const plan = (State.meta && State.meta.name) || '—';
  const db = (State.dataset && State.dataset.name) || '—';
  const region = (State.meta && State.meta.region) || '—';
  const tr = document.createElement('tr');
  tr.innerHTML = `<td class="ch"><input type="checkbox"></td><td>${escHtml(plan)}</td><td>${dateStr}</td>
    <td>${escHtml(db)}</td><td>已完成</td>
    <td class="log-acts"><button class="mini" data-act="res">结果</button><button class="mini" data-act="txt">文本</button><button class="mini" data-act="img">图像</button></td>`;
  body.prepend(tr);
  tr.querySelectorAll('.mini').forEach(b => b.addEventListener('click', () => {
    const act = b.dataset.act;
    if (act === 'res') { navigate('result'); return; }
    if (act === 'txt') {
      const txt = ($('#log-stream') && $('#log-stream').innerText) || '';
      if (!txt.trim()) { toast('本次运行暂无日志文本'); return; }
      download(`run-log-${dateStr.replace(/\./g, '')}.txt`, txt);
      toast('日志已导出');
      return;
    }
    if (act === 'img') { navigate('result'); const v = document.getElementById('dap-viz'); if (v) v.scrollIntoView({ block: 'start' }); toast('已定位到可视化分析模块'); }
  }));
}

function renderLogEmpty() {
  const body = $('#log-body');
  if (!body || body.children.length) return;
  body.innerHTML = '<tr class="log-empty"><td colspan="6" style="color:#9aa6b8;text-align:center;padding:14px">暂无记录 —— 完成一次「配比计算」后会自动记录在此</td></tr>';
}

async function runCompute() {
  const btn = $('#btn-run'); btn.disabled = true; btn.textContent = '计算中';
  try {
    if (!State.model) { await trainModel(); if (!State.model) { toast('请先导入数据并训练模型'); return; } }
    if (!State.dataset) { toast('请先导入数据'); return; }

    const p = collectAlgoParams();
    const dim = State.dataset.xIdx.length;
    const lb = $('#o-lb').value.split(',').map(Number).filter(isFinite);
    const ub = $('#o-ub').value.split(',').map(Number).filter(isFinite);
    while (lb.length < dim) lb.push(0);
    while (ub.length < dim) ub.push(12);
    // 外推检查：搜索范围是否超出试验数据范围
    const dmin = [], dmax = [];
    if (State.dataset && State.dataset.xIdx) {
      for (let j = 0; j < dim; j++) {
        const col = State.dataset.rows.map(r => parseFloat(r[State.dataset.xIdx[j]])).filter(isFinite);
        dmin.push(col.length ? Math.min(...col) : NaN);
        dmax.push(col.length ? Math.max(...col) : NaN);
      }
    }
    const extrap = dmin.some((v, j) => isFinite(v) && (lb[j] < v - 1e-9 || ub[j] > dmax[j] + 1e-9));
    const target = $('#o-target').value.includes('最大') ? 1 : -1;
    const constraint = $('#o-constraint').value;
    const region = (document.getElementById('o-region') || {}).value || 'box';
    let project = null;
    if (constraint.includes('归一化')) {
      project = x => { const s = x.reduce((a, b) => a + b, 0) || 1; for (let i = 0; i < x.length; i++) x[i] = x[i] / s; };
    } else if (region === 'sphere') {
      const c = lb.map((v, j) => (v + ub[j]) / 2);
      const h = lb.map((v, j) => ((ub[j] - v) / 2) || 1);
      let R = 0;
      if (State.dataset) {
        State.dataset.rows.forEach(row => {
          let s = 0;
          for (let j = 0; j < dim; j++) {
            const z = (parseFloat(row[State.dataset.xIdx[j]]) - c[j]) / h[j];
            s += z * z;
          }
          if (isFinite(s)) R = Math.max(R, Math.sqrt(s));
        });
      }
      if (!isFinite(R) || R <= 0) R = 1;
      project = x => {
        let s = 0;
        for (let j = 0; j < dim; j++) { const z = (x[j] - c[j]) / h[j]; s += z * z; }
        const rr = Math.sqrt(s);
        if (rr > R) { const k = R / rr; for (let j = 0; j < dim; j++) x[j] = c[j] + (x[j] - c[j]) * k; }
      };
      pushLogLine('>> 寻优范围：设计球（半径 ' + fmt(R, 3) + ' 倍半区间），避免球外外推');
    }
    const objective = x => target * State.model.predict(x);

    $('#log-stream').textContent = '';
    pushLogLine('>> 开始计算 ...');
    pushLogLine('>> 算法: ' + State.algo + '    目标: ' + $('#o-target').value);
    if (extrap) pushLogLine('>> 注意：搜索范围超出试验数据范围（' + dmin.map((v,i)=>v+'–'+dmax[i]).join('; ') + '），结果属于外推，请谨慎使用');
    pushLogLine('>> 已载入 SVM 预测模型 (C=' + fmt(State.model.C, 4) + ', γ=' + fmt(State.model.gamma, 4) + ')');

    const history = [];
    const t0 = performance.now();
    let res;
    if (State.algo === 'PSO') {
      res = ML.runPSO({
        lb, ub, np: p['p-np'] || 40, maxIter: p['p-max'] || 60,
        c1: p['p-c1'] || 2, c2: p['p-c2'] || 2,
        wMax: p['p-wmax'] ?? 0.9, wMin: p['p-wmin'] ?? 0.4,
        objective, project,
        onIter: (it, max, f) => history.push({ it, max, f })
      });
    } else {
      res = ML.runWSO({
        lb, ub, np: p['w-np'] || 25, maxIter: p['w-max'] || 70,
        objective, project,
        onIter: (it, max, f) => history.push({ it, max, f })
      });
    }
    const elapsed = ((performance.now() - t0) / 1000).toFixed(3);

    // 进度回放（可在「设置」中关闭动画）
    const total = history.length || 1;
    // 逐代打印（代太多时按 2~5 代一行），并标记“首次达到最优”的代数
    const logEvery = Math.max(1, Math.ceil(total / 120));
    const bestF = history.length ? history[total - 1].f : 0;
    let convergedAt = -1;
    for (let i = 0; i < total; i++) {
      if (Math.abs(history[i].f - bestF) <= Math.abs(bestF) * 1e-9 + 1e-9) { convergedAt = history[i].it; break; }
    }
    const stepMs = Math.max(12, Math.min(38, 1800 / total));
    for (let i = 0; i < total; i++) {
      const pct = (i + 1) / total * 100;
      if (State.settings.animation) {
        setRing(pct);
        $('#st-data').textContent = fmt(96.73 * pct / 100, 2) + '%';
        $('#st-text').textContent = fmt(44.27 * pct / 100, 2) + '%';
        $('#st-img').textContent = fmt(24.98 * pct / 100, 2) + '%';
        $('#st-ana').textContent = fmt(24.98 * pct / 100, 2) + '%';
      }
      if (i % logEvery === 0 || i === total - 1) {
        const tag = (history[i].it === convergedAt) ? '   ← 已达最终最优' : '';
        pushLogLine(`>> 迭代 ${history[i].it}/${history[i].max}  q_u = ${fmt(target * history[i].f)} kPa${tag}`);
      }
      if (State.settings.animation) await sleep(stepMs);
    }
    setRing(100);
    $('#st-data').textContent = '96.73%';
    $('#st-text').textContent = '44.27%';
    $('#st-img').textContent = '24.98%';
    $('#st-ana').textContent = '24.98%';

    const bestX = res.best.slice();
    const bestY = target * res.fitness;
    State.result = {
      algo: State.algo, bestX, bestY,
      history: res.history, elapsed,
      iter: total, params: p,
      headers: State.dataset.headers.slice(),
      xIdx: State.dataset.xIdx.slice(), unit: State.dataset.unit
    };
    const bestDesc = (State.result && State.result.bestX)
      ? State.dataset.xIdx.map((ci, t) => (State.dataset.headers[ci] || ('X' + (t + 1))) + '=' + fmt(State.result.bestX[t], 3)).join('，')
      : '';
    pushLogLine(`>> 完成：最优 q_u = ${fmt(bestY, 2)} kPa（${bestDesc}），用时 ${elapsed} s`);
    pushLogLine('>> 说明：适应度来自 SVR 模型预测，计算很快；若迭代很早就走平，说明已收敛，可适当减小迭代次数。');
    if (dmin.length && bestX.some((v, j) => isFinite(dmin[j]) && (v < dmin[j] - 1e-9 || v > dmax[j] + 1e-9))) {
      pushLogLine('>> 警告：最优配比超出试验数据范围（' + dmin.map((v, i) => v + '–' + dmax[i]).join('; ') + '），属外推结果，需做验证试验');
    }
    if (State.meta.store === '否') {
      pushLogLine('>> 数据入库：否（本次结果未写入日志列表）');
    } else {
      addLogRow(new Date().toISOString().slice(0, 10).replace(/-/g, '.'));
    }
    renderResult();
    refreshChecklist();
    pushNotice(`${State.algo} 计算完成：最优 q_u = ${fmt(bestY)} ${State.dataset.unit}`);
    toast('计算完成，最优 q_u = ' + fmt(bestY, 2) + ' kPa');
    navigate('result');
  } finally {
    btn.disabled = false; btn.textContent = '确定';
  }
}

// ---------- 结果展示 ----------
function renderResult() {
  const r = State.result;
  if (!r) return;
  // 「输出设置」为“仅最优配比”时只显示数值，不显示图表
  const onlyBest = String(State.meta.out || '').indexOf('仅') === 0 || String(State.meta.out || '').includes('仅最优');
  const rc = $('#result-charts'); if (rc) rc.style.display = onlyBest ? 'none' : '';
  const names = r.xIdx.map(i => r.headers[i]);
  const sum = r.bestX.reduce((a, b) => a + b, 0);
  $('#result-summary').innerHTML = `
    <p class="res-title">最优配比计算结果</p>
    <div class="res-row"><span>试验方案</span><b>${State.meta.name}</b></div>
    <div class="res-row"><span>养护龄期</span><b>${State.meta.age || '7 d'}</b></div>
    <div class="res-row"><span>优化算法</span><b>${r.algo}</b></div>
    <div class="res-row"><span>迭代次数</span><b>${r.iter}</b></div>
    <div class="res-row"><span>计算用时</span><b>${r.elapsed} s</b></div>
    <div class="res-row"><span>最优抗压强度 q<sub>u,max</sub></span><b>${fmt(r.bestY, 2)} ${r.unit}</b></div>
    ${names.map((nm, i) => `<div class="res-row"><span>${nm}</span><b>${fmt(r.bestX[i], 3)}</b></div>`).join('')}
    <div class="res-row"><span>各组分掺入比之和</span><b>${fmt(sum, 3)}</b></div>`;

  drawIterChart(r.history, r.algo, r.bestY);
  $('#cap-line').textContent = '适应度迭代曲线（' + r.algo + '，共 ' + r.history.length + ' 代）';
  if ($('#chart-bar')) {
    Charts.bars($('#chart-bar'), {
      labels: names.map((n, i) => 'w' + (i + 1)),
      values: r.bestX
    });
    if ($('#cap-bar')) $('#cap-bar').textContent = '最优配比（各组分掺入比）';
  }
}

function redrawCharts() {
  if (State.model && $('#page-model').classList.contains('active')) {
    const p = State.model.points;
    Charts.parity($('#chart-train'), {
      actual: p.actual, pred: p.pred, trainCount: p.trainCount,
      xLabel: '实测值', yLabel: '预测值'
    });
  }
  if (State.result && $('#page-result').classList.contains('active')) renderResult();
  const pdpPage = $('#page-pdp'); if (State.pdp && pdpPage && pdpPage.classList.contains('active')) renderPdp();
  const sigPage = $('#page-sig');
  if (State.sig && sigPage && sigPage.classList.contains('active')) {
    drawPareto($('#chart-pareto'), State.sig.coefs, State.sig.tcrit, State.sig.alpha, State.sig.names);
  }
}

// ---------- 可视化 / PDP 交互效应分析 ----------
// 因子工具：仿 Design-Expert 的 Factors Tool
// 两个因子作为坐标轴（X1 / X2），其余因子用滑块固定在某个取值上，
// 左侧等值线图随取值实时重算。
const FT_LETTER = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

function ftLetter(p) { return FT_LETTER[p] || ('X' + (p + 1)); }

// p 是 xIdx 中的位置（0..n-1），不是原始列号
function ftRange(p) {
  const d = getXY();
  let min = Infinity, max = -Infinity;
  if (d) d.X.forEach(r => { const v = r[p]; if (v < min) min = v; if (v > max) max = v; });
  if (!isFinite(min) || !isFinite(max)) return { min: 0, max: 1 };
  if (min === max) return { min: min - 0.5, max: max + 0.5 };
  return { min, max };
}
function ftMid(p) { const r = ftRange(p); return (r.min + r.max) / 2; }
function ftName(p) { const ds = State.dataset; return ds.headers[ds.xIdx[p]]; }
function ftLabel(p) { return ftLetter(p) + ': ' + ftName(p); }

function ftEnsure() {
  const ds = State.dataset;
  const d = getXY();
  if (!ds || !d || !ds.xIdx || ds.xIdx.length < 2) return null;
  const n = ds.xIdx.length;
  if (!State.ft) State.ft = { j: 0, k: 1, held: {}, active: null, run: -1 };
  const ft = State.ft;

  if (!(ft.j >= 0 && ft.j < n)) ft.j = 0;
  if (!(ft.k >= 0 && ft.k < n) || ft.k === ft.j) {
    ft.k = -1;
    for (let p = 0; p < n; p++) if (p !== ft.j) { ft.k = p; break; }
  }
  for (let p = 0; p < n; p++) {
    if (p === ft.j || p === ft.k) continue;
    if (!isFinite(ft.held[p])) ft.held[p] = ftMid(p);
    const r = ftRange(p);
    ft.held[p] = clamp(ft.held[p], r.min, r.max);
  }
  if (ft.active === null || ft.active === undefined || ft.active === ft.j || ft.active === ft.k) {
    ft.active = -1;
    for (let p = 0; p < n; p++) if (p !== ft.j && p !== ft.k) { ft.active = p; break; }
  }
  return ft;
}

// 固定其他因子时用的一行完整特征取值（坐标轴因子先取量程中点，随后被网格覆盖）
function ftBaseRow(ft) {
  const n = State.dataset.xIdx.length;
  const base = new Array(n);
  for (let p = 0; p < n; p++) base[p] = (p === ft.j || p === ft.k) ? ftMid(p) : ft.held[p];
  return base;
}

function ftIsAxis(ft, p) { return p === ft.j || p === ft.k; }

function renderFactorTool() {
  const ds = State.dataset;
  const ft = ftEnsure();
  const box = $('#ft-factors');
  if (!box) return;

  const tip = $('#pd-tip');
  if (!ft) {
    box.innerHTML = '<p class="ft-note" style="border:none;padding:0;margin:0">需要至少两个输入变量。</p>';
    if (tip) tip.textContent = '需要至少两个输入变量才能做可视化分析。';
    return;
  }
  const n = ds.xIdx.length;
      const canHold = n > 2;   // 只有两个因子时两个都得当坐标轴

  // 项：本系统只有一个响应变量
  const item = $('#ft-item');
  if (item) item.innerHTML = `<option>${escHtml(ds.headers[ds.yIdx])}</option>`;

  // 跳转至运行
  const runSel = $('#ft-run');
  if (runSel) {
    const opts = ds.rows.map((_, i) => `<option value="${i}">Run #${i + 1}</option>`).join('');
    runSel.innerHTML = `<option value="-1">自定义</option>` + opts;
    runSel.value = String(ft.run >= 0 && ft.run < ds.rows.length ? ft.run : -1);
  }

  // 因子行
  box.innerHTML = ds.xIdx.map((_, p) => {
    const axis = ftIsAxis(ft, p);
    const role = p === ft.j ? 'x1' : (p === ft.k ? 'x2' : 'hold');
    const r = ftRange(p);
    const v = axis ? ftMid(p) : ft.held[p];
    const slider = axis ? '' : `
        <div class="ft-slider">
          <input type="range" data-p="${p}" min="${r.min}" max="${r.max}" step="${(r.max - r.min) / 200}" value="${v}">
          <span class="ft-num" data-num="${p}">${fmt(v, 2)}</span>
        </div>`;
    return `
      <div class="ft-row${ft.active === p ? ' is-active' : ''}" data-p="${p}">
        <div class="ft-row-head">
          <span class="ft-row-label" title="${ftLabel(p)}">${escHtml(ftLabel(p))}</span>
          <select class="ft-axis" data-p="${p}">
            <option value="x1"${role === 'x1' ? ' selected' : ''}>X1</option>
            <option value="x2"${role === 'x2' ? ' selected' : ''}>X2</option>
            ${canHold ? `<option value="hold"${role === 'hold' ? ' selected' : ''}>固定</option>` : ''}
          </select>
        </div>
        ${slider}
      </div>`;
  }).join('');

  // 因子值输入框
  const val = $('#ft-value');
  const note = $('#ft-note');
  const held = ft.active >= 0 && !ftIsAxis(ft, ft.active);
  if (val) {
    val.disabled = !held;
    val.value = held ? fmt(ft.held[ft.active], 3) : '';
  }

  if (tip) {
    tip.textContent = State.model
      ? '模型已就绪：拖动滑块即可实时更新等值线。'
      : '需要先在「模型设置」中完成 SVM 模型训练。';
  }

  const mode = $('#pd-mode') ? $('#pd-mode').value : 'hold';
  const card = document.querySelector('.ft-card');
  if (card) card.classList.toggle('is-pdp', mode === 'pdp');
  if (note) {
    if (!State.model) {
      note.textContent = '请先在「模型设置」中完成 SVM 模型训练，再回到本页调节因子。';
    } else if (mode === 'pdp') {
      note.textContent = '当前是「样本平均（PDP）」模式：曲面对全部样本取平均，固定值滑块不生效，曲面会比真实响应更平缓；要看某一具体取值下的真实曲面，请切回「固定其他因子」。';
    } else {
      note.textContent = '把两个因子设为 X1、X2 作为坐标轴，其余因子用滑块固定；拖动滑块即时更新左侧等值线图。';
    }
  }
}

// 「表单…」：用表格精确录入各因子取值
function openFactorForm() {
  const ft = ftEnsure();
  if (!ft) { toast('请先导入数据'); return; }
  const ds = State.dataset;
  const body = ds.xIdx.map((_, p) => {
    const r = ftRange(p);
    const axis = ftIsAxis(ft, p);
    const cell = axis
      ? `<span class="ro">${p === ft.j ? 'X1（坐标轴）' : 'X2（坐标轴）'}</span>`
      : `<input type="number" step="any" data-p="${p}" value="${ft.held[p]}">`;
    return `<tr><td>${ftLabel(p)}</td><td class="ro">${fmt(r.min, 3)}</td><td class="ro">${fmt(r.max, 3)}</td><td>${cell}</td></tr>`;
  }).join('');

  openModal('因子取值表单', `
    <table class="ft-form-table">
      <thead><tr><th>因子</th><th>下限</th><th>上限</th><th>当前取值</th></tr></thead>
      <tbody>${body}</tbody>
    </table>
    <p class="pd-note" style="margin-top:14px">坐标轴因子在图上连续变化，不需要填值；其余因子按这里填写的数值固定。</p>
  `, `<button class="btn" id="ft-form-cancel">取消</button><button class="btn primary" id="ft-form-apply">应用</button>`);

  $('#ft-form-cancel').addEventListener('click', closeModal);
  $('#ft-form-apply').addEventListener('click', () => {
    $$('#modal-body input[data-p]').forEach(inp => {
      const p = parseInt(inp.dataset.p, 10);
      const v = parseFloat(inp.value);
      if (isFinite(v)) {
        const r = ftRange(p);
        ft.held[p] = clamp(v, r.min, r.max);
      }
    });
    ft.run = -1;
    closeModal();
    renderFactorTool();
    recomputeSurface(false);
    toast('已按表单更新因子取值');
  });
}

// 按当前设置计算曲面网格。
// hold：固定其他因子，只让两个坐标轴因子变化（Design-Expert 等值线语义）
// pdp ：对全部样本的其余特征取平均（偏依赖）
async function computeSurface(quick) {
  const ds = State.dataset;
  const data = getXY();
  const ft = ftEnsure();
  const model = State.model;
  if (!ds || !data || !ft || !model) return;
  clearTimeout(_surfTimer);
  const request = ++_surfaceRequest;
  clearInteraction('正在计算当前因子的交互效应…');

  const mode = $('#pd-mode') ? $('#pd-mode').value : 'hold';
  const grid = parseInt($('#pd-grid').value, 10) || 30;
  const levels = parseInt($('#pd-levels').value, 10) || 7;
  const n = quick ? Math.min(grid, 18) : grid;
  const j = ft.j, k = ft.k;
  const rj = ftRange(j), rk = ftRange(k);

  let pj, pk, p2, base;
  if (mode === 'hold') {
    base = ftBaseRow(ft);
    const xv = PDP.linGrid(rj.min, rj.max, n);
    const yv = PDP.linGrid(rk.min, rk.max, n);
    p2 = await PDP.surface2d(model, base, j, k, xv, yv, null);
    const axisPrediction = (axis, values) => {
      const row = base.slice();
      return { vals: values, means: values.map(value => { row[axis] = value; return model.predict(row); }) };
    };
    pj = axisPrediction(j, xv);
    pk = axisPrediction(k, yv);
  } else {
    pj = PDP.pdp1d(State.model, data.X, j, n);
    pk = PDP.pdp1d(State.model, data.X, k, n);
    p2 = await PDP.pdp2d(State.model, data.X, j, k, n, null);
  }

  if (request !== _surfaceRequest || model !== State.model || ds !== State.dataset) return;
  const conditions = mode === 'hold'
    ? ds.xIdx.flatMap((index, axis) => axis === j || axis === k ? [] : [{name:ds.headers[index], value:base[axis]}])
    : [];
  State.pdp = { j, k, grid, levels, pj, pk, p2, mode, unit: ds.unit, request, conditions, sampleCount:data.X.length };
  renderPdp();
}

let _surfTimer = null, _surfaceRequest = 0;
function recomputeSurface(quick) {
  if (!State.model) return;
  if (quick === undefined) quick = true;
  clearTimeout(_surfTimer);
  _surfaceRequest++;
  clearInteraction('正在计算当前因子的交互效应…');
  _surfTimer = setTimeout(() => { computeSurface(quick); }, quick ? 90 : 0);
}

async function runPdp() {
  if (!State.model) { toast('请先在「模型设置」中训练模型'); navigate('model'); return; }
  const data = getXY();
  if (!State.dataset || !data || State.dataset.xIdx.length < 2) {
    toast('至少需要两个输入变量'); return;
  }
  const ft = ftEnsure();
  const btn = $('#pd-run');
  btn.disabled = true; btn.textContent = '计算中…';
  try {
    await computeSurface(false);
    const nm = p => ftName(p);
    pushNotice(`可视化分析完成：${nm(ft.j)} × ${nm(ft.k)}`);
    toast('计算完成');
  } catch (e) {
    toast('计算失败：' + e.message, 3200);
  } finally {
    btn.disabled = false; btn.textContent = '重新计算';
  }
}

function renderPdp() {
  const r = State.pdp;
  if (!r) return;
  const ds = State.dataset;
  const st = PDP.stats(r.p2.z);
  const data = getXY();
  const ft = ftEnsure();
  const rawRespLabel = (ds.headers && ds.headers[ds.yIdx]) || 'Response';
  const respLabel = rawRespLabel.replace(/(?:_kPa|_MPa|\s*\([^)]*\))$/i, '') + (ds.unit ? ' (' + ds.unit + ')' : '');

  // 「跳转至运行」选中的那一次试验，在图上用红点标出
  let marker = null;
  if (ft && ft.run >= 0 && data && data.X[ft.run]) {
    marker = { x: data.X[ft.run][r.j], y: data.X[ft.run][r.k] };
  }

  const is3d = $('#pd-type') && $('#pd-type').value === '3d';
  const v3box = $('#view3d');
  if (v3box) v3box.hidden = !is3d;
  const yawEl = $('#pd-yaw'), pitchEl = $('#pd-pitch');
  const yaw = yawEl ? parseFloat(yawEl.value) || 0 : -35;
  const pitch = pitchEl ? parseFloat(pitchEl.value) || 0 : 26;
  if ($('#pd-yaw-v')) $('#pd-yaw-v').textContent = Math.round(yaw) + '°';
  if ($('#pd-pitch-v')) $('#pd-pitch-v').textContent = Math.round(pitch) + '°';

  const showPoints = !!($('#pd-show-points') && $('#pd-show-points').checked);
  const sliceRows = data && r.mode !== 'pdp' ? data.X.map((row,i)=>({row,i})).filter(({row})=>row.every((v,p)=>p===r.j || p===r.k || Math.abs(v-ft.held[p]) <= 1e-6 * Math.max(1,Math.abs(v)))) : [];
  const chartArgs = {
    xv: r.p2.xv, yv: r.p2.yv, z: r.p2.z, scale: st,
    xLabel: ftLetter(r.j) + ': ' + ftName(r.j),
    yLabel: ftLetter(r.k) + ': ' + ftName(r.k),
    unit: respLabel,
    levels: r.levels,
    marker,
    points: showPoints ? sliceRows.map(({row}) => [row[r.j], row[r.k]]) : []
  };
  if (is3d) {
    chartArgs.yaw = yaw;
    chartArgs.pitch = pitch;
    const nl = Math.max(3, Math.min(12, r.levels || 7));
    chartArgs.contourLevels = Array.from({ length: nl }, (_, i) => st.min + (st.max - st.min) * (i + 1) / (nl + 1));
    chartArgs.dataPoints = showPoints ? sliceRows.map(({row,i}) => [row[r.j], row[r.k], data.y[i]]) : [];
    Charts.surface3d($('#chart-pdp2d'), chartArgs);
  } else {
    Charts.pdp2d($('#chart-pdp2d'), chartArgs);
  }
  State.figureExport = { args: chartArgs, is3d };
  Charts.line($('#chart-pdp1x'), {
    points: r.pj.vals.map((v, i) => ({ x: v, y: r.pj.means[i] })),
    fmtX: v => fmt(v, 2), xTicks: 5
  });
  $('#cap-pdp1x').textContent = r.mode === 'hold'
    ? ftName(r.j) + ' 的边际效应曲线（其余因子固定为当前取值）'
    : ftName(r.j) + ' 的偏依赖曲线（其余特征保持原值）';
  renderInteraction(r, st);
  $('#pd-caption').textContent = ftLetter(r.j) + ': ' + ftName(r.j) + ' × ' + ftLetter(r.k) + ': ' + ftName(r.k)
    + (is3d ? ' · 3D 曲面' : '');

  const cap = $('#pd-cap');
  if (cap) {
    if (r.mode === 'hold') {
      const heldList = ds.xIdx.map((_, p) => p).filter(p => ft && !ftIsAxis(ft, p))
        .map(p => ftLetter(p) + '=' + fmt(ft.held[p], 3)).join('、');
      cap.textContent = is3d
        ? `固定其他因子（${heldList || '无'}）时的 3D 曲面；颜色由低（青）到高（黄）表示预测强度，底面为等高线投影；可勾选显示当前固定因子截面内的实测点${marker ? '，红点为当前查看的运行' : ''}`
        : `固定其他因子（${heldList || '无'}）时的预测强度等值线；勾选后显示当前固定因子截面内的实测点${marker ? '，红点为当前查看的运行' : ''}`;
    } else {
      cap.textContent = is3d
        ? '对全部样本的其余特征保持原值后取平均得到的 3D 偏依赖曲面（颜色由青经绿到黄表示强度由低到高）'
        : '对全部样本的其余特征保持原值后取平均得到的预测强度（偏依赖）；勾选后显示当前固定因子截面内的实测点';
    }
  }
}

async function exportPdpImage(format) {
  if (!State.pdp) { toast('请先完成曲面计算'); return; }
  const safe = s => String(s).replace(/[\\/:*?"<>|\s]+/g, '_');
  const tag = State.pdp.mode === 'hold' ? 'contour' : 'pdp';
  const basename = `${State.settings.exportPrefix || 'svm-ioa'}-${tag}-${safe(ftName(State.pdp.j))}-${safe(ftName(State.pdp.k))}`;
  const source = $('#chart-pdp2d'), out = document.createElement('canvas');
  out.dataset.w = String(source.clientWidth || 900);
  out.dataset.h = source.dataset.h || '540';
  out.dataset.dpr = String(Math.max(3, Math.ceil(2400 / Number(out.dataset.w))));
  const fig = State.figureExport;
  if (!fig) return;
  try {
    (fig.is3d ? Charts.surface3d : Charts.pdp2d)(out, fig.args);
    await exportCanvasImage(out, basename, format);
    pushNotice('已发起图片保存 ' + basename + '.' + format);
  } catch (error) {
    toast('图片导出失败：' + error.message);
  }
}

// ---------- 事件绑定 ----------
function bind() {
  $$('.nav-item').forEach(n => n.addEventListener('click', () => {
    if (n.dataset.page === 'data' && $('#submenu-data')) $('#submenu-data').classList.toggle('open');
    if (n.dataset.page === 'result' && $('#submenu-result')) $('#submenu-result').classList.toggle('open');
    navigate(n.dataset.page);
  }));
  $$('[data-goto]').forEach(b => b.addEventListener('click', () => navigate(b.dataset.goto)));
  // 数据分析子菜单：直接跳到对应页签
  document.querySelectorAll('[data-da-jump]').forEach(b => {
    b.addEventListener('click', () => {
      navigate('result');
      if (typeof daGo === 'function') daGo(b.dataset.daJump);
      document.querySelectorAll('[data-da-jump]').forEach(x => x.classList.toggle('active', x === b));
    });
  });

  // 顶栏：通知 / 设置
  $('#btn-notify').addEventListener('click', e => { e.stopPropagation(); toggleNotices(); });
  $('#notify-panel').addEventListener('click', e => e.stopPropagation());
  $('#notify-clear').addEventListener('click', () => {
    State.notices = [];
    renderNotices();
    toast('通知已清空');
  });
  $('#btn-settings').addEventListener('click', openSettings);
  document.addEventListener('click', () => toggleNotices(false));

  // 弹窗
  $('#modal-close').addEventListener('click', closeModal);
  $('#mask').addEventListener('click', e => { if (e.target.id === 'mask') closeModal(); });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { closeModal(); toggleNotices(false); }
  });
  $('#op-help').addEventListener('click', openHelp);
  $('#op-about').addEventListener('click', openAbout);

  $('#btn-import').addEventListener('click', () => $('#file-input').click());
  $('#file-input').addEventListener('change', e => { if (e.target.files[0]) handleFile(e.target.files[0]); e.target.value = ''; });
  $('#btn-demo').addEventListener('click', () => {
    setDataset(makeDemoDataset());
    if (typeof dwGo === 'function') dwGo(4);
    renderPlan();
    pushNotice('已载入示例数据（18 条）');
    toast('已载入示例数据（18 条）');
  });
  window.saveMeta = function () {
    const v = id => { const el = $(id); return el ? el.value : ''; };
    State.meta = Object.assign({}, State.meta, {
      name: v('#f-name') || State.meta.name,
      unit: v('#f-unit') || State.meta.unit,
      age: v('#f-aux') || State.meta.age
    });
    if (State.dataset) {
      State.dataset.unit = State.meta.unit;
      State.dataset.name = State.meta.name;
      renderDataTable();
    }
    if (typeof renderPlan === 'function') renderPlan();
    refreshChecklist();
  };
  $('#btn-export-csv').addEventListener('click', () => {
    if (!State.dataset) { toast('暂无数据可导出'); return; }
    const name = `${State.settings.exportPrefix || 'svm-ioa'}-data.csv`;
    download(name, DataIO.toCSV(State.dataset.headers, State.dataset.rows));
    pushNotice('已导出 ' + name);
    toast('已导出 ' + name);
  });

  $('#btn-train').addEventListener('click', async () => {
    const m = await trainModel();
    if (m) pushNotice(`模型训练完成：R² = ${fmt(m.r2, 4)}`);
  });
  $$('.algo-tab').forEach(t => t.addEventListener('click', () => {
    collectAlgoParams(); State.algo = t.dataset.algo; renderAlgo();
  }));
  $('#btn-run').addEventListener('click', runCompute);
  $('#btn-log-view').addEventListener('click', () => {
    const box = $('#log-stream');
    const on = box.classList.toggle('show');
    const btn = $('#btn-log-view');
    if (btn) btn.textContent = on ? '收起' : '查看';
    if (on && !box.textContent.trim()) pushLogLine('>> 暂无日志，先点「确定」运行一次计算');
    if (on) box.scrollTop = box.scrollHeight;
  });
  $('#btn-log-proc').addEventListener('click', () => {
    const box = $('#log-stream');
    box.classList.add('show');
    if ($('#btn-log-view')) $('#btn-log-view').textContent = '收起';
    const t = new Date();
    const hh = String(t.getHours()).padStart(2, '0'), mm = String(t.getMinutes()).padStart(2, '0'), ss = String(t.getSeconds()).padStart(2, '0');
    const n = ($('#log-body') ? $('#log-body').querySelectorAll('tr:not(.log-empty)').length : 0);
pushLogLine('>> [' + hh + ':' + mm + ':' + ss + '] 进程状态：就绪 · 已完成 ' + n + ' 次计算');
    box.scrollTop = box.scrollHeight;
    toast('进程状态：就绪');
  });
  $('#pd-run').addEventListener('click', runPdp);
  $('#pd-export').addEventListener('click', () => exportPdpImage('png'));
  $('#pd-export-tiff').addEventListener('click', () => exportPdpImage('tiff'));
  $('#pd-show-points').addEventListener('change', renderPdp);

  // ---------- 因子工具 ----------
  $('#ft-default').addEventListener('click', () => {
    State.ft = { j: 0, k: 1, held: {}, active: null, run: -1 };
    renderFactorTool();
    recomputeSurface(false);
    toast('已恢复默认设置');
  });

  $('#ft-form').addEventListener('click', openFactorForm);

  $('#ft-run').addEventListener('change', e => {
    const ft = ftEnsure();
    if (!ft) return;
    const i = parseInt(e.target.value, 10);
    ft.run = isFinite(i) ? i : -1;
    const d = getXY();
    if (ft.run >= 0 && d && d.X[ft.run]) {
      const n = State.dataset.xIdx.length;
      for (let p = 0; p < n; p++) {
        if (ftIsAxis(ft, p)) continue;
        const r = ftRange(p);
        ft.held[p] = clamp(d.X[ft.run][p], r.min, r.max);
      }
    }
    renderFactorTool();
    recomputeSurface(false);
  });

  // 选中某一行（用于「因子值」输入）
  $('#ft-factors').addEventListener('click', e => {
    if (e.target.tagName === 'SELECT' || e.target.tagName === 'INPUT') return;
    const row = e.target.closest ? e.target.closest('.ft-row') : null;
    if (!row) return;
    const ft = ftEnsure();
    ft.active = parseInt(row.dataset.p, 10);
    renderFactorTool();
  });

  // 拖动滑块：实时重算
  $('#ft-factors').addEventListener('input', e => {
    const el = e.target;
    if (el.tagName !== 'INPUT' || el.type !== 'range') return;
    const ft = ftEnsure();
    const p = parseInt(el.dataset.p, 10);
    ft.held[p] = parseFloat(el.value);
    ft.run = -1;
    const num = $(`.ft-num[data-num="${p}"]`);
    if (num) num.textContent = fmt(ft.held[p], 2);
    const rs = $('#ft-run'); if (rs) rs.value = '-1';
    const val = $('#ft-value');
    if (val && ft.active === p) val.value = fmt(ft.held[p], 3);
    recomputeSurface(true);
  });

  // 切换 X1 / X2 / 固定
  $('#ft-factors').addEventListener('change', e => {
    const el = e.target;
    if (el.tagName !== 'SELECT' || !el.classList.contains('ft-axis')) return;
    const ft = ftEnsure();
    if (!ft) return;
    const p = parseInt(el.dataset.p, 10);
    const role = el.value;
    const n = State.dataset.xIdx.length;

    if (role === 'x1') {
      const old = ft.j;
      if (p !== ft.j) { ft.j = p; if (p === ft.k) ft.k = old; }
    } else if (role === 'x2') {
      const old = ft.k;
      if (p !== ft.k) { ft.k = p; if (p === ft.j) ft.j = old; }
    } else if (ft.j === p || ft.k === p) {
      if (ft.j === p) ft.j = ft.k;
      ft.k = -1;
      for (let q = 0; q < n; q++) if (q !== ft.j && q !== p) { ft.k = q; break; }
      if (ft.k < 0) for (let q = 0; q < n; q++) if (q !== ft.j) { ft.k = q; break; }
    }

    if (ft.k < 0 || ft.j === ft.k) { renderFactorTool(); return; }   // 至少保留两条坐标轴

    delete ft.held[ft.j];
    delete ft.held[ft.k];
    ft.active = -1;
    for (let q = 0; q < n; q++) if (q !== ft.j && q !== ft.k) { ft.active = q; break; }
    renderFactorTool();
    recomputeSurface(false);
  });

  // 「因子值」输入框
  $('#ft-value').addEventListener('change', e => {
    const ft = ftEnsure();
    if (!ft || ft.active < 0 || ftIsAxis(ft, ft.active)) return;
    const v = parseFloat(e.target.value);
    if (!isFinite(v)) { e.target.value = fmt(ft.held[ft.active], 3); return; }
    const r = ftRange(ft.active);
    ft.held[ft.active] = clamp(v, r.min, r.max);
    ft.run = -1;
    const rs = $('#ft-run'); if (rs) rs.value = '-1';
    renderFactorTool();
    recomputeSurface(false);
  });

  $('#pd-mode').addEventListener('change', () => { renderFactorTool(); recomputeSurface(false); });
  const pdType = $('#pd-type');
  if (pdType) pdType.addEventListener('change', () => { if (State.pdp) renderPdp(); });

  const wireView3d = () => {
    const y = $('#pd-yaw'), p = $('#pd-pitch');
    const upd = () => {
      if (y && $('#pd-yaw-v')) $('#pd-yaw-v').textContent = Math.round(parseFloat(y.value)) + '°';
      if (p && $('#pd-pitch-v')) $('#pd-pitch-v').textContent = Math.round(parseFloat(p.value)) + '°';
      clearTimeout(window._v3t);
      window._v3t = setTimeout(() => { if (State.pdp) renderPdp(); }, 50);
    };
    if (y) y.addEventListener('input', upd);
    if (p) p.addEventListener('input', upd);
  };
  wireView3d();
  $('#pd-grid').addEventListener('change', () => recomputeSurface(false));
  $('#pd-levels').addEventListener('change', () => {
    if (State.pdp) { State.pdp.levels = parseInt($('#pd-levels').value, 10) || 7; renderPdp(); }
  });

  $('#btn-export-result').addEventListener('click', () => {
    const r = State.result;
    if (!r) { toast('暂无结果可导出'); return; }
    const names = r.xIdx.map(i => r.headers[i]);
    const rows = [
      ['试验方案', State.meta.name], ['养护龄期', State.meta.age || '7 d'],
      ['优化算法', r.algo], ['迭代次数', r.iter], ['计算用时(s)', r.elapsed],
      [`最优抗压强度 q_u (${r.unit})`, fmt(r.bestY)],
      ...names.map((nm, i) => [nm, fmt(r.bestX[i], 4)])
    ];
    const name = `${State.settings.exportPrefix || 'svm-ioa'}-result.csv`;
    download(name, DataIO.toCSV(['项目', '数值'], rows));
    pushNotice('已导出 ' + name);
    toast('结果已导出');
  });

  window.addEventListener('resize', () => { clearTimeout(window._rz); window._rz = setTimeout(redrawCharts, 150); });
}

// ---------- 显著性分析（RSM / ANOVA / 置换检验） ----------
const escHtml = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const sigP = p => (p === null || p === undefined) ? '--' : (p < 0.0001 ? '< 0.0001' : p.toFixed(4));
const sigPText = p => (p === null || p === undefined) ? 'P = --' : (p < 0.0001 ? 'P < 0.0001' : 'P = ' + p.toFixed(4));
const sigStar = p => (p === null || p === undefined) ? '' : (p < 0.001 ? '***' : p < 0.01 ? '**' : p < 0.05 ? '*' : p < 0.1 ? '·' : '');
const sigNum = (v, d = 2) => (v === null || v === undefined || !isFinite(v)) ? '--' : Number(v).toFixed(d);
const sigBig = v => {
  if (v === null || v === undefined || !isFinite(v)) return '--';
  const a = Math.abs(v);
  if (a >= 1e5) return (v / 1e5).toFixed(2) + '×10⁵';
  if (a >= 1e4) return (v / 1e4).toFixed(2) + '×10⁴';
  return v.toFixed(1);
};

function sigDataset() {
  const d = getXY();
  return (d && d.X.length >= 6) ? d : null;
}

// 因子短名：优先取列名里的 w1 / X1 这类代号，便于在窄表格里显示
function sigShort(name) {
  const s = String(name == null ? '' : name).trim();
  const m = s.match(/[A-Za-z]{1,3}\s?\d+/);
  if (m) return m[0].replace(/\s+/g, '');
  const m2 = s.match(/[（(]([^）)]{1,8})[）)]/);
  if (m2) return m2[1];
  return s.length > 8 ? s.slice(0, 8) + '…' : s;
}
function shortTerm(t, names) {
  if (!t) return '';
  if (t.type === 'intercept') return '常数项';
  if (t.type === 'linear') return sigShort(names[t.i]);
  if (t.type === 'interaction') return sigShort(names[t.i]) + '·' + sigShort(names[t.j]);
  return sigShort(names[t.i]) + '²';
}

// ---------- 编码设置：x0 / Δx ----------
function sigCodingDefaults(d) {
  const center = [], scale = [];
  for (let j = 0; j < d.X[0].length; j++) {
    const col = d.X.map(r => r[j]);
    const lo = Math.min(...col), hi = Math.max(...col);
    center.push((lo + hi) / 2);
    scale.push((hi - lo) > 0 ? (hi - lo) / (2 * 1.682) : 1);   // 标准 CCD：轴点 ±1.682
  }
  return { center, scale };
}

function renderSigCoding() {
  const d = sigDataset();
  if (!d) return null;
  const names = State.dataset.xIdx.map(i => State.dataset.headers[i] || ('X' + i));
  const def = sigCodingDefaults(d);
  const prev = State.sigCoding || {};
  const useCenter = Array.isArray(prev.center) && prev.center.length === names.length ? prev.center : def.center;
  const useScale = Array.isArray(prev.scale) && prev.scale.length === names.length ? prev.scale : def.scale;
  const rows = names.map((nm, j) => `<tr><td>${escHtml(nm)}</td>
      <td><input class="sig-num" type="number" step="any" data-j="${j}" data-k="center" value="${Number(useCenter[j]).toFixed(4)}"></td>
      <td><input class="sig-num" type="number" step="any" data-j="${j}" data-k="scale" value="${Number(useScale[j]).toFixed(4)}"></td>
    </tr>`).join('');
  $('#sig-coding-table').innerHTML = `<thead><tr><th>因子</th><th>中心值 x0</th><th>步长 Δx</th></tr></thead><tbody>${rows}</tbody>`;
  $$('#sig-coding-table input').forEach(inp => inp.addEventListener('change', () => { readSigCoding(); renderSig(); }));
  readSigCoding();
  $('#sig-coding-note').textContent = '系数按该编码输出，可与 Design-Expert 的「Coded Factors」方程逐项对照；F 值、P 值、R² 与编码方式无关。';
  return State.sigCoding;
}

function readSigCoding() {
  const inputs = $$('#sig-coding-table input');
  if (!inputs.length) return null;
  const center = [], scale = [];
  inputs.forEach(inp => {
    const j = Number(inp.dataset.j), k = inp.dataset.k, v = parseFloat(inp.value);
    if (!isFinite(j) || !isFinite(v)) return;
    if (k === 'center') center[j] = v; else scale[j] = v;
  });
  State.sigCoding = { mode: 'manual', center, scale };
  return State.sigCoding;
}

function showSigBanner(kind, text) {
  const el = $('#sig-banner');
  if (!el) return;
  el.hidden = false;
  el.className = 'sig-banner ' + kind;
  el.textContent = text;
}

// 统一入口：负责按钮反馈、异常兜底与状态横幅
function renderSig(opts) {
  const o = opts || {};
  const btn = $('#sig-run');
  const run = () => {
    try {
      renderSigCore();
    } catch (e) {
      console.error(e);
      const msg = e && e.message ? e.message : String(e);
      showSigBanner('err', '计算失败：' + msg);
      toast('显著性计算失败：' + msg, 4500);
      if ($('#sig-tip')) $('#sig-tip').textContent = '计算失败，请检查数据或「列角色」设置。';
    }
  };
  if (o.button && btn) {
    const old = btn.textContent;
    btn.disabled = true;
    btn.textContent = '计算中…';
    setTimeout(() => {
      try {
        run();
        if (o.notify && State.sig) {
          const s = State.sig;
          toast(`显著性计算完成：R²=${sigNum(s.r2, 4)}，F=${sigNum(s.Fmodel, 2)}，${sigPText(s.pModel)}`);
        }
      } finally {
        btn.disabled = false;
        btn.textContent = old;
      }
    }, 30);
    return;
  }
  run();
}

function renderSigCore() {
  const d = sigDataset();
  const tip = $('#sig-tip');
  if (!d) {
    if (tip) tip.textContent = '请先在「数据管理」导入至少 6 组试验数据。';
    showSigBanner('warn', '还没有可分析的数据：请到「数据管理」导入 CSV / Excel（至少 6 组，且指定 1 列为响应）。');
    return;
  }
  const names = State.dataset.xIdx.map(i => State.dataset.headers[i] || ('X' + i));
  const modeSel = $('#sig-coding-mode');
  const codingMode = modeSel ? modeSel.value : 'auto';
  const codingBox = $('#sig-coding-box');
  if (codingBox) codingBox.style.display = codingMode === 'manual' ? '' : 'none';

  let coding = null;
  if (codingMode === 'manual') {
    const cnt = $$('#sig-coding-table input[data-k="center"]').length;
    if (cnt !== names.length) renderSigCoding(); else readSigCoding();
    coding = State.sigCoding && State.sigCoding.center && State.sigCoding.center.length === names.length ? State.sigCoding : null;
  }

  let r;
  try {
    r = STATS.analyze(d.X, d.y, {
      names,
      select: $('#sig-select').value,
      alpha: parseFloat($('#sig-alpha').value) || 0.05,
      coding
    });
  } catch (e) {
    if (tip) tip.textContent = '无法拟合二次模型：' + e.message;
    showSigBanner('err', '无法拟合二次模型：' + e.message + '（常见原因：数据点少于模型项数、某列全为常数、或「列角色」把响应列设错了）');
    toast('显著性分析失败：' + e.message, 4000);
    return;
  }
  State.sig = r;
  const codeTxt = r.coded.mode === 'manual'
    ? ' · 编码 x0=' + r.coded.center.map(v => sigNum(v, 2)).join('/') + '，Δx=' + r.coded.scale.map(v => sigNum(v, 2)).join('/')
    : ' · 编码：数据范围 ±1';
  $('#sig-state').textContent = `${r.n} 组数据 · ${r.d} 个因子 · ${r.terms.length} 项模型` + codeTxt;

  $('#m-r2').textContent = sigNum(r.r2, 4);
  $('#m-adj').textContent = sigNum(r.adjR2, 4);
  $('#m-pred').textContent = sigNum(r.predR2, 4);
  $('#m-s').textContent = sigNum(r.s, 2) + ' ' + (State.dataset.unit || '');
  $('#m-f').textContent = sigNum(r.Fmodel, 2);
  $('#m-p').textContent = sigP(r.pModel);
  $('#m-p').style.color = r.pModel < 0.05 ? '#1fae7a' : '#d9534f';

  const tr = (cells, cls) => `<tr${cls ? ' class="' + cls + '"' : ''}>` + cells.map(c => `<td>${c}</td>`).join('') + '</tr>';
  const vifCell = v => {
    if (v === undefined || v === null || !isFinite(v)) return '<span style="color:#c0392b;font-weight:600">∞</span>';
    const style = v > 10 ? 'color:#c0392b;font-weight:600' : v > 5 ? 'color:#b9770e' : 'color:#8a97a8';
    return `<span style="${style}">${v.toFixed(1)}</span>`;
  };
  let html = '<thead><tr><th>来源</th><th title="平方和">SS</th><th title="自由度">df</th><th title="均方">MS</th><th>F 值</th><th>P 值</th><th title="方差膨胀因子，>10 表示严重共线">VIF</th><th>显著性</th></tr></thead><tbody>';
  html += tr(['<b>模型 Model</b>', sigBig(r.ssModel), r.dfModel, sigBig(r.msModel), sigNum(r.Fmodel, 2), '<b>' + sigP(r.pModel) + '</b>', '', sigStar(r.pModel)]);
  for (const t of r.termStats) {
    const nm = shortTerm(t.term, names);
    html += tr([`<span title="${escHtml(t.label)}">${escHtml(nm)}</span>`, sigBig(t.ss), 1, sigBig(t.ss), sigNum(t.F, 2), sigP(t.p), vifCell(t.vif), sigStar(t.p)]);
  }
  html += tr(['残差 Residual', sigBig(r.ssResid), r.dfResid, sigBig(r.msResid), '', '', '', '']);
  if (r.lackOfFit) {
    html += tr(['　失拟 Lack of Fit', sigBig(r.lackOfFit.ssLOF), r.lackOfFit.dfLOF, sigBig(r.lackOfFit.ssLOF / r.lackOfFit.dfLOF), sigNum(r.lackOfFit.F, 2), sigP(r.lackOfFit.p), '', sigStar(r.lackOfFit.p)]);
    html += tr(['　纯误差 Pure Error', sigBig(r.lackOfFit.ssPE), r.lackOfFit.dfPE, sigBig(r.lackOfFit.ssPE / r.lackOfFit.dfPE), '', '', '', '']);
  }
  const tss = r.ssModel + r.ssResid;
  html += tr(['<b>总和 Total</b>', sigBig(tss), r.n - 1, '', '', '', '', '']);
  html += '</tbody>';
  $('#sig-anova').innerHTML = html;
  $('#sig-anova-cap').textContent = `模型 F=${sigNum(r.Fmodel, 2)}，${sigPText(r.pModel)}；R²=${sigNum(r.r2, 4)}，调整 R²=${sigNum(r.adjR2, 4)}`;

  const aqEl = $('#sig-adequacy');
  if (aqEl) {
    aqEl.hidden = false;
    aqEl.innerHTML = `近似信噪比 = <b>${sigNum(r.adeq, 1)}</b>（仅作诊断参考，不套用标准 Adeq Precision 阈值）` +
      ` · C.V. = <b>${sigNum(r.cvPct, 2)}%</b>（越小越好）` +
      ` · PRESS = <b>${sigBig(r.press)}</b>` +
      `<span class="muted">（R²=${sigNum(r.r2, 4)}，调整 R²=${sigNum(r.adjR2, 4)}，固定模型 PRESS R²=${sigNum(r.predR2, 4)}）</span>`;
  }

  const vEl = $('#sig-vif');
  if (vEl) {
    const vifs = r.termStats.map(t => t.vif).filter(v => v !== undefined);
    const maxVif = vifs.length ? Math.max(...vifs) : 1;
    const high = r.termStats.filter(t => t.vif > 10).sort((a, b) => b.vif - a.vif);
    vEl.hidden = false;
    if (high.length) {
      vEl.innerHTML = `<b style="color:#c0392b">共线性严重（VIF &gt; 10）：</b>` +
        high.map(t => `${escHtml(shortTerm(t.term, names))}（VIF=${isFinite(t.vif) ? t.vif.toFixed(0) : '∞'}）`).join('、') +
        '。这时单项 P 值不可靠——各项会互相“顶替”，整体检验与单项检验结论可能不同。建议增加试验点、减少模型项，或直接看「向后剔除」的最终模型。' +
        '<span class="muted">（VIF = 1 表示完全正交；&gt; 10 视为严重共线）</span>';
    } else {
      vEl.innerHTML = `<span class="muted">共线性检查通过：最大 VIF = ${maxVif.toFixed(1)}（≈1 表示正交），单项 P 值可正常判读。</span>`;
    }
  }

  const dEl = $('#sig-dropped');
  if (dEl) {
    if (r.dropped && r.dropped.length) {
      dEl.hidden = false;
      dEl.innerHTML = `已按 α=${r.alpha} 向后剔除：` +
        r.dropped.map(d => `<b title="${escHtml(d.label)}">${escHtml(shortTerm(d.term, names))}</b>（P=${sigNum(d.p, 3)}）`).join('、') +
        '。想查看完整模型，请把「模型选择」改成「保留全部项」。';
    } else {
      dEl.hidden = true;
      dEl.textContent = '';
    }
  }

  const coefTitle = r.coded.mode === 'manual' ? '系数（x0/Δx 编码）' : '系数（数据范围 ±1）';
  let ch = `<thead><tr><th>项</th><th>${coefTitle}</th><th>标准误</th><th>t 值</th><th>P 值</th><th>95% 置信区间</th><th></th></tr></thead><tbody>`;
  for (const c of r.coefs) {
    const strong = (c.p !== null && c.p < 0.1) ? ' style="font-weight:600"' : '';
    ch += `<tr${strong}><td title="${escHtml(c.label)}">${escHtml(shortTerm(c.term, names))}</td><td>${sigNum(c.est, 3)}</td><td>${sigNum(c.se, 3)}</td><td>${sigNum(c.t, 2)}</td><td>${sigP(c.p)}</td><td>[${sigNum(c.lo, 2)}, ${sigNum(c.hi, 2)}]</td><td>${sigStar(c.p)}</td></tr>`;
  }
  ch += '</tbody>';
  $('#sig-coef').innerHTML = ch;
  if ($('#sig-coef-note')) {
    $('#sig-coef-note').innerHTML = r.coded.mode === 'manual'
      ? `系数按 <b>coded = (x − x0)/Δx</b> 编码（x0=${r.coded.center.map(v => sigNum(v, 2)).join('、')}，Δx=${r.coded.scale.map(v => sigNum(v, 2)).join('、')}），可用于按相同编码和模型项进行对照；显著性标记：*** p&lt;0.001，** p&lt;0.01，* p&lt;0.05，· p&lt;0.1。`
      : '系数为<b>编码值</b>（每个因子按数据范围线性映射到 ±1）；显著性标记：*** p&lt;0.001，** p&lt;0.01，* p&lt;0.05，· p&lt;0.1。';
  }

  const lof = $('#sig-lof');
  if (r.lackOfFit) {
    const ok = r.lackOfFit.p !== null && r.lackOfFit.p > 0.05;
    lof.innerHTML = `
      <p style="font-size:15px;margin-bottom:8px">F = <b>${sigNum(r.lackOfFit.F, 2)}</b>，P = <b>${sigP(r.lackOfFit.p)}</b>（失拟 ${r.lackOfFit.dfLOF} 自由度，纯误差 ${r.lackOfFit.dfPE} 自由度）</p>
      <p class="sig-verdict ${ok ? 'good' : 'warn'}">${r.lackOfFit.p === null ? escHtml(r.lackOfFit.reason || '无法估计失拟检验') : ok ? '尚未检出显著失拟；请结合残差和外部验证判断模型适用性。' : '失拟显著（P ≤ 0.05）：二次模型存在系统偏差，应调整模型或补充试验。'}</p>
      <p class="sig-note">识别到 ${r.lackOfFit.groups} 组重复点，共 ${r.lackOfFit.points} 次试验。</p>`;
  } else {
    lof.innerHTML = `<p class="muted">未检测到重复试验点，纯误差无法估计，因此不能做失拟检验。在中心点安排 2~6 次重复即可启用该检验（与 Design-Expert 的做法一致）。</p>`;
  }

  let pt, tag;
  if (State.result && State.result.bestX) { pt = State.result.bestX.slice(); tag = '当前最优配比（来自配比计算）'; }
  else { pt = r.coded.center.slice(); tag = '试验设计的中心点（因素均值处）'; }
  const pr = r.predict(pt);
  const mins = [], maxs = [];
  for (let j = 0; j < r.d; j++) { const col = d.X.map(row => row[j]); mins.push(Math.min(...col)); maxs.push(Math.max(...col)); }
  const outside = pt.some((v, j) => v < mins[j] - 1e-9 || v > maxs[j] + 1e-9);
  $('#sig-pred').innerHTML = `
    <p class="muted" style="margin-bottom:10px">${tag}</p>
    <table class="sig-mini"><tbody>
      ${names.map((nm, j) => `<tr><td>${escHtml(nm)}</td><td>${sigNum(pt[j], 4)}</td><td class="muted">范围 ${sigNum(mins[j], 2)}–${sigNum(maxs[j], 2)}</td></tr>`).join('')}
      <tr><td><b>预测值</b></td><td><b>${sigNum(pr.yhat, 1)}</b></td><td class="muted">${escHtml(State.dataset.unit || '')}</td></tr>
      <tr><td>均值 95% 置信区间</td><td>[${sigNum(pr.ciLo, 1)}, ${sigNum(pr.ciHi, 1)}]</td><td class="muted">模型均值的不确定度</td></tr>
      <tr><td>单次观测 95% 预测区间</td><td>[${sigNum(pr.piLo, 1)}, ${sigNum(pr.piHi, 1)}]</td><td class="muted">再做一次试验的落点范围</td></tr>
    </tbody></table>
    ${outside ? '<p class="sig-verdict warn">注意：该点超出试验数据范围，属于外推，区间不可信。</p>' : ''}`;

  drawPareto($('#chart-pareto'), r.coefs, r.tcrit, parseFloat($('#sig-alpha').value) || 0.05, names);
  $('#cap-pareto').textContent = `各因子项 |t| 值（虚线：α=${(parseFloat($('#sig-alpha').value) || 0.05)} 时临界 t=${sigNum(r.tcrit, 2)}）`;

  if (tip) tip.textContent = `已完成：${r.terms.length} 项模型（含截距），残差 ${r.dfResid} 自由度。`;
  const timeStr = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  showSigBanner(r.lackOfFit && (r.lackOfFit.p === null || r.lackOfFit.p <= 0.05) ? 'warn' : 'ok',
    `计算完成 ${timeStr} · ${r.n} 组数据 · ${r.d} 个因子 · ${r.terms.length} 项模型 · ` +
    `R²=${sigNum(r.r2, 4)} · 调整 R²=${sigNum(r.adjR2, 4)} · F=${sigNum(r.Fmodel, 2)} · ${sigPText(r.pModel)}` +
    (r.lackOfFit ? ` · 失拟 ${sigPText(r.lackOfFit.p).replace('P ', 'P ')}` : ''));
}

function drawPareto(canvas, coefs, tcrit, alpha, names) {
  if (!canvas || !coefs) return;
  const rows = coefs.slice(1)
    .map(c => ({ label: names ? shortTerm(c.term, names) : c.label, t: Math.abs(c.t), p: c.p }))
    .sort((a, b) => b.t - a.t);
  if (!rows.length) return;

  const dpr = window.devicePixelRatio || 1;
  const host = canvas.parentElement;
  const W = Math.max(Math.round((host && host.clientWidth) || 0), 320);
  const rowH = 24, gap = 9, padT = 18, padB = 36, padR = 56;
  const H = padT + padB + rows.length * (rowH + gap) - gap;
  const bottom = padT + rows.length * (rowH + gap) - gap;

  canvas.width = Math.round(W * dpr);
  canvas.height = Math.round(H * dpr);
  canvas.style.height = H + 'px';

  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);
  ctx.font = '12px system-ui, -apple-system, "Segoe UI", sans-serif';

  let labelW = 0;
  for (const r of rows) labelW = Math.max(labelW, ctx.measureText(r.label).width);
  const padL = Math.min(Math.ceil(labelW) + 18, Math.round(W * 0.36));
  const pw = Math.max(W - padL - padR, 60);

  const maxT = Math.max(tcrit * 1.25, ...rows.map(r => r.t), 1e-9);
  const x = v => padL + (v / maxT) * pw;

  // 网格与刻度
  const ticks = pw < 240 ? 3 : 5;
  for (let i = 0; i <= ticks; i++) {
    const v = (maxT * i) / ticks;
    const xx = x(v);
    ctx.strokeStyle = i === 0 ? '#dbe3ef' : '#eef2f8';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(xx, padT - 6); ctx.lineTo(xx, bottom); ctx.stroke();
    ctx.fillStyle = '#9aa6b8'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText(v.toFixed(v >= 10 ? 0 : 1), xx, bottom + 8);
  }

  rows.forEach((r, i) => {
    const y0 = padT + i * (rowH + gap);
    const sig = r.p !== null && r.p < alpha;
    const bw = Math.max(x(r.t) - padL, 1);

    ctx.fillStyle = sig ? '#2f7ef5' : '#c7d3e3';
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(padL, y0, bw, rowH, 4); else ctx.rect(padL, y0, bw, rowH);
    ctx.fill();

    let label = r.label;
    const avail = padL - 12;
    if (ctx.measureText(label).width > avail) {
      while (label.length > 1 && ctx.measureText(label + '…').width > avail) label = label.slice(0, -1);
      label += '…';
    }
    ctx.fillStyle = '#5b7186'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    ctx.fillText(label, padL - 8, y0 + rowH / 2);

    const txt = r.t.toFixed(2);
    const tw = ctx.measureText(txt).width;
    if (padL + bw + 6 + tw > W - 4) {
      ctx.fillStyle = '#ffffff'; ctx.textAlign = 'right';
      ctx.fillText(txt, padL + bw - 6, y0 + rowH / 2);
    } else {
      ctx.fillStyle = '#5b7186'; ctx.textAlign = 'left';
      ctx.fillText(txt, padL + bw + 6, y0 + rowH / 2);
    }
  });

  // α 临界值线
  const cx = x(tcrit);
  ctx.save();
  ctx.setLineDash([5, 4]); ctx.strokeStyle = '#e2574c'; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.moveTo(cx, padT - 8); ctx.lineTo(cx, bottom + 3); ctx.stroke();
  ctx.restore();
  ctx.fillStyle = '#e2574c'; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
  ctx.font = '11px system-ui, sans-serif';
  ctx.fillText('α=' + alpha, Math.min(cx + 4, W - 46), padT - 8);
}

function exportSig() {
  const r = State.sig;
  if (!r) { toast('请先计算显著性'); return; }
  const rows = [];
  rows.push(['Source', 'SS', 'df', 'MS', 'F', 'P', 'VIF', 'Significance']);
  rows.push(['Coding mode', r.coded.mode === 'manual' ? 'manual: coded=(x-x0)/dx' : 'auto: data range +-1', '', '', '', '', '', '']);
  rows.push(['x0', r.coded.center.map(v => v.toFixed(4)).join(', '), '', '', '', '', '', '']);
  rows.push(['dx', r.coded.scale.map(v => v.toFixed(4)).join(', '), '', '', '', '', '', '']);
  rows.push(['Model', r.ssModel.toFixed(2), r.dfModel, r.msModel.toFixed(2), r.Fmodel.toFixed(3), sigP(r.pModel), '', sigStar(r.pModel)]);
  for (const t of r.termStats) {
    const vif = t.vif === undefined ? '' : (isFinite(t.vif) ? t.vif.toFixed(2) : 'Inf');
    rows.push([t.label, t.ss.toFixed(2), 1, t.ss.toFixed(2), t.F.toFixed(3), sigP(t.p), vif, sigStar(t.p)]);
  }
  rows.push(['Residual', r.ssResid.toFixed(2), r.dfResid, r.msResid.toFixed(2), '', '', '', '']);
  if (r.lackOfFit) {
    rows.push([' Lack of Fit', r.lackOfFit.ssLOF.toFixed(2), r.lackOfFit.dfLOF, (r.lackOfFit.ssLOF / r.lackOfFit.dfLOF).toFixed(2), (r.lackOfFit.F || 0).toFixed(3), sigP(r.lackOfFit.p), '', sigStar(r.lackOfFit.p)]);
    rows.push([' Pure Error', r.lackOfFit.ssPE.toFixed(2), r.lackOfFit.dfPE, (r.lackOfFit.ssPE / r.lackOfFit.dfPE).toFixed(2), '', '', '', '']);
  }
  const maxVif = Math.max(...r.termStats.map(t => (isFinite(t.vif) ? t.vif : 1e9)));
  rows.push(['Max VIF', maxVif >= 1e9 ? 'Inf' : maxVif.toFixed(2), maxVif > 10 ? 'COLLINEARITY WARNING' : 'OK', '', '', '', '', '']);
  rows.push(['近似信噪比', isFinite(r.adeq) ? r.adeq.toFixed(2) : '', 'approximate diagnostic only', '', '', '', '', '']);
  rows.push(['C.V. %', isFinite(r.cvPct) ? r.cvPct.toFixed(2) : '', '', '', '', '', '', '']);
  rows.push(['PRESS', isFinite(r.press) ? r.press.toFixed(2) : '', '', '', '', '', '', '']);
  rows.push(['R2 / adjR2 / predR2', r.r2.toFixed(4), r.adjR2.toFixed(4), r.predR2.toFixed(4), '', '', '', '']);
  rows.push([]);
  if (r.dropped && r.dropped.length) {
    rows.push([`Dropped terms (alpha=${r.alpha})`, 'P at removal']);
    for (const d of r.dropped) rows.push([d.label, sigP(d.p)]);
    rows.push([]);
  }
  rows.push(['Term', 'Coef(coded)', 'SE', 't', 'P', 'CI_low', 'CI_high']);
  for (const c of r.coefs) rows.push([c.label, c.est.toFixed(4), c.se.toFixed(4), c.t.toFixed(3), sigP(c.p), c.lo.toFixed(3), c.hi.toFixed(3)]);
  const name = `${State.settings.exportPrefix || 'svm-ioa'}-ANOVA.csv`;
  download(name, DataIO.toCSV(['SVM-IOA significance analysis'], rows));
  pushNotice('已导出 ' + name);
  toast('ANOVA 已导出');
}

async function runSigPerm() {
  const d = sigDataset();
  if (!d) { toast('请先导入数据'); return; }
  const btn = $('#sig-perm'), st = $('#sig-perm-state'), body = $('#sig-perm-body');
  btn.disabled = true; btn.textContent = '检验中…';
  try {
    if (!State.model) { st.textContent = '正在训练 SVM 模型…'; await trainModel(); }
    const m = State.model;
    const fit = (Xtr, ytr) => {
      const mod = ML.trainSVR(Xtr, ytr, { C: m.C, gamma: m.gamma, eps: m.eps, standardize: true });
      return x => mod.predict(x);
    };
    const perms = d.X.length > 60 ? 39 : 99;
    const res = await STATS.permutationTest({
      X: d.X, y: d.y, fit, perms, folds: 5,
      onProgress: p => { st.textContent = '运行中 ' + Math.round(p * 100) + '%'; }
    });
    State.sigPerm = res;
    st.textContent = '已完成';
    const sig = res.p < 0.05;
    body.innerHTML = `
      <div class="metric-row cols3" style="margin-bottom:14px">
        <div class="metric"><span class="metric-value">${sigNum(res.observed, 4)}</span><span class="metric-label">实测交叉验证 R²</span></div>
        <div class="metric"><span class="metric-value">${res.p.toFixed(3)}</span><span class="metric-label">置换检验 P 值</span></div>
        <div class="metric"><span class="metric-value">${sigNum(res.nullMean, 3)}</span><span class="metric-label">随机数据平均 R²</span></div>
      </div>
      <p class="sig-verdict ${sig ? 'good' : 'warn'}">${sig
        ? `P = ${res.p.toFixed(3)} &lt; 0.05：打乱响应值 ${res.perms} 次后，随机数据的 R² 最高只有 ${sigNum(res.nullMax, 3)}，说明 SVM 学到的关系是真实的，不是巧合。`
        : `P = ${res.p.toFixed(3)} ≥ 0.05：无法排除“模型只是拟合了噪声”，建议增加样本或检查数据质量。`}</p>
      <p class="sig-note">方法：固定当前 SVM 超参数（C=${sigNum(m.C, 4)}, γ=${sigNum(m.gamma, 4)}），对响应值做 ${res.perms} 次随机置换，每次重跑 5 折交叉验证，统计随机 R² ≥ 实测 R² 的比例。</p>`;
    pushNotice(`置换检验完成：P=${res.p.toFixed(3)}`);
  } catch (e) {
    body.innerHTML = `<p class="sig-verdict warn">检验失败：${escHtml(e.message)}</p>`;
  } finally {
    btn.disabled = false; btn.textContent = 'SVM 置换检验';
  }
}

// ---------- 模型对比：SVR vs 二次 RSM ----------
function svrLooPredictions(X, y, m) {
  const pred = new Array(X.length);
  for (let i = 0; i < X.length; i++) {
    const mod = ML.trainSVR(X.filter((_, j) => j !== i), y.filter((_, j) => j !== i),
      { C: m.C, gamma: m.gamma, eps: m.eps, standardize: true });
    pred[i] = mod.predict(X[i]);
  }
  return pred;
}

function errStats(actual, pred) {
  const n = actual.length;
  const e = actual.map((v, i) => pred[i] - v);
  const ae = e.map(Math.abs);
  const rmse = Math.sqrt(e.reduce((s, v) => s + v * v, 0) / n);
  const mae = ae.reduce((a, b) => a + b, 0) / n;
  const maxe = Math.max(...ae);
  const mean = actual.reduce((a, b) => a + b, 0) / n;
  const sst = actual.reduce((s, v) => s + (v - mean) ** 2, 0);
  const ssr = e.reduce((s, v) => s + v * v, 0);
  return { rmse, mae, maxe, r2: 1 - ssr / sst, n };
}

// 设计域：因子上下界 + 以数据最外圈为半径的"设计球"投影
function sigDesignRegion(d) {
  const p = d.X[0].length;
  const lb = [], ub = [], c = [], s = [];
  for (let j = 0; j < p; j++) {
    const col = d.X.map(r => r[j]);
    const lo = Math.min(...col), hi = Math.max(...col);
    lb.push(lo); ub.push(hi);
    c.push((lo + hi) / 2); s.push((hi - lo) / 2 || 1);
  }
  let R = 0;
  for (const row of d.X) {
    let t = 0;
    for (let j = 0; j < p; j++) { const z = (row[j] - c[j]) / s[j]; t += z * z; }
    R = Math.max(R, Math.sqrt(t));
  }
  const project = (x) => {
    let t = 0; const z = [];
    for (let j = 0; j < p; j++) { const q = (x[j] - c[j]) / s[j]; z.push(q); t += q * q; }
    const r = Math.sqrt(t);
    if (r > R && r > 1e-9) {
      const k = R / r;
      for (let j = 0; j < p; j++) x[j] = c[j] + z[j] * k * s[j];
    }
  };
  return { lb, ub, project, R, center: c, scale: s };
}

async function runCompare() {
  const d = sigDataset();
  if (!d) { toast('请先导入数据'); return; }
  const btn = $('#cmp-run'), st = $('#cmp-state'), body = $('#cmp-body');
  const old = btn.textContent;
  btn.disabled = true; btn.textContent = '对比中…';
  const wait = ms => new Promise(r => setTimeout(r, ms));
  try {
    const names = State.dataset.xIdx.map(i => State.dataset.headers[i] || ('X' + i));
    const mode = $('#sig-coding-mode') ? $('#sig-coding-mode').value : 'auto';
    const coding = mode === 'manual' ? State.sigCoding : null;

    st.textContent = 'RSM 留一法…'; await wait(30);
    const rsmFull = STATS.analyze(d.X, d.y, { names, coding, select: 'none' });
    const rsmLoo = STATS.looRsm(d.X, d.y, { names, coding });

    st.textContent = '训练 SVR…'; await wait(30);
    if (!State.model) await trainModel();
    const svr = State.model;

    st.textContent = 'SVR 留一法…'; await wait(30);
    const svrLoo = svrLooPredictions(d.X, d.y, svr);

    const a = errStats(d.y, rsmLoo);
    const b = errStats(d.y, svrLoo);
    const diffs = rsmLoo.map((p, i) => Math.abs(rsmLoo[i] - d.y[i]) - Math.abs(svrLoo[i] - d.y[i]));
    const wil = STATS.wilcoxonSignedRank(diffs);

    st.textContent = '两模型各自寻优…'; await wait(30);
    const region = sigDesignRegion(d);
    const psoOpts = { lb: region.lb, ub: region.ub, project: region.project, np: 40, maxIter: 60, c1: 2, c2: 2, wMax: 0.9, wMin: 0.4 };
    const optRsm = ML.runPSO(Object.assign({}, psoOpts, { objective: x => rsmFull.predict(x).yhat }));
    const optSvr = ML.runPSO(Object.assign({}, psoOpts, { objective: x => svr.predict(x) }));

    const unit = State.dataset.unit || '';
    const fmtN = (v, d0 = 2) => (isFinite(v) ? Number(v).toFixed(d0) : '--');
    const better = b.rmse < a.rmse ? 'SVR' : (a.rmse < b.rmse ? 'RSM' : '两者相同');
    const gain = Math.abs(a.rmse - b.rmse) / Math.max(a.rmse, b.rmse) * 100;
    const sig = wil.p < 0.05;
    const sameOpt = optRsm.best.every((v, j) => Math.abs(v - optSvr.best[j]) <= 0.02 * Math.max(1, Math.abs(v)));

    body.innerHTML = `
      <div class="table-wrap" style="margin-bottom:12px">
        <table class="data-table">
          <thead><tr><th>指标（LOO 留一法）</th><th>二次 RSM</th><th>SVR（RBF）</th><th>差值（RSM−SVR）</th></tr></thead>
          <tbody>
            <tr><td>R²</td><td>${fmtN(a.r2, 4)}</td><td>${fmtN(b.r2, 4)}</td><td>${fmtN(a.r2 - b.r2, 4)}</td></tr>
            <tr><td>RMSE (${escHtml(unit)})</td><td>${fmtN(a.rmse, 2)}</td><td>${fmtN(b.rmse, 2)}</td><td>${fmtN(a.rmse - b.rmse, 2)}</td></tr>
            <tr><td>MAE (${escHtml(unit)})</td><td>${fmtN(a.mae, 2)}</td><td>${fmtN(b.mae, 2)}</td><td>${fmtN(a.mae - b.mae, 2)}</td></tr>
            <tr><td>最大误差 (${escHtml(unit)})</td><td>${fmtN(a.maxe, 1)}</td><td>${fmtN(b.maxe, 1)}</td><td>${fmtN(a.maxe - b.maxe, 1)}</td></tr>
            <tr><td>最优配比</td><td>${optRsm.best.map(v => fmtN(v, 3)).join(' / ')}</td><td>${optSvr.best.map(v => fmtN(v, 3)).join(' / ')}</td><td>${sameOpt ? '基本一致' : '存在差异'}</td></tr>
            <tr><td>最优预测值</td><td>${fmtN(optRsm.fitness, 1)}</td><td>${fmtN(optSvr.fitness, 1)}</td><td>${fmtN(optRsm.fitness - optSvr.fitness, 1)}</td></tr>
          </tbody>
        </table>
      </div>
      <p class="sig-verdict ${better === 'SVR' ? 'good' : 'warn'}">
        逐点误差更小的是 <b>${better}</b>：RMSE 相差 ${fmtN(gain, 1)}%；
        Wilcoxon 符号秩检验 ${wil.n} 个有效配对，P = <b>${isFinite(wil.p) ? wil.p.toFixed(3) : '--'}</b>
        → ${sig ? '两者差异<b>显著</b>' : '差异<b>不显著</b>（不能据此证明两者等效）'}。
        最优配比${sameOpt ? '基本一致（差值 &lt; 2%）' : '存在差异，需结合实际约束判断'}。
      </p>
      <p class="sig-note">说明：RSM 用全部二次项（不做剔除），SVR 用当前超参数（C=${fmtN(svr.C, 3)}, γ=${fmtN(svr.gamma, 3)}）；两者都在<b>设计球</b>内寻优（半径 = 数据点最外圈），不越出试验支持域。</p>`;
    st.textContent = '已完成';
  } catch (e) {
    console.error(e);
    body.innerHTML = `<p class="sig-verdict warn">对比失败：${escHtml(e.message)}</p>`;
    st.textContent = '失败';
  } finally {
    btn.disabled = false; btn.textContent = old;
  }
}

// ---------- Bootstrap 不确定性 ----------
async function runBootstrap() {
  const d = sigDataset();
  if (!d) { toast('请先导入数据'); return; }
  const btn = $('#boot-run'), st = $('#boot-state'), body = $('#boot-body');
  const B = parseInt($('#boot-b').value, 10) || 300;
  const mode = $('#boot-point').value;
  const old = btn.textContent;
  btn.disabled = true; btn.textContent = '采样中…';
  const wait = ms => new Promise(r => setTimeout(r, ms));
  try {
    if (!State.model) { st.textContent = '训练 SVR…'; await trainModel(); }
    const m = State.model;
    const n = d.y.length, p = d.X[0].length;
    const lb = [], ub = [];
    for (let j = 0; j < p; j++) {
      const col = d.X.map(r => r[j]);
      lb.push(Math.min(...col)); ub.push(Math.max(...col));
    }
    const x0 = (mode === 'opt' && State.result && State.result.bestX)
      ? State.result.bestX.slice()
      : d.X[0].map((_, j) => d.X.reduce((s, r) => s + r[j], 0) / n);

    // 设计域约束：以数据点最外圈为半径的"设计球"，避免在立方体角落外推
    const region = sigDesignRegion(d);
    const useSphere = ($('#boot-domain') ? $('#boot-domain').value : 'sphere') === 'sphere';
    const Rdesign = region.R;
    const project = useSphere ? region.project : null;

    // 留一残差（用于单次观测的预测区间）
    st.textContent = '计算留一残差…'; await wait(20);
    const residuals = [];
    for (let i = 0; i < n; i++) {
      const mod = ML.trainSVR(d.X.filter((_, j) => j !== i), d.y.filter((_, j) => j !== i),
        { C: m.C, gamma: m.gamma, eps: m.eps, standardize: true });
      residuals.push(d.y[i] - mod.predict(d.X[i]));
    }

    const preds = [], optX = [], optY = [];
    const yhatAll = d.X.map(x => m.predict(x));
    let done = 0;
    while (done < B) {
      // 残差重采样：保留设计点，响应值由拟合值 + 随机残差重建
      const yb = yhatAll.map(v => v + residuals[Math.floor(rnd() * residuals.length)]);
      let mod;
      try { mod = ML.trainSVR(d.X, yb, { C: m.C, gamma: m.gamma, eps: m.eps, standardize: true }); }
      catch (e) { continue; }
      preds.push(mod.predict(x0));
      const opt = ML.runPSO({ lb, ub, np: 24, maxIter: 40, c1: 2, c2: 2, wMax: 0.9, wMin: 0.4, project, objective: x => mod.predict(x) });
      optX.push(opt.best); optY.push(opt.fitness);
      done++;
      if (done % 10 === 0) {
        st.textContent = `采样中 ${Math.round(done / B * 100)}%（${done}/${B}）`;
        await wait(0);
      }
    }
    if (!preds.length) throw new Error('有效重采样次数为 0，数据可能过于集中');

    const sorted = a => a.slice().sort((x, y) => x - y);
    const ci = a => { const s = sorted(a); return [STATS.percentile(s, 0.025), STATS.percentile(s, 0.975)]; };
    const predCI = ci(preds);
    const piSamples = preds.map((v) => v + residuals[Math.floor(rnd() * residuals.length)]);
    const predPI = ci(piSamples);
    const yhat0 = m.predict(x0);
    const optYCI = ci(optY);
    const xCI = [];
    for (let j = 0; j < p; j++) xCI.push(ci(optX.map(x => x[j])));

    // 全模型在同样范围内寻优，作为点估计
    const fullOpt = ML.runPSO({ lb, ub, np: 40, maxIter: 60, c1: 2, c2: 2, wMax: 0.9, wMin: 0.4, project, objective: x => m.predict(x) });
    const names = State.dataset.xIdx.map(i => State.dataset.headers[i] || ('X' + i));
    const unit = State.dataset.unit || '';
    const f2 = v => (isFinite(v) ? Number(v).toFixed(2) : '--');
    const f3 = v => (isFinite(v) ? Number(v).toFixed(3) : '--');

    const rows = [];
    rows.push(`<tr><td>评估点</td><td colspan="3">${mode === 'opt' ? '当前最优配比（来自「配比计算」）' : '因素中心点（各因子均值）'}：${x0.map(v => f3(v)).join(' / ')}</td></tr>`);
    rows.push(`<tr><td>预测值</td><td>${f2(yhat0)} ${escHtml(unit)}</td><td>[${f2(predCI[0])}, ${f2(predCI[1])}]</td><td class="muted">模型不确定度（95% CI）</td></tr>`);
    rows.push(`<tr><td>单次观测</td><td>—</td><td>[${f2(predPI[0])}, ${f2(predPI[1])}]</td><td class="muted">含试验噪声（95% PI）</td></tr>`);
    names.forEach((nm, j) => {
      const wide = (xCI[j][1] - xCI[j][0]) > 0.4 * (ub[j] - lb[j]);
      rows.push(`<tr><td>最优 ${escHtml(sigShort(nm))}</td><td>${f3(fullOpt.best[j])}</td><td>[${f3(xCI[j][0])}, ${f3(xCI[j][1])}]</td><td class="muted">${wide ? '<span style="color:#c0392b">区间较宽，建议补点</span>' : '较稳定'}</td></tr>`);
    });
    rows.push(`<tr><td>最优预测值</td><td>${f2(fullOpt.fitness)}</td><td>[${f2(optYCI[0])}, ${f2(optYCI[1])}]</td><td class="muted">B=${preds.length} 次有效重采样</td></tr>`);

    body.innerHTML = `
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>项目</th><th>点估计</th><th>95% 区间</th><th>说明</th></tr></thead>
          <tbody>${rows.join('')}</tbody>
        </table>
      </div>
      <p class="sig-note">方法：<b>残差重采样</b>（设计点固定，响应值 = 拟合值 + 随机留一残差）${preds.length} 次，每次用相同超参数（C=${f2(m.C)}，γ=${f2(m.gamma)}）重新拟合 SVR 并重新寻优；区间取 2.5%–97.5% 分位数。寻优范围：${useSphere ? '设计球内（半径 = 数据最外圈）' : '因子上下界立方体'}。单次观测区间由每次预测值再叠加一个留一残差得到。</p>`;
    st.textContent = '已完成';
    toast(`Bootstrap 完成：${preds.length} 次重采样`);
  } catch (e) {
    console.error(e);
    body.innerHTML = `<p class="sig-verdict warn">Bootstrap 失败：${escHtml(e.message)}</p>`;
    st.textContent = '失败';
  } finally {
    btn.disabled = false; btn.textContent = old;
  }
}

// ---------- 置换重要性 ----------
async function runImportance() {
  const d = sigDataset();
  if (!d) { toast('请先导入数据'); return; }
  const btn = $('#imp-run'), st = $('#imp-state'), body = $('#imp-body');
  const old = btn.textContent;
  btn.disabled = true; btn.textContent = '计算中…';
  const wait = ms => new Promise(r => setTimeout(r, ms));
  try {
    if (!State.model) { st.textContent = '训练 SVR…'; await trainModel(); }
    const m = State.model;
    const p = d.X[0].length, n = d.y.length;
    const folds = 5;
    const repeats = n > 40 ? 1 : 2;
    const perms = p > 4 ? 19 : 29;
    const fit = (Xtr, ytr) => {
      const mod = ML.trainSVR(Xtr, ytr, { C: m.C, gamma: m.gamma, eps: m.eps, standardize: true });
      return x => mod.predict(x);
    };
    const meanCV = () => {
      let s = 0, k = 0;
      for (let r = 0; r < repeats; r++) { const v = STATS.cvR2(d.X, d.y, fit, folds); if (isFinite(v)) { s += v; k++; } }
      return k ? s / k : NaN;
    };

    st.textContent = '基线交叉验证…'; await wait(20);
    const base = meanCV();
    if (!isFinite(base)) throw new Error('基线交叉验证失败');

    const names = State.dataset.xIdx.map(i => State.dataset.headers[i] || ('X' + i));
    const results = [];
    for (let j = 0; j < p; j++) {
      const drops = [];
      for (let t = 0; t < perms; t++) {
        const Xp = d.X.map(row => row.slice());
        const col = Xp.map(r => r[j]);
        for (let i = col.length - 1; i > 0; i--) { const k = Math.floor(rnd() * (i + 1)); [col[i], col[k]] = [col[k], col[i]]; }
        Xp.forEach((r, i) => { r[j] = col[i]; });
        let s = 0, k = 0;
        for (let r = 0; r < repeats; r++) {
          const v = STATS.cvR2(Xp, d.y, fit, folds);
          if (isFinite(v)) { s += v; k++; }
        }
        if (k) drops.push(base - s / k);
        if (t % 5 === 0) { st.textContent = `因子 ${j + 1}/${p}：第 ${t + 1}/${perms} 次`; await wait(0); }
      }
      const meanDrop = drops.reduce((a, b) => a + b, 0) / Math.max(drops.length, 1);
      const ge = drops.filter(v => v <= 0).length;
      results.push({
        name: names[j], label: sigShort(names[j]), drop: meanDrop,
        p: (ge + 1) / (perms + 1), perms: drops.length
      });
    }

    results.sort((a, b) => b.drop - a.drop);
    const maxDrop = Math.max(...results.map(r => Math.max(r.drop, 0)), 1e-9);
    const rows = results.map((r, i) => {
      const pct = Math.max(0, r.drop) / maxDrop * 100;
      const sig = r.p < 0.05;
      return `<tr>
        <td>${i + 1}</td>
        <td title="${escHtml(r.name)}">${escHtml(r.label)}</td>
        <td>${r.drop.toFixed(4)}</td>
        <td>
          <div style="background:#eef4fd;border-radius:4px;height:8px;min-width:90px">
            <div style="width:${pct.toFixed(1)}%;background:${sig ? '#2f7ef5' : '#c7d3e3'};height:8px;border-radius:4px"></div>
          </div>
        </td>
        <td>${pct.toFixed(0)}%</td>
        <td>${r.p.toFixed(3)}</td>
        <td>${sig ? '***'.slice(0, r.p < 0.001 ? 3 : r.p < 0.01 ? 2 : 1) : ''}</td>
      </tr>`;
    }).join('');

    const top = results[0];
    const weak = results.filter(r => r.p >= 0.05).length;
    body.innerHTML = `
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>#</th><th>因子</th><th>ΔR²（打乱后下降）</th><th>相对重要性</th><th>占比</th><th>P 值</th><th></th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
      <p class="sig-verdict good" style="margin-top:12px">
        最重要的因子是 <b>${escHtml(top.label)}</b>：打乱后交叉验证 R² 平均下降 <b>${top.drop.toFixed(4)}</b>（P=${top.p.toFixed(3)}）；
        基线交叉验证 R² = ${base.toFixed(4)}。
        ${weak ? `${weak}/${results.length} 个因子的 P ≥ 0.05，未达显著——说明这套数据里因子效应较弱，或样本量不足以支撑该显著性水平。` : '所有因子的 P 均 &lt; 0.05，即每个因子都对预测有实质贡献。'}
      </p>
      <p class="sig-note">方法：每个因子随机置换 ${perms} 次，每次重跑 ${repeats} 次 × ${folds} 折交叉验证；ΔR² = 基线 R² − 置换后 R²；P 值为“置换后 R² 不低于基线”的比例（置换 ${perms} 次时 P 的下限约为 ${(1 / (perms + 1)).toFixed(3)}）。</p>`;
    st.textContent = '已完成';
    toast('重要性分析完成');
  } catch (e) {
    console.error(e);
    body.innerHTML = `<p class="sig-verdict warn">分析失败：${escHtml(e.message)}</p>`;
    st.textContent = '失败';
  } finally {
    btn.disabled = false; btn.textContent = old;
  }
}

// ---------- 残差诊断 ----------
function normInv(p) {
  let lo = -8, hi = 8;
  for (let i = 0; i < 80; i++) {
    const mid = (lo + hi) / 2;
    if (STATS.normCdf(mid) < p) lo = mid; else hi = mid;
  }
  return (lo + hi) / 2;
}

function diagScatter(cv, o) {
  if (!cv) return;
  const dpr = window.devicePixelRatio || 1;
  const host = cv.parentElement;
  const W = Math.max(Math.round((host && host.clientWidth) || 0), 240);
  const H = 250;
  cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
  cv.style.height = H + 'px';
  const ctx = cv.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);

  const pts = o.pts.filter(p => isFinite(p[0]) && isFinite(p[1]));
  if (!pts.length) return;
  const pad = { l: 46, r: 14, t: 12, b: 34 };
  const pw = W - pad.l - pad.r, ph = H - pad.t - pad.b;
  const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]);
  let x0 = Math.min(...xs), x1 = Math.max(...xs);
  let y0 = Math.min(...ys), y1 = Math.max(...ys);
  if (o.centerY) { const m = (Math.max(Math.abs(y0), Math.abs(y1)) * 1.15) || 1; y0 = -m; y1 = m; }
  if (x0 === x1) { x0 -= 1; x1 += 1; }
  if (y0 === y1) { y0 -= 1; y1 += 1; }
  const py = (y1 - y0) * 0.08; y0 -= py; y1 += py;
  const X = v => pad.l + ((v - x0) / (x1 - x0)) * pw;
  const Y = v => pad.t + ph - ((v - y0) / (y1 - y0)) * ph;

  ctx.font = '11px system-ui, -apple-system, sans-serif';
  for (let i = 0; i <= 4; i++) {
    const xv = x0 + (x1 - x0) * i / 4, yv = y0 + (y1 - y0) * i / 4;
    ctx.strokeStyle = '#eef2f8'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(X(xv), pad.t); ctx.lineTo(X(xv), pad.t + ph); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(pad.l, Y(yv)); ctx.lineTo(pad.l + pw, Y(yv)); ctx.stroke();
    ctx.fillStyle = '#9aa6b8'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText(Math.abs(x1) < 10 ? xv.toFixed(1) : xv.toFixed(0), X(xv), pad.t + ph + 6);
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    ctx.fillText(Math.abs(y1) < 10 ? yv.toFixed(1) : yv.toFixed(0), pad.l - 6, Y(yv));
  }

  ctx.fillStyle = '#7b8a9e'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
  ctx.fillText(o.xLab || '', pad.l + pw / 2, H - 3);
  ctx.save();
  ctx.translate(11, pad.t + ph / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText(o.yLab || '', 0, 0);
  ctx.restore();

  if (o.refLine === 'zero') {
    ctx.save();
    ctx.setLineDash([5, 4]); ctx.strokeStyle = '#e2574c'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(pad.l, Y(0)); ctx.lineTo(pad.l + pw, Y(0)); ctx.stroke();
    ctx.restore();
  } else if (o.refLine === 'fit') {
    const n = pts.length;
    const mx = xs.reduce((a, b) => a + b, 0) / n, my = ys.reduce((a, b) => a + b, 0) / n;
    let sxy = 0, sxx = 0;
    pts.forEach(p => { sxy += (p[0] - mx) * (p[1] - my); sxx += (p[0] - mx) ** 2; });
    const b = sxx ? sxy / sxx : 0, a = my - b * mx;
    ctx.save();
    ctx.setLineDash([5, 4]); ctx.strokeStyle = '#e2574c'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(X(x0), Y(a + b * x0)); ctx.lineTo(X(x1), Y(a + b * x1)); ctx.stroke();
    ctx.restore();
  }

  ctx.fillStyle = '#2f7ef5';
  for (const p of pts) {
    ctx.beginPath();
    ctx.arc(X(p[0]), Y(p[1]), 3, 0, Math.PI * 2);
    ctx.fill();
  }
}

async function runDiagnostics() {
  const d = sigDataset();
  if (!d) { toast('请先导入数据'); return; }
  const btn = $('#diag-run'), st = $('#diag-state'), body = $('#diag-body');
  const old = btn.textContent;
  btn.disabled = true; btn.textContent = '计算中…';
  try {
    if (!State.model) { st.textContent = '训练 SVR…'; await trainModel(); }
    const m = State.model;
    st.textContent = '计算留一残差…';
    await new Promise(r => setTimeout(r, 20));
    const loo = svrLooPredictions(d.X, d.y, m);
    const resid = d.y.map((v, i) => v - loo[i]);
    const n = resid.length;
    const mean = resid.reduce((a, b) => a + b, 0) / n;
    const sd = Math.sqrt(resid.reduce((s, r) => s + (r - mean) ** 2, 0) / Math.max(n - 1, 1)) || 1e-9;
    const z = resid.map(r => (r - mean) / sd);
    const skew = z.reduce((s, v) => s + v ** 3, 0) * n / Math.max((n - 1) * (n - 2), 1);

    const order = resid.map((_, i) => i).sort((a, b) => resid[a] - resid[b]);
    const ptsNorm = order.map((id, k) => [normInv((k + 1 - 0.375) / (n + 0.25)), z[id]]);
    const mq = ptsNorm.reduce((s, p) => s + p[0], 0) / n;
    const mz = ptsNorm.reduce((s, p) => s + p[1], 0) / n;
    const rNorm = ptsNorm.reduce((s, p) => s + (p[0] - mq) * (p[1] - mz), 0) /
      Math.sqrt(ptsNorm.reduce((s, p) => s + (p[0] - mq) ** 2, 0) * ptsNorm.reduce((s, p) => s + (p[1] - mz) ** 2, 0) || 1e-12);

    diagScatter($('#diag-norm'), { pts: ptsNorm, xLab: '理论分位数', yLab: '标准化残差', refLine: 'fit' });
    diagScatter($('#diag-pred'), { pts: loo.map((p, i) => [p, resid[i]]), xLab: '预测值', yLab: '残差', refLine: 'zero', centerY: true });
    diagScatter($('#diag-order'), { pts: resid.map((v, i) => [i + 1, v]), xLab: '运行序号', yLab: '残差', refLine: 'zero', centerY: true });

    const maxAbs = Math.max(...resid.map(Math.abs));
    const okNorm = rNorm > 0.95;
    const okSkew = Math.abs(skew) < 1;
    st.textContent = '已完成';
    body.innerHTML = `
      <p class="sig-verdict ${okNorm && okSkew ? 'good' : 'warn'}">
        残差标准差 = <b>${sd.toFixed(2)}</b>；偏度 = <b>${skew.toFixed(2)}</b>；正态概率图相关系数 R = <b>${rNorm.toFixed(4)}</b>；
        最大绝对残差 = ${maxAbs.toFixed(1)}。
        ${okNorm ? 'R &gt; 0.95，残差近似正态，满足回归类模型的常用假设。' : 'R ≤ 0.95，残差偏离正态，建议检查异常点或对响应做变换。'}
        ${Math.abs(skew) >= 1 ? '偏度较大，提示残差分布不对称。' : ''}
      </p>
      <p class="sig-note">判读：①正态概率图上的点越贴近虚线越接近正态；②残差 vs 预测值应呈随机散布、无明显喇叭形（异方差）；③残差 vs 运行序号若出现趋势，说明存在时间漂移或顺序效应。以上均为留一法残差。</p>`;
    toast('残差诊断完成');
  } catch (e) {
    console.error(e);
    body.innerHTML = `<p class="sig-verdict warn">诊断失败：${escHtml(e.message)}</p>`;
    st.textContent = '失败';
  } finally {
    btn.disabled = false; btn.textContent = old;
  }
}

function bindSig() {
  if (!$('#sig-run')) return;
  $('#sig-run').addEventListener('click', () => renderSig({ button: true, notify: true }));
  $('#sig-select').addEventListener('change', renderSig);
  $('#sig-alpha').addEventListener('change', renderSig);
  $('#sig-export').addEventListener('click', exportSig);
  $('#sig-perm').addEventListener('click', runSigPerm);
  const modeSel = $('#sig-coding-mode');
  if (modeSel) modeSel.addEventListener('change', () => {
    if (modeSel.value === 'manual') renderSigCoding();
    renderSig();
  });
  const guess = $('#sig-coding-guess');
  if (guess) guess.addEventListener('click', () => {
    const d = sigDataset();
    if (!d) { toast('请先导入数据'); return; }
    State.sigCoding = null;
    renderSigCoding();
    renderSig();
    toast('已按标准 CCD（α=1.682）推算 x0 与 Δx');
  });
  const cmp = $('#cmp-run');
  if (cmp) cmp.addEventListener('click', runCompare);
  const boot = $('#boot-run');
  if (boot) boot.addEventListener('click', runBootstrap);
  const imp = $('#imp-run');
  if (imp) imp.addEventListener('click', runImportance);
  const diag = $('#diag-run');
  if (diag) diag.addEventListener('click', runDiagnostics);
}

window.addEventListener('error', ev => {
  try {
    if (typeof pushLogLine === 'function') pushLogLine('!! 运行出错：' + (ev.message || ev.error));
    if (typeof toast === 'function') toast('运行出错：' + (ev.message || ev.error), 6000);
  } catch (e) { }
});
window.addEventListener('unhandledrejection', ev => {
  try {
    const msg = (ev.reason && ev.reason.message) || ev.reason;
    if (typeof pushLogLine === 'function') pushLogLine('!! 异步出错：' + msg);
    if (typeof toast === 'function') toast('运行出错：' + msg, 6000);
  } catch (e) { }
});
document.addEventListener('DOMContentLoaded', () => {
  bind();
  bindSig();
  bindRoles();
  dwBind();
  renderLogEmpty();
  bindDataAnalysis();
  bindDaTabs();
  bindRangeFill();
  renderAlgo();
  setRing(0);
  setSeed(null);
  refreshChecklist();
  setDataset(makeDemoDataset());   // 预置示例数据，便于直接体验
  renderPlan();
  renderFactorTool();
  renderNotices();
  navigate('home');
});

// ---------- 数据管理向导（方案设计 → 响应设置 → 试验表 → 预览） ----------
const DW = { step: 1, k: 3, design: null };

function dwGo(step) {
  DW.step = step;
  ['1', '2', '3', '4'].forEach(s => {
    const el = $('#dstep-' + s);
    if (el) el.hidden = String(s) !== String(step);
    const btn = document.querySelector('.step-btn[data-step="' + s + '"]');
    if (btn) {
      btn.classList.toggle('active', String(s) === String(step));
      btn.classList.toggle('done', Number(s) < Number(step));
    }
  });
  $('#main').scrollTop = 0;
}

function dwFactorInputs() {
  const k = parseInt($('#d-k').value, 10) || 3;
  const out = [];
  for (let i = 0; i < k; i++) {
    const name = ($('#df-name-' + i) && $('#df-name-' + i).value.trim()) || ('X' + (i + 1));
    const unit = ($('#df-unit-' + i) && $('#df-unit-' + i).value.trim()) || '';
    const low = finiteCell($('#df-low-' + i) && $('#df-low-' + i).value);
    const high = finiteCell($('#df-high-' + i) && $('#df-high-' + i).value);
    out.push({ name, unit, low, high });
  }
  return out;
}

function dwRenderFactorTable() {
  const k = parseInt($('#d-k').value, 10) || 3;
  const old = [];
  for (let i = 0; i < 6; i++) {
    old.push({
      name: ($('#df-name-' + i) || {}).value,
      unit: ($('#df-unit-' + i) || {}).value,
      low: ($('#df-low-' + i) || {}).value,
      high: ($('#df-high-' + i) || {}).value
    });
  }
  let head = '<thead><tr><th>因子</th><th>名称</th><th>单位</th><th>下限</th><th>上限</th></tr></thead><tbody>';
  let body = '';
  for (let i = 0; i < k; i++) {
    const o = old[i] || {};
    const letter = String.fromCharCode(65 + i);
    body += `<tr>
      <td>${letter}</td>
      <td><input id="df-name-${i}" value="${escHtml(String(o.name !== undefined ? o.name : 'X' + (i + 1)))}"></td>
      <td><input id="df-unit-${i}" value="${escHtml(String(o.unit !== undefined ? o.unit : '%'))}"></td>
      <td><input id="df-low-${i}" type="number" step="any" value="${escHtml(String(o.low !== undefined ? o.low : 1))}"></td>
      <td><input id="df-high-${i}" type="number" step="any" value="${escHtml(String(o.high !== undefined ? o.high : 3))}"></td>
    </tr>`;
  }
  $('#d-factor-table').innerHTML = head + body + '</tbody>';
}

function dwAlpha() {
  const k = parseInt($('#d-k').value, 10) || 3;
  const mode = $('#d-alpha').value;
  if (mode === 'spherical') return Math.sqrt(k);
  if (mode === 'face') return 1;
  if (mode === 'custom') return finiteCell($('#d-alpha-custom').value);
  return Math.pow(2, k / 4);          // 可旋转
}

function dwShuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function dwGenerate() {
  Engine.seed(State.settings.seed ?? 42, 'design-generation');
  const type = $('#d-type').value;
  const k = parseInt($('#d-k').value, 10) || 3;
  const n0 = Math.max(0, parseInt($('#d-center').value, 10) || 0);
  const factors = dwFactorInputs();
  const bad = factors.filter(f => !(f.high > f.low));
  if (bad.length) { toast('因子的上限必须大于下限：' + bad.map(f => f.name).join('、')); return; }

  const alpha = type === 'CCD' ? dwAlpha() : 0;
  if (!(Number.isInteger(k) && k >= 2 && k <= 6 && Number.isInteger(n0) && n0 >= 0 && n0 <= 50) || (type === 'CCD' && !(Number.isFinite(alpha) && alpha > 0 && alpha <= 5))) { toast('因子数、中心点数或 Alpha 超出有效范围'); return; }
  const codes = [];
  if (type === 'CCD') {
    for (let m = 0; m < (1 << k); m++) {
      const c = [];
      for (let j = 0; j < k; j++) c.push((m >> j) & 1 ? 1 : -1);
      codes.push(c);
    }
    for (let j = 0; j < k; j++) {
      const c1 = new Array(k).fill(0); c1[j] = alpha; codes.push(c1);
      const c2 = new Array(k).fill(0); c2[j] = -alpha; codes.push(c2);
    }
  } else {
    if (k < 3) { toast('BBD 需要 3 个及以上因子'); return; }
    for (let i = 0; i < k; i++) for (let j = i + 1; j < k; j++) {
      [[1, 1], [1, -1], [-1, 1], [-1, -1]].forEach(([a, b]) => {
        const c = new Array(k).fill(0); c[i] = a; c[j] = b; codes.push(c);
      });
    }
  }
  for (let c = 0; c < n0; c++) codes.push(new Array(k).fill(0));

  const runs = codes.map((c, idx) => ({ std: idx + 1, codes: c }));
  if ($('#d-rand').value === '1') dwShuffle(runs);
  runs.forEach((r, i) => {
    r.run = i + 1;
    r.actual = r.codes.map((c, j) => {
      const f = factors[j];
      const mid = (f.low + f.high) / 2;
      const step = (f.high - f.low) / 2;
      return +(mid + c * step).toFixed(6);
    });
    r.resp = '';
  });

  DW.design = { type, k, n0, alpha, factors, runs };
  const total = runs.length;
  const pts = type === 'CCD'
    ? `${Math.pow(2, k)} 析因 + ${2 * k} 轴点 + ${n0} 中心`
    : `${2 * k * (k - 1)} 边中点 + ${n0} 中心`;
  $('#design-info').textContent = `${type} · ${k} 因子 · ${total} 次运行`;
  $('#d-hint').textContent = `已生成：${pts}（α = ${type === 'CCD' ? alpha.toFixed(3) : '—'}）`;
  $('#d-runs').textContent = `共 ${total} 次运行 · α = ${type === 'CCD' ? alpha.toFixed(3) : '—'}`;
  if (!$('#f-name').value) $('#f-name').value = `${type}_${k}因子设计`;
  dwGo(2);
}

function dwRenderRuns() {
  const D = DW.design;
  if (!D) return;
  const names = D.factors.map(f => f.name + (f.unit ? '(' + f.unit + ')' : ''));
  const respName = ($('#f-resp-name') && $('#f-resp-name').value.trim()) || '响应';
  const unit = ($('#f-unit') && $('#f-unit').value.trim()) || '';
  let head = '<thead><tr><th>Std</th><th>Run</th>' + names.map(n => `<th>${escHtml(n)}</th>`).join('') +
    `<th>${escHtml(respName)}${unit ? ' (' + escHtml(unit) + ')' : ''}</th></tr></thead><tbody>`;
  let body = '';
  D.runs.forEach((r, i) => {
    body += `<tr><td>${r.std}</td><td>${r.run}</td>` +
      r.actual.map(v => `<td>${v}</td>`).join('') +
      `<td><input class="resp-cell" id="dr-resp-${i}" type="number" step="any" value="${r.resp === '' ? '' : r.resp}"></td></tr>`;
  });
  $('#d-run-table').innerHTML = head + body + '</tbody>';
  $('#d-run-count').textContent = `共 ${D.runs.length} 次运行`;
}

function dwCollectResp() {
  const D = DW.design;
  let miss = 0;
  D.runs.forEach((r, i) => {
    const el = $('#dr-resp-' + i);
    const v = el ? finiteCell(el.value) : NaN;
    r.resp = isFinite(v) ? v : '';
    if (r.resp === '') miss++;
  });
  return miss;
}

function dwFinish() {
  const D = DW.design;
  if (!D) { toast('请先生成试验方案'); return; }
  const miss = dwCollectResp();
  if (miss) { toast(`还有 ${miss} 行没有填响应值（可手动填或点「导入响应数据」）`, 3500); return; }

  const respName = ($('#f-resp-name') && $('#f-resp-name').value.trim()) || '响应';
  const unit = ($('#f-unit') && $('#f-unit').value.trim()) || '';
  const headers = D.factors.map(f => f.name + (f.unit ? '(' + f.unit + ')' : '')).concat([respName + (unit ? ' (' + unit + ')' : '')]);
  const rows = D.runs.map(r => r.actual.concat([r.resp]));
  const ds = {
    headers, rows,
    xIdx: D.factors.map((_, i) => i),
    yIdx: D.factors.length,
    numericIdx: headers.map((_, i) => i),
    roles: headers.map((_, i) => (i === D.factors.length ? 'y' : 'x')),
    name: ($('#f-name') && $('#f-name').value.trim()) || (D.type + '设计'),
    unit: unit || 'kPa'
  };
  window.saveMeta();
  setDataset(ds);
  renderPlan();
  dwGo(4);
  toast(`已生成数据集：${rows.length} 次运行`);
  pushNotice(`方案设计完成：${ds.name}（${rows.length} 次运行）`);
}

async function dwImportResponses(file) {
  try {
    const grid = await DataIO.readFile(file);
    if (!grid || grid.length < 2) throw new Error('文件为空');
    const head = grid[0].map(x => String(x || ''));
    const body = grid.slice(1).filter(r => r.some(v => String(v).trim() !== ''));
    const D = DW.design;
    if (!D) { toast('请先生成试验方案'); return; }
    if (body.length !== D.runs.length) {
      throw new Error(`行数不一致：试验表 ${D.runs.length} 行，文件 ${body.length} 行`);
    }
    let col = head.findIndex(h => /响应|response|qu|强度|y$/i.test(h));
    if (col < 0) col = head.length - 1;
    const vals = body.map(r => finiteCell(r[col]));
    if (vals.some(v => !isFinite(v))) throw new Error('响应列存在非数值');
    vals.forEach((v, i) => { D.runs[i].resp = v; });
    dwRenderRuns();
    toast(`已导入 ${vals.length} 个响应值`);
    pushNotice(`响应数据导入成功：${file.name}`);
  } catch (e) {
    toast('导入失败：' + e.message, 4000);
  }
}

function dwBind() {
  if (!$('#d-factor-table')) return;
  dwRenderFactorTable();
  $('#d-k').addEventListener('change', dwRenderFactorTable);
  $('#d-type').addEventListener('change', () => {
    $('#d-alpha-field').style.display = $('#d-type').value === 'CCD' ? '' : 'none';
    $('#d-alpha-custom-field').style.display = ($('#d-type').value === 'CCD' && $('#d-alpha').value === 'custom') ? '' : 'none';
  });
  $('#d-alpha').addEventListener('change', () => {
    $('#d-alpha-custom-field').style.display = $('#d-alpha').value === 'custom' ? '' : 'none';
  });
  $('#d-generate').addEventListener('click', dwGenerate);
  $('#d-prev2').addEventListener('click', () => dwGo(1));
  $('#d-next2').addEventListener('click', () => { dwRenderRuns(); dwGo(3); });
  $('#d-prev3').addEventListener('click', () => dwGo(2));
  $('#d-prev4').addEventListener('click', () => dwGo(3));
  $('#d-tomodel').addEventListener('click', () => { window.saveMeta(); navigate('model'); });
  $('#d-finish').addEventListener('click', dwFinish);
  $('#d-import-resp').addEventListener('click', () => $('#resp-input').click());
  $('#resp-input').addEventListener('change', e => {
    if (e.target.files[0]) dwImportResponses(e.target.files[0]);
    e.target.value = '';
  });
  $$('.step-btn[data-step]').forEach(b => b.addEventListener('click', () => {
    const s = Number(b.dataset.step);
    if (s === 1) dwGo(1);
    else if (!DW.design) { toast('请先在「方案设计」里生成试验方案'); return; }
    else if (s === 2) dwGo(2);
    else if (s === 3) { dwRenderRuns(); dwGo(3); }
    else dwGo(4);
  }));
}

// ---------- 按数据范围填充优化上下界 ----------
function bindRangeFill() {
  const btn = $('#o-fill-range');
  if (!btn) return;
  btn.addEventListener('click', () => {
    const ds = State.dataset;
    if (!ds || !ds.xIdx || !ds.xIdx.length) { toast('请先导入数据'); return; }
    const k = ds.xIdx.length;
    const lb = [], ub = [];
    for (let j = 0; j < k; j++) {
      const col = ds.rows.map(r => parseFloat(r[ds.xIdx[j]])).filter(isFinite);
      if (!col.length) { toast('第 ' + (j + 1) + ' 个因子没有数值'); return; }
      lb.push(Math.min(...col));
      ub.push(Math.max(...col));
    }
    const fmt = v => String(+v.toFixed(4));
    $('#o-lb').value = lb.map(fmt).join(',');
    $('#o-ub').value = ub.map(fmt).join(',');
    const hint = $('#o-range-hint');
    if (hint) hint.textContent = '已按数据范围填充：' + lb.map((v, i) => fmt(v) + ' – ' + fmt(ub[i])).join('；');
    toast('已按数据范围填充上下界');
  });
}

// ---------- 数据分析：迭代结果（带色标）+ 方差分析 ----------
function iterColor(t) {
  const stops = [[47, 95, 208], [74, 158, 232], [142, 201, 107], [245, 210, 74], [240, 145, 63], [216, 74, 58]];
  const x = Math.max(0, Math.min(1, t)) * (stops.length - 1);
  const i = Math.floor(x), fr = x - i;
  const a = stops[i], b = stops[Math.min(i + 1, stops.length - 1)];
  return 'rgb(' + Math.round(a[0] + (b[0] - a[0]) * fr) + ',' +
    Math.round(a[1] + (b[1] - a[1]) * fr) + ',' +
    Math.round(a[2] + (b[2] - a[2]) * fr) + ')';
}

function drawIterChart(hist, algo, bestY) {
  const cv = $('#chart-line');
  if (!cv || !hist || !hist.length) return;
  const dpr = window.devicePixelRatio || 1;
  const W = cv.clientWidth || 640, H = 300;
  cv.width = W * dpr; cv.height = H * dpr;
  const ctx = cv.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);

  const pad = { l: 58, r: 14, t: 16, b: 34 };
  const iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
  const vmin = Math.min(...hist), vmax = Math.max(...hist);
  const span = (vmax - vmin) || 1;
  const yLo = vmin - span * 0.08, yHi = vmax + span * 0.08;
  const sx = i => pad.l + (hist.length === 1 ? iw / 2 : (i / (hist.length - 1)) * iw);
  const sy = v => pad.t + ih - ((v - yLo) / (yHi - yLo)) * ih;

  // 网格 + y 轴刻度
  ctx.strokeStyle = '#eef3fb'; ctx.lineWidth = 1; ctx.font = '11px ui-sans-serif'; ctx.fillStyle = '#8a99ad';
  for (let k = 0; k <= 4; k++) {
    const v = yLo + (yHi - yLo) * k / 4, y = sy(v);
    ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(W - pad.r, y); ctx.stroke();
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    ctx.fillText(fmt(v, 1), pad.l - 8, y);
  }
  // x 轴
  ctx.strokeStyle = '#c9d7ea';
  ctx.beginPath(); ctx.moveTo(pad.l, pad.t + ih); ctx.lineTo(W - pad.r, pad.t + ih); ctx.stroke();
  ctx.textAlign = 'center'; ctx.textBaseline = 'top';
  const xt = Math.min(6, hist.length);
  for (let k = 0; k < xt; k++) {
    const i = Math.round(k * (hist.length - 1) / Math.max(1, xt - 1));
    ctx.fillText(String(i), sx(i), pad.t + ih + 8);
  }
  ctx.fillText('迭代次数', pad.l + iw / 2, pad.t + ih + 22);

  // 折线
  ctx.strokeStyle = '#b9cdf0'; ctx.lineWidth = 1.6;
  ctx.beginPath(); hist.forEach((v, i) => { i ? ctx.lineTo(sx(i), sy(v)) : ctx.moveTo(sx(i), sy(v)); }); ctx.stroke();

  // 数据点（颜色随数值变化）
  hist.forEach((v, i) => {
    const t = (v - vmin) / span;
    ctx.beginPath(); ctx.arc(sx(i), sy(v), 3.2, 0, Math.PI * 2);
    ctx.fillStyle = iterColor(t); ctx.fill();
  });

  // 最优点
  const bi = Math.max(0, hist.findIndex(v => Math.abs(v - bestY) <= 1e-9 * Math.max(1, Math.abs(bestY))));
  ctx.beginPath(); ctx.arc(sx(bi), sy(bestY), 6.5, 0, Math.PI * 2);
  ctx.strokeStyle = '#d84a3a'; ctx.lineWidth = 2; ctx.stroke();
  ctx.fillStyle = '#d84a3a'; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
  ctx.font = '11.5px ui-sans-serif';
  ctx.fillText('候选 ' + fmt(bestY, 1) + ' @第' + bi + '代', Math.min(sx(bi) + 10, W - 120), sy(bestY) - 6);

  // 色标上下限
  if ($('#iter-max')) $('#iter-max').textContent = fmt(vmax, 1);
  if ($('#iter-min')) $('#iter-min').textContent = fmt(vmin, 1);
  if ($('#iter-cap')) $('#iter-cap').textContent = algo + ' · ' + (hist.length-1) + ' 次迭代 · 候选 ' + fmt(bestY, 2) + ' ' + (State.result?.unit || '');
}

function renderDaAnova() {
  const tbl = $('#da-anova');
  if (!tbl) return;
  const ds = State.dataset;
  if (!ds) { tbl.innerHTML = '<tbody><tr><td style="color:#9aa6b8;padding:14px">请先在「数据管理」中导入或生成数据</td></tr></tbody>'; return; }
  const { X, y } = getXY();
  const names = ds.xIdx.map((ci, i) => ds.headers[ci] || ('X' + (i + 1)));
  let r;
  try { r = STATS.analyze(X, y, { names, select: 'none' }); }
  catch (e) { tbl.innerHTML = '<tbody><tr><td style="color:#c0392b;padding:14px">方差分析失败：' + escHtml(e.message) + '</td></tr></tbody>'; return; }

  const row = (a, b, c, d, e, f, cls) => '<tr' + (cls ? ' class="' + cls + '"' : '') + '>' +
    '<td>' + a + '</td><td>' + b + '</td><td>' + c + '</td><td>' + d + '</td><td>' + e + '</td><td>' + f + '</td></tr>';
  let html = '<thead><tr><th>来源</th><th>SS</th><th>df</th><th>MS</th><th>F</th><th>P</th></tr></thead><tbody>';
  html += row('<b>模型</b>', fmt(r.ssModel, 1), r.dfModel, fmt(r.msModel, 1), fmt(r.Fmodel, 2), sigPText(r.pModel), 'model-row');
  (r.termStats || []).forEach(s => {
    html += row(escHtml(s.label), fmt(s.ss, 2), 1, fmt(s.ss, 2), fmt(s.F, 2), fmt(s.p, 4));
  });
  html += row('残差', fmt(r.ssResid, 1), r.dfResid, fmt(r.msResid, 1), '—', '—');
  if (r.lackOfFit) {
    html += row('　失拟', fmt(r.lackOfFit.ssLOF, 1), r.lackOfFit.dfLOF, fmt(r.lackOfFit.ssLOF / Math.max(1, r.lackOfFit.dfLOF), 1), fmt(r.lackOfFit.F, 2), sigPText(r.lackOfFit.p));
    html += row('　纯误差', fmt(r.lackOfFit.ssPE, 1), r.lackOfFit.dfPE, fmt(r.lackOfFit.ssPE / Math.max(1, r.lackOfFit.dfPE), 1), '—', '—');
  }
  html += row('<b>总和</b>', fmt(r.ssModel + r.ssResid, 1), r.n - 1, '—', '—', '—');
  html += '</tbody>';
  tbl.innerHTML = html;

  if ($('#da-anova-state')) $('#da-anova-state').textContent = 'R² = ' + fmt(r.r2, 4) + ' · 调整 R² = ' + fmt(r.adjR2, 4);
  if ($('#da-anova-note')) {
    $('#da-anova-note').innerHTML = '模型 F = <b>' + fmt(r.Fmodel, 2) + '</b>，P = ' + sigPText(r.pModel) +
      '；近似信噪比 = ' + fmt(r.adeq, 1) + '，C.V. = ' + fmt(r.cvPct, 2) + '%' +
      '。该表为<b>全项模型</b>（不做剔除），用于与 SVR 对照；带剔除记录与 VIF 的完整版本见「显著性分析」页。';
  }
}

function bindDataAnalysis() {
  const btn = $('#da-anova-run');
  if (btn) btn.addEventListener('click', renderDaAnova);
  if ($('#da-anova') && State.dataset) renderDaAnova();
}

// ---------- 数据分析：三个子页签 ----------
function daGo(tab) {
  ['iter', 'anova', 'viz', 'sig'].forEach(t => {
    const el = document.getElementById('dap-' + t);
    if (el) el.hidden = (t !== tab);
    const b = document.querySelector('.step-btn[data-da="' + t + '"]');
    if (b) b.classList.toggle('active', t === tab);
  });
  document.body.classList.toggle('pdp-wide', tab === 'viz');
  const m = document.getElementById('main');
  if (m) m.scrollTop = 0;
  if (tab === 'iter' && State.result) renderResult();
  if (tab === 'anova') renderDaAnova();
  if (tab === 'sig' && State.dataset && !State.sig) renderSig();
  if (tab === 'viz') {
    if (State.model && !State.pdp) { renderFactorTool(); recomputeSurface(false); }
    else if (State.pdp && typeof renderPdp === 'function') setTimeout(() => { renderPdp(); }, 30);
  }
  requestAnimationFrame(redrawCharts);
}

function bindDaTabs() {
  document.querySelectorAll('.step-btn[data-da]').forEach(b => {
    b.addEventListener('click', () => daGo(b.dataset.da));
  });
  const btn = document.getElementById('da-anova-run');
  if (btn) btn.addEventListener('click', () => {
    renderDaAnova();
    toast('验证摘要已刷新');
  });
}

// 数据变化时按数据范围自动填寻优上下界，避免外推
function autoFillBounds(ds) {
  const lbEl = document.getElementById('o-lb'), ubEl = document.getElementById('o-ub');
  if (!lbEl || !ubEl || !ds || !ds.xIdx) return;
  const lb = [], ub = [];
  for (let j = 0; j < ds.xIdx.length; j++) {
    const col = ds.rows.map(r => parseFloat(r[ds.xIdx[j]])).filter(isFinite);
    if (!col.length) return;
    lb.push(Math.min(...col)); ub.push(Math.max(...col));
  }
  const fmt = v => String(+v.toFixed(4));
  lbEl.value = lb.map(fmt).join(',');
  ubEl.value = ub.map(fmt).join(',');
  const hint = document.getElementById('o-range-hint');
  if (hint) hint.textContent = '已按数据范围自动填充：' + lb.map((v, i) => fmt(v) + ' – ' + fmt(ub[i])).join('；');
}
