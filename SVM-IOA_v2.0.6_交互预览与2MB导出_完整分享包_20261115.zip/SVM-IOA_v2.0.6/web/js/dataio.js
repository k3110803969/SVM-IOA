// ---------- 数据导入 / 导出 ----------
const DataIO = (() => {

  function parseCSV(text) {
    text = text.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    const rows = [];
    let row = [], field = '', inQ = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (inQ) {
        if (c === '"') {
          if (text[i + 1] === '"') { field += '"'; i++; }
          else inQ = false;
        } else field += c;
      } else {
        if (c === '"') inQ = true;
        else if (c === ',') { row.push(field); field = ''; }
        else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
        else field += c;
      }
    }
    if (inQ) throw new Error('CSV 引号未闭合，请检查文件格式');
    if (field.length || row.length) { row.push(field); rows.push(row); }
    return rows.filter(r => r.some(v => String(v).trim() !== ''));
  }

  // ---- 极简 ZIP 读取（xlsx 本质是 zip） ----
  async function unzip(buffer) {
    const dv = new DataView(buffer);
    let eocd = -1;
    const min = Math.max(0, buffer.byteLength - 22 - 65536);
    for (let i = buffer.byteLength - 22; i >= min; i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('非法 zip/xlsx 文件');
    const count = dv.getUint16(eocd + 10, true);
    let off = dv.getUint32(eocd + 16, true);
    const entries = Object.create(null); let expanded = 0;
    for (let k = 0; k < count; k++) {
      if (dv.getUint32(off, true) !== 0x02014b50) break;
      const flags = dv.getUint16(off + 8, true);
      if (flags & 1) throw new Error('不支持加密 XLSX，请先解除密码');
      const method = dv.getUint16(off + 10, true);
      if (method !== 0 && method !== 8) throw new Error('XLSX 压缩方式不受支持');
      expanded += dv.getUint32(off + 24, true);
      if (expanded > 50000000) throw new Error('XLSX 解压后超过 50 MB，请缩小文件');
      let compSize = dv.getUint32(off + 20, true);
      const nameLen = dv.getUint16(off + 28, true);
      const extraLen = dv.getUint16(off + 30, true);
      const commentLen = dv.getUint16(off + 32, true);
      const localOff = dv.getUint32(off + 42, true);
      const name = new TextDecoder().decode(new Uint8Array(buffer, off + 46, nameLen));
      const lnameLen = dv.getUint16(localOff + 26, true);
      const lextraLen = dv.getUint16(localOff + 28, true);
      if (!compSize) compSize = dv.getUint32(localOff + 18, true);
      entries[name] = { method, compSize, dataStart: localOff + 30 + lnameLen + lextraLen };
      off += 46 + nameLen + extraLen + commentLen;
    }
    const out = Object.create(null);
    for (const name in entries) {
      const e = entries[name];
      const raw = new Uint8Array(buffer, e.dataStart, e.compSize);
      if (e.method === 0) out[name] = raw;
      else out[name] = await inflateRaw(raw);
    }
    return out;
  }

  async function inflateRaw(bytes) {
    if (typeof DecompressionStream === 'undefined') {
      throw new Error('当前浏览器不支持解压 xlsx，请改用 CSV 或 Chrome / Edge 打开');
    }
    const ds = new DecompressionStream('deflate-raw');
    const stream = new Blob([bytes]).stream().pipeThrough(ds);
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  const colIndex = (ref) => {
    const m = ref.match(/^[A-Z]+/)[0];
    let n = 0;
    for (const ch of m) n = n * 26 + (ch.charCodeAt(0) - 64);
    return n - 1;
  };

  async function parseXLSX(buffer) {
    const files = await unzip(buffer);
    const dec = new TextDecoder();
    const parser = new DOMParser();

    // 共享字符串
    let shared = [];
    if (files['xl/sharedStrings.xml']) {
      const doc = parser.parseFromString(dec.decode(files['xl/sharedStrings.xml']), 'application/xml');
      shared = Array.from(doc.getElementsByTagName('si')).map(si =>
        Array.from(si.getElementsByTagName('t')).map(t => t.textContent).join('')
      );
    }
    // Resolve the first visible worksheet in workbook order through its relationship.
    let sheetName;
    if(files['xl/workbook.xml'] && files['xl/_rels/workbook.xml.rels']) {
      const wb=parser.parseFromString(dec.decode(files['xl/workbook.xml']),'application/xml');
      const rel=parser.parseFromString(dec.decode(files['xl/_rels/workbook.xml.rels']),'application/xml');
      const sheets=Array.from(wb.getElementsByTagName('sheet'));
      const targets=Array.from(rel.getElementsByTagName('Relationship'));
      for(const sh of sheets) {
        if(sh.getAttribute('state')==='hidden'||sh.getAttribute('state')==='veryHidden')continue;
        const id=sh.getAttribute('r:id')||sh.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id');
        const rr=targets.find(r=>r.getAttribute('Id')===id && /\/worksheet$/.test(r.getAttribute('Type')||''));
        if(rr && rr.getAttribute('TargetMode')!=='External') {sheetName=new URL(rr.getAttribute('Target'),'https://xlsx.local/xl/workbook.xml').pathname.replace(/^\//,'');break;}
      }
    }
    if (!sheetName) throw new Error('xlsx 中未找到工作表');
    if (!files[sheetName]) throw new Error('XLSX 工作簿关系指向不存在的工作表');
    const sheet = parser.parseFromString(dec.decode(files[sheetName]), 'application/xml');
    if (sheet.getElementsByTagName('parsererror').length) throw new Error('XLSX 工作表 XML 损坏');

    const grid = [];
    Array.from(sheet.getElementsByTagName('row')).forEach(rowEl => {
      const r = parseInt(rowEl.getAttribute('r'), 10) - 1;
      if (!Number.isInteger(r) || r < 0 || r > 10000) throw new Error('XLSX 行号超出 10000 行限制');
      const line = grid[r] || (grid[r] = []);
      Array.from(rowEl.getElementsByTagName('c')).forEach(c => {
        const ref=c.getAttribute('r');
        if (!/^[A-Z]+[0-9]+$/.test(ref || '')) throw new Error('XLSX 单元格引用无效');
        const ci = colIndex(ref);
        if (ci >= 50) throw new Error('XLSX 超过 50 列，请先移除多余列');
        if (c.getElementsByTagName('f').length && !c.getElementsByTagName('v')[0]?.textContent.trim()) throw new Error('公式单元格 '+ref+' 没有缓存结果；请在 Excel 重算并保存，或粘贴为数值');
        if (c.getAttribute('t') === 'e') throw new Error('XLSX 单元格 '+ref+' 包含公式错误');
        const t = c.getAttribute('t');
        let val = '';
        if (t === 'inlineStr') {
          const is = c.getElementsByTagName('is')[0];
          val = is ? Array.from(is.getElementsByTagName('t')).map(x => x.textContent).join('') : '';
        } else {
          const v = c.getElementsByTagName('v')[0];
          if (v) {
            val = v.textContent;
            if (t === 's') val = shared[parseInt(val, 10)] || '';
          }
        }
        line[ci] = val;
      });
    });
    return grid.filter(r => r && r.some(v => String(v ?? '').trim() !== ''))
               .map(r => Array.from(r, v => (v === undefined ? '' : v)));
  }

  function toCSV(headers, rows) {
    const esc = v => {
      const s = v === null || v === undefined ? '' : String(v);
      return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    };
    return [headers.map(esc).join(','), ...rows.map(r => r.map(esc).join(','))].join('\n');
  }

  async function readFile(file) {
    if (file.size > 10000000) throw new Error('数据文件超过 10 MB，请先缩小文件');
    const name = file.name.toLowerCase();
    if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
      if (!name.endsWith('.xlsx')) throw new Error('仅支持 .xlsx，请用 Excel 另存为 .xlsx 或 CSV');
      return parseXLSX(await file.arrayBuffer());
    }
    if (!name.endsWith('.csv')) throw new Error('仅支持 CSV 和 XLSX');
    const bytes=await file.arrayBuffer();let text;
    try {text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);} catch(e) {text=new TextDecoder('gb18030',{fatal:true}).decode(bytes);}
    return parseCSV(text);
  }

  return { parseCSV, parseXLSX, toCSV, readFile };
})();

window.DataIO = DataIO;
