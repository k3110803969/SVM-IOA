self.window=self;
importScripts('lib.js','ml.js','stats.js','engine.js');
self.onmessage=async event=>{const {id,task,payload}=event.data;try{const result=await Engine.run(task,payload,p=>self.postMessage({id,progress:p}));self.postMessage({id,result});}catch(e){self.postMessage({id,error:e.message||String(e)});}};
