function interactionContext(result) {
  if (result.mode === 'pdp') return '样本平均（PDP），共 ' + result.sampleCount + ' 条样本';
  if (!result.conditions.length) return '固定因子模式，无其他因子';
  return '固定其他因子　' + result.conditions.map(({name, value}) => name + ' = ' + value).join('，');
}

function clearInteraction(message = '请先计算曲面') {
  $('#pd-interaction-pair').textContent = message;
  $('#pd-interaction-context').textContent = '';
  for (const id of ['pd-h', 'pd-range', 'pd-amp']) $('#' + id).textContent = '—';
  $('#pd-interp').textContent = '';
  $('#pd-interaction-tiff').disabled = true;
  $('#pd-interaction-preview').hidden = true;
}

let interactionPreviewKey = null;
function renderInteraction(result, stats) {
  if (result.request !== _surfaceRequest) return;
  const interaction = PDP.interaction(result.p2.z, result.pj, result.pk);
  const unit = State.dataset.unit ? ' ' + State.dataset.unit : '';
  const names = [ftName(result.j), ftName(result.k)];
  $('#pd-interaction-pair').textContent = names.join(' × ');
  $('#pd-interaction-context').textContent = interactionContext(result);
  $('#pd-h').textContent = fmt(interaction.h2, 3);
  $('#pd-range').textContent = fmt(stats.max - stats.min, 1) + unit;
  $('#pd-amp').textContent = fmt(stats.max, 1) + unit;
  $('#pd-interp').textContent = 'H² 越接近 0，联合预测越接近两个单因子效应之和。红色高于加性基线，蓝色低于基线，白色接近零。';
  const preview = $('#pd-interaction-preview');
  const key = JSON.stringify([result.request, result.levels, unit, ...names]);
  if (key !== interactionPreviewKey) {
    preview.dataset.w = '580';
    drawInteractionContour(preview, result, names, State.dataset.unit, interaction.residual);
    preview.setAttribute('aria-label', names.join(' × ') + ' 交互效应等值图');
    interactionPreviewKey = key;
  }
  preview.hidden = false;
  $('#pd-interaction-tiff').disabled = false;
}

function interactionPalette(t) {
  const edge = t < 0.5 ? [31, 92, 161] : [176, 45, 46];
  const weight = Math.min(1, Math.abs(t * 2 - 1));
  return edge.map(color => Math.round(255 + (color - 255) * weight));
}

function drawInteractionContour(canvas, result, names, unit, residual) {
  const residualStats = PDP.stats(residual);
  const magnitude = Math.max(Math.abs(residualStats.min), Math.abs(residualStats.max));
  const limit = magnitude > 1e-9 ? magnitude : 1;
  Charts.pdp2d(canvas, {
    ...result.p2, z:residual, scale:{min:-limit, max:limit},
    xLabel:names[0], yLabel:names[1], unit:'交互分量' + (unit ? ' (' + unit + ')' : ''),
    levels:result.levels, palette:interactionPalette,
  });
}

function interactionFigure(result, names, unit) {
  const {residual, h2} = PDP.interaction(result.p2.z, result.pj, result.pk);
  const responseStats = PDP.stats(result.p2.z);
  const width = 920;
  const chart = document.createElement('canvas');
  chart.dataset.w = String(width);
  chart.dataset.h = '602';
  chart.dataset.dpr = '3';
  drawInteractionContour(chart, result, names, unit, residual);

  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  const font = ' "Microsoft YaHei", sans-serif';
  const lines = [];
  function addText(text, size, weight = '') {
    ctx.font = weight + size + 'px' + font;
    let line = '';
    for (const char of text) {
      if (line && ctx.measureText(line + char).width > width - 80) {
        lines.push({text:line, size, weight});
        line = '';
      }
      line += char;
    }
    if (line) lines.push({text:line, size, weight});
  }
  addText('SVR 双因子交互效应', 28, 'bold ');
  addText(names.join(' × '), 22, 'bold ');
  addText(interactionContext(result), 16);
  addText('H² = ' + fmt(h2, 3) + '　　响应变化幅度 = ' + fmt(responseStats.max-responseStats.min, 1) + (unit ? ' ' + unit : '') +
    '　　最大预测响应 = ' + fmt(responseStats.max, 1) + (unit ? ' ' + unit : ''), 16);

  const headerHeight = 34 + lines.reduce((height, line) => height + line.size + 11, 0);
  canvas.width = chart.width;
  canvas.height = chart.height + 3 * (headerHeight + 62);
  ctx.scale(3, 3);
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, width, canvas.height / 3);
  ctx.fillStyle = '#132d4a';
  ctx.textBaseline = 'top';
  let y = 28;
  for (const line of lines) {
    ctx.font = line.weight + line.size + 'px' + font;
    ctx.fillText(line.text, 40, y);
    y += line.size + 11;
  }
  ctx.drawImage(chart, 0, headerHeight, width, chart.height / 3);
  ctx.font = '15px' + font;
  const footer = headerHeight + chart.height / 3 + 12;
  ctx.fillText('蓝色低于加性基线，红色高于加性基线，白色接近零。', 40, footer);
  ctx.fillText('交互分量 = 中心化双因子预测 − 两个中心化单因子效应。', 40, footer + 23);
  return canvas;
}

document.addEventListener('DOMContentLoaded', () => {
  $('#pd-interaction-tiff').addEventListener('click', async () => {
    const result = State.pdp;
    if (!State.model || !result || result.request !== _surfaceRequest) {
      clearInteraction();
      return;
    }
    const names = [ftName(result.j), ftName(result.k)];
    const safeNames = names.map(name => name.replace(/[<>:"/\\|?*\s]/g, '_').slice(0, 48));
    const basename = (State.settings.exportPrefix || 'svm-ioa') + '-interaction-' + safeNames.join('-');
    try {
      const canvas = interactionFigure(result, names, State.dataset.unit);
      await exportCanvasImage(canvas, basename, 'tiff');
    } catch (error) {
      toast('交互效应图片导出失败：' + error.message);
    }
  });
});
