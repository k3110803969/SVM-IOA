const IMAGE_EXPORT_MAX_BYTES = 2_000_000;

// TIFF 6.0 RGB with an optional Adobe Deflate (zlib) strip.
async function canvasToTiff(canvas) {
  const {width, height} = canvas;
  if (!width || !height) throw new Error('图像尺寸无效');
  const byteCount = width * height * 3;
  const entries = 13;
  const bitsOffset = 8 + 2 + entries * 12 + 4;
  const resolutionOffset = bitsOffset + 6;
  const pixelsOffset = resolutionOffset + 8;
  if (pixelsOffset + byteCount > 0xffffffff) throw new Error('图像过大');

  const header = new DataView(new ArrayBuffer(pixelsOffset));
  header.setUint16(0, 0x4949, true); // II byte order
  header.setUint16(2, 42, true);
  header.setUint32(4, 8, true);
  header.setUint16(8, entries, true);

  const tags = [
    [256, 4, 1, width],              // ImageWidth
    [257, 4, 1, height],             // ImageLength
    [258, 3, 3, bitsOffset],         // BitsPerSample
    [259, 3, 1, 1],                  // Compression: updated after encoding
    [262, 3, 1, 2],                  // PhotometricInterpretation: RGB
    [273, 4, 1, pixelsOffset],       // StripOffsets
    [277, 3, 1, 3],                  // SamplesPerPixel
    [278, 4, 1, height],             // RowsPerStrip
    [279, 4, 1, byteCount],          // StripByteCounts
    [282, 5, 1, resolutionOffset],  // XResolution
    [283, 5, 1, resolutionOffset],  // YResolution
    [284, 3, 1, 1],                  // PlanarConfiguration: interleaved
    [296, 3, 1, 2],                  // ResolutionUnit: inch
  ];
  tags.forEach(([id, type, count, value], index) => {
    const offset = 10 + index * 12;
    header.setUint16(offset, id, true);
    header.setUint16(offset + 2, type, true);
    header.setUint32(offset + 4, count, true);
    if (type === 3 && count === 1) header.setUint16(offset + 8, value, true);
    else header.setUint32(offset + 8, value, true);
  });
  for (let i = 0; i < 3; i++) header.setUint16(bitsOffset + i * 2, 8, true);
  header.setUint32(resolutionOffset, 300, true);
  header.setUint32(resolutionOffset + 4, 1, true);

  // Composite any transparent canvas pixels on white for standard RGB TIFF.
  const rgba = canvas.getContext('2d').getImageData(0, 0, width, height).data;
  const rgb = new Uint8Array(byteCount);
  for (let src = 0, dst = 0; src < rgba.length; src += 4, dst += 3) {
    const alpha = rgba[src + 3];
    for (let ch = 0; ch < 3; ch++) {
      rgb[dst + ch] = alpha === 255 ? rgba[src + ch] :
        Math.round((rgba[src + ch] * alpha + 255 * (255 - alpha)) / 255);
    }
  }
  let pixels = new Blob([rgb]);
  if (typeof CompressionStream === 'function') {
    const compressed = await new Response(pixels.stream().pipeThrough(new CompressionStream('deflate'))).blob();
    if (compressed.size < pixels.size) {
      pixels = compressed;
      header.setUint16(10 + 3 * 12 + 8, 8, true);
      header.setUint32(10 + 8 * 12 + 8, pixels.size, true);
    }
  }
  return new Blob([header.buffer, pixels], {type:'image/tiff'});
}

function canvasToPng(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('无法编码 PNG 图像')), 'image/png');
  });
}

async function encodeImageWithinLimit(canvas, format) {
  const encode = format === 'png' ? canvasToPng : canvasToTiff;
  let candidate = canvas;
  for (;;) {
    const blob = await encode(candidate);
    if (blob.size <= IMAGE_EXPORT_MAX_BYTES) return blob;
    // Start at original size, then shrink proportionally only if encoding exceeds the cap.
    const factor = Math.max(0.2, Math.min(0.9, 0.96 * Math.sqrt(IMAGE_EXPORT_MAX_BYTES / blob.size)));
    const width = Math.max(1, Math.floor(candidate.width * factor));
    const height = Math.max(1, Math.floor(candidate.height * factor));
    if (width === candidate.width && height === candidate.height) throw new Error('图片无法缩小到 2 MB 以内');
    candidate = document.createElement('canvas');
    candidate.width = width;
    candidate.height = height;
    const ctx = candidate.getContext('2d');
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(canvas, 0, 0, width, height);
  }
}

async function exportCanvasImage(canvas, basename, format) {
  const filename = basename + '.' + format;
  const blob = await encodeImageWithinLimit(canvas, format);
  if (window.AndroidHost?.saveFileBase64 || window.webkit?.messageHandlers?.saveFile) {
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error || new Error('无法读取导出图像'));
      reader.readAsDataURL(blob);
    });
    downloadBinary(filename, dataUrl, blob.type);
    return;
  }
  const url = URL.createObjectURL(blob);
  downloadBinary(filename, url);
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}
