// ---------- 轻量 Canvas 图表 ----------
const Charts = (() => {
  const BLUE = '#2f7ef5';
  const GREEN = '#27c08a';

  function prep(canvas) {
    const dpr = Number(canvas.dataset.dpr) || window.devicePixelRatio || 1;
    // 逻辑高度只在第一次读取 HTML 里声明的 height，然后记在 dataset 上。
    // 注意：给 canvas.height 赋值会改写同一个 HTML 属性，
    // 若每次都回读，高度会一轮一轮翻倍（图表越点越长）。
    if (!canvas.dataset.h) {
      canvas.dataset.h = String(parseInt(canvas.getAttribute('height'), 10) || 280);
    }
    const h = Math.max(80, Math.min(900, parseInt(canvas.dataset.h, 10) || 280));
    const w = Number(canvas.dataset.w) || canvas.clientWidth || (canvas.parentElement && canvas.parentElement.clientWidth) || 600;
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    canvas.style.height = h + 'px';
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    return { ctx, w, h };
  }

  function niceTicks(min, max, n = 5) {
    if (min === max) { min -= 1; max += 1; }
    const span = max - min;
    const raw = span / n;
    const mag = Math.pow(10, Math.floor(Math.log10(raw)));
    const norm = raw / mag;
    let step = mag;
    if (norm >= 5) step = 5 * mag; else if (norm >= 2) step = 2 * mag; else step = 1 * mag;
    const lo = Math.floor(min / step) * step;
    const hi = Math.ceil(max / step) * step;
    const ticks = [];
    for (let v = lo; v <= hi + step * 0.5; v += step) ticks.push(+v.toFixed(10));
    return { ticks, lo, hi };
  }

  function frame(ctx, w, h, pad, opts) {
    const { lo, hi, ticks } = opts;
    const pw = w - pad.l - pad.r, ph = h - pad.t - pad.b;
    ctx.font = '12px -apple-system,"PingFang SC",sans-serif';
    ctx.textBaseline = 'middle';
    const fmtY = opts.fmtY || (v => {
      const a = Math.abs(v);
      if (a >= 100) return String(Math.round(v));
      if (a >= 1) return String(+v.toFixed(1));
      return String(+v.toFixed(3));
    });
    // 横向虚线网格 + y 轴刻度
    ticks.forEach(t => {
      const y = pad.t + ph - ((t - lo) / (hi - lo)) * ph;
      ctx.strokeStyle = '#e7edf6';
      ctx.setLineDash([5, 5]);
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(w - pad.r, y); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = '#9aa6b8';
      ctx.textAlign = 'right';
      ctx.fillText(fmtY(t), pad.l - 8, y);
    });
    // 坐标轴
    ctx.strokeStyle = '#d6deea';
    ctx.beginPath();
    ctx.moveTo(pad.l, pad.t); ctx.lineTo(pad.l, h - pad.b); ctx.lineTo(w - pad.r, h - pad.b);
    ctx.stroke();
    return { pw, ph, lo, hi };
  }

  // 折线图（适应度收敛曲线 / 预测对比）
  function line(canvas, o) {
    const { ctx, w, h } = prep(canvas);
    const pad = { l: 52, r: 24, t: 16, b: 34 };
    const pts = o.points;
    if (!pts.length) return;
    const xs = pts.map(p => p.x), ys = pts.map(p => p.y);
    const xMin = o.xMin !== undefined ? o.xMin : Math.min(...xs);
    const xMax = o.xMax !== undefined ? o.xMax : Math.max(...xs);
    const t = niceTicks(o.yMin !== undefined ? o.yMin : Math.min(...ys),
                       o.yMax !== undefined ? o.yMax : Math.max(...ys), 5);
    const { pw, ph, lo, hi } = frame(ctx, w, h, pad, { ...t, fmtY: o.fmtY });
    const X = x => pad.l + ((x - xMin) / (xMax - xMin || 1)) * pw;
    const Y = y => pad.t + ph - ((y - lo) / (hi - lo)) * ph;

    // 面积 + 折线
    ctx.beginPath();
    pts.forEach((p, i) => { const x = X(p.x), y = Y(p.y); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
    ctx.strokeStyle = o.color || BLUE;
    ctx.lineWidth = 2; ctx.lineJoin = 'round';
    ctx.stroke();

    if (o.marker !== false) {
      // 数据点较多时抽稀，避免标记挤在一起
      const n = pts.length;
      const step = Math.max(1, Math.ceil(n / 26));
      pts.forEach((p, i) => {
        if (i % step !== 0 && i !== n - 1) return;
        ctx.beginPath();
        ctx.arc(X(p.x), Y(p.y), 4, 0, Math.PI * 2);
        ctx.fillStyle = o.color || BLUE; ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
      });
    }
    // x 轴标签
    ctx.fillStyle = '#9aa6b8'; ctx.textBaseline = 'top';
    const steps = o.xTicks || 6;
    for (let i = 0; i <= steps; i++) {
      const xv = xMin + (xMax - xMin) * i / steps;
      // 首尾标签贴边时改为左右对齐，避免被画布裁掉
      const px = X(xv);
      let tx = px, align = 'center';
      if (i === 0) { align = 'left'; tx = Math.max(pad.l - 6, px); }
      else if (i === steps) { align = 'right'; tx = Math.min(w - pad.r + 6, px); }
      ctx.textAlign = align;
      ctx.fillText(o.fmtX ? o.fmtX(xv) : String(Math.round(xv)), tx, h - pad.b + 12);
    }
  }

  // 柱状图（最优配比）
  function bars(canvas, o) {
    const { ctx, w, h } = prep(canvas);
    const pad = { l: 52, r: 18, t: 16, b: 34 };
    const vals = o.values;
    const t = niceTicks(0, o.yMax !== undefined ? o.yMax : Math.max(...vals) * 1.15, 5);
    const { pw, ph, lo, hi } = frame(ctx, w, h, pad, { ...t, fmtY: o.fmtY });
    const n = vals.length;
    const slot = pw / n;
    const bw = Math.min(slot * 0.42, 46);
    vals.forEach((v, i) => {
      const cx = pad.l + slot * (i + 0.5);
      const y = pad.t + ph - ((v - lo) / (hi - lo)) * ph;
      const grad = ctx.createLinearGradient(0, y, 0, pad.t + ph);
      grad.addColorStop(0, o.color || BLUE);
      grad.addColorStop(1, o.color2 || '#7fb2fa');
      ctx.fillStyle = grad;
      const r = 5;
      const x0 = cx - bw / 2, y0 = y, ww = bw, hh = pad.t + ph - y;
      ctx.beginPath();
      ctx.moveTo(x0, y0 + hh);
      ctx.lineTo(x0, y0 + r);
      ctx.quadraticCurveTo(x0, y0, x0 + r, y0);
      ctx.lineTo(x0 + ww - r, y0);
      ctx.quadraticCurveTo(x0 + ww, y0, x0 + ww, y0 + r);
      ctx.lineTo(x0 + ww, y0 + hh);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#9aa6b8'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillText(o.labels[i], cx, h - pad.b + 12);
    });
  }

  // 预测/实测对比散点图
  function parity(canvas, o) {
    const { ctx, w, h } = prep(canvas);
    const pad = { l: 56, r: 20, t: 18, b: 40 };
    const all = o.actual.concat(o.pred);
    const t = niceTicks(Math.min(...all), Math.max(...all), 5);
    const { pw, ph, lo, hi } = frame(ctx, w, h, pad, { ...t });
    const X = v => pad.l + ((v - lo) / (hi - lo)) * pw;
    const Y = v => pad.t + ph - ((v - lo) / (hi - lo)) * ph;

    // 45° 参考线
    ctx.strokeStyle = '#c9d6e8'; ctx.setLineDash([6, 5]); ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(X(lo), Y(lo)); ctx.lineTo(X(hi), Y(hi)); ctx.stroke();
    ctx.setLineDash([]);

    o.actual.forEach((a, i) => {
      const isTrain = i < o.trainCount;
      ctx.beginPath();
      ctx.arc(X(a), Y(o.pred[i]), 4.6, 0, Math.PI * 2);
      ctx.fillStyle = isTrain ? BLUE : GREEN;
      ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.4; ctx.stroke();
    });

    ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillStyle = '#9aa6b8';
    ctx.fillText(o.xLabel || '实测值', pad.l + pw / 2, h - 26);
    ctx.save();
    ctx.translate(16, pad.t + ph / 2); ctx.rotate(-Math.PI / 2);
    ctx.textBaseline = 'middle';
    ctx.fillText(o.yLabel || '预测值', 0, 0);
    ctx.restore();

    // 图例
    const lg = o.trainCount ? [['训练拟合', BLUE], ['留出验证', GREEN]] : [['外层验证', GREEN]];
    lg.forEach(([name, c], i) => {
      const lx = w - pad.r - 150 + i * 76, ly = 14;
      ctx.beginPath(); ctx.arc(lx, ly, 4.5, 0, Math.PI * 2); ctx.fillStyle = c; ctx.fill();
      ctx.fillStyle = '#6b7789'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(name, lx + 9, ly);
    });
  }

  // Publication figures: common cyan–green–yellow scale for contours and surfaces.
  const FIG_STOPS = [[0,[0,174,255]],[0.27,[0,255,225]],[0.55,[0,244,35]],[0.78,[150,255,0]],[1,[255,242,0]]];
  function figureRGB(t) {
    t = clamp(t, 0, 1);
    for (let k=1;k<FIG_STOPS.length;k++) {
      const [b,B]=FIG_STOPS[k], [a,A]=FIG_STOPS[k-1];
      if(t<=b) { const f=(t-a)/(b-a); return A.map((v,j)=>Math.round(v+(B[j]-v)*f)); }
    }
    return FIG_STOPS[FIG_STOPS.length-1][1];
  }
  function divColor(t) { return 'rgb('+figureRGB(t).join(',')+')'; }
  function tickLabel(v) { const a=Math.abs(v);return String(+(a>=100?v.toFixed(0):a>=10?v.toFixed(1):a>=1?v.toFixed(2):v.toFixed(3))); }
  function axisName(s) {
    return String(s||'').replace(/^[A-Z]:\s*/, '').replace(/X([1-6])/g,(_,n)=>'X'+'₀₁₂₃₄₅₆'[+n])
      .replace(/_pct\b/gi,' (%)').replace(/_coded\b/gi,' (coded)').replace(/_/g,' ');
  }
  function responseName(s) {
    return String(s||'Response').replace(/qu7/gi,'qᵤ,₇').replace(/q_u/gi,'qᵤ').replace(/_(kPa|MPa)\b/gi,' ($1)');
  }
  function contourLevels(min,max,count=7) {
    if (!(max>min)) return [];
    const raw=(max-min)/(count+1), mag=10**Math.floor(Math.log10(raw));
    const step=[1,2,2.5,5,10].map(v=>v*mag).reduce((a,b)=>Math.abs(b-raw)<Math.abs(a-raw)?b:a);
    const out=[];
    for(let v=Math.ceil((min+step*1e-8)/step)*step;v<max-step*1e-8;v+=step) out.push(+v.toPrecision(10));
    return out;
  }
  function contourSegments(z,xv,yv,level) {
    const out=[];
    for(let i=0;i<xv.length-1;i++) for(let j=0;j<yv.length-1;j++) {
      const p=[[xv[i],yv[j],z[i][j]],[xv[i+1],yv[j],z[i+1][j]],[xv[i+1],yv[j+1],z[i+1][j+1]],[xv[i],yv[j+1],z[i][j+1]]];
      const hits=[];
      for(let e=0;e<4;e++) { const a=p[e],b=p[(e+1)%4];
        if((a[2]<level)!==(b[2]<level)) {const t=(level-a[2])/(b[2]-a[2]);hits.push([a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])]);}
      }
      if(hits.length===2) out.push(hits);
      else if(hits.length===4) {
        // Resolve a saddle with its bilinear cell-center value.
        const flip=((p.reduce((s,a)=>s+a[2],0)/4<level)===(p[0][2]<level));
        out.push(flip?[hits[0],hits[1]]:[hits[0],hits[3]],flip?[hits[2],hits[3]]:[hits[1],hits[2]]);
      }
    }
    return out;
  }
  function figText(ctx,text,x,y,size=15,align='center',italic=false) {
    ctx.font=(italic?'italic bold ':'')+size+'px "Times New Roman", "Noto Serif", "SimSun", serif';
    ctx.fillStyle='#111111';ctx.textAlign=align;ctx.textBaseline='middle';ctx.fillText(text,x,y);
  }
  function pdp2d(canvas,o) {
    const {ctx,w,h}=prep(canvas);ctx.fillStyle='#fff';ctx.fillRect(0,0,w,h);
    const small=w<520, fs=small?12:15;
    const side=Math.max(90,Math.min(w-(small?128:178),h-112));
    const left=(w-side)/2-12,top=(h-side)/2-6;
    const xv=o.xv,yv=o.yv,z=o.z,st=o.scale;
    const xmin=xv[0],xmax=xv[xv.length-1],ymin=yv[0],ymax=yv[yv.length-1];
    const X=x=>left+(x-xmin)/(xmax-xmin||1)*side,Y=y=>top+side-(y-ymin)/(ymax-ymin||1)*side;
    const T=v=>(v-st.min)/(st.max-st.min||1);
    const palette=o.palette || figureRGB;
    // Bilinear raster avoids the visible block edges of the former cell heatmap.
    const raster=document.createElement('canvas'),nr=Math.min(1000,Math.max(300,Math.ceil(side*1.7)));
    raster.width=nr;raster.height=nr;const rc=raster.getContext('2d'),im=rc.createImageData(nr,nr);
    for(let py=0;py<nr;py++) for(let px=0;px<nr;px++) {
      const a=px/(nr-1)*(xv.length-1),b=(1-py/(nr-1))*(yv.length-1);
      const i=Math.min(xv.length-2,Math.floor(a)),j=Math.min(yv.length-2,Math.floor(b)),u=a-i,v=b-j;
      const value=z[i][j]*(1-u)*(1-v)+z[i+1][j]*u*(1-v)+z[i][j+1]*(1-u)*v+z[i+1][j+1]*u*v;
      const rgb=palette(T(value)),k=4*(py*nr+px);im.data[k]=rgb[0];im.data[k+1]=rgb[1];im.data[k+2]=rgb[2];im.data[k+3]=255;
    }
    rc.putImageData(im,0,0);ctx.drawImage(raster,left,top,side,side);
    const labels=[];
    ctx.save();ctx.beginPath();ctx.rect(left,top,side,side);ctx.clip();
    for(const lv of contourLevels(st.min,st.max,o.levels)) {
      const segs=contourSegments(z,xv,yv,lv);ctx.beginPath();
      for(const [a,b] of segs){ctx.moveTo(X(a[0]),Y(a[1]));ctx.lineTo(X(b[0]),Y(b[1]));}
      ctx.strokeStyle='rgba(0,0,0,.66)';ctx.lineWidth=1.05;ctx.stroke();
      if(o.showLevelValues===false)continue;
      const candidates=segs.map(([a,b])=>[(X(a[0])+X(b[0]))/2,(Y(a[1])+Y(b[1]))/2]);
      candidates.sort((a,b)=>Math.abs(a[0]-left-side*.54)-Math.abs(b[0]-left-side*.54));
      for(const [x,y] of candidates){
        if(x<left+28||x>left+side-28||y<top+13||y>top+side-13||labels.some(p=>Math.abs(p[0]-x)<52&&Math.abs(p[1]-y)<23))continue;
        const text=tickLabel(lv);ctx.font='bold '+fs+'px "Times New Roman",serif';const bw=ctx.measureText(text).width+10;
        ctx.fillStyle='rgba(255,255,255,.96)';ctx.fillRect(x-bw/2,y-10,bw,20);figText(ctx,text,x,y+.5,fs);labels.push([x,y]);break;
      }
    }
    if(o.points)for(const p of o.points){ctx.beginPath();ctx.arc(X(p[0]),Y(p[1]),3,0,Math.PI*2);ctx.fillStyle='#fff';ctx.fill();ctx.strokeStyle='#222';ctx.lineWidth=1;ctx.stroke();}
    if(o.marker){ctx.beginPath();ctx.arc(X(o.marker.x),Y(o.marker.y),5,0,Math.PI*2);ctx.fillStyle='#c52c2c';ctx.fill();ctx.strokeStyle='#fff';ctx.stroke();}
    ctx.restore();ctx.strokeStyle='#222';ctx.lineWidth=1.2;ctx.strokeRect(left,top,side,side);
    for(let k=0;k<=4;k++){
      const x=left+side*k/4,y=top+side-side*k/4;
      ctx.beginPath();ctx.moveTo(x,top+side);ctx.lineTo(x,top+side+6);ctx.moveTo(left-6,y);ctx.lineTo(left,y);ctx.stroke();
      figText(ctx,tickLabel(xmin+(xmax-xmin)*k/4),x,top+side+19,fs);
      figText(ctx,tickLabel(ymin+(ymax-ymin)*k/4),left-12,y,fs,'right');
    }
    figText(ctx,axisName(o.xLabel),left+side/2,top+side+48,small?16:19,'center',true);
    ctx.save();ctx.translate(left-(small?49:66),top+side/2);ctx.rotate(-Math.PI/2);figText(ctx,axisName(o.yLabel),0,0,small?16:19,'center',true);ctx.restore();
    figText(ctx,responseName(o.unit),left+side/2,top-23,small?17:20,'center',true);
    const cbx=left+side+25,cbw=12,g=ctx.createLinearGradient(0,top+side,0,top);
    for(let k=0;k<=32;k++)g.addColorStop(k/32,'rgb('+palette(k/32).join(',')+')');ctx.fillStyle=g;ctx.fillRect(cbx,top,cbw,side);ctx.strokeStyle='#444';ctx.lineWidth=.7;ctx.strokeRect(cbx,top,cbw,side);
    for(let k=0;k<=4;k++)figText(ctx,tickLabel(st.min+(st.max-st.min)*k/4),cbx+cbw+6,top+side-side*k/4,small?10:12,'left');
    return {kind:'contour',w,h,left,top,side,project:(x,y)=>[X(x),Y(y)],unproject:(x,y)=>x>=left&&x<=left+side&&y>=top&&y<=top+side?[xmin+(x-left)/side*(xmax-xmin),ymax-(y-top)/side*(ymax-ymin)]:null};
  }

  function surface3d(canvas,o) {
    const {ctx,w,h}=prep(canvas);ctx.fillStyle='#fff';ctx.fillRect(0,0,w,h);
    const xv=o.xv,yv=o.yv,z=o.z,nx=xv.length,ny=yv.length;
    const zmin=o.scale.min,zmax=o.scale.max,span=zmax-zmin||1;
    const observed=(o.dataPoints||[]).map(p=>p[2]),axisMin=Math.min(zmin,...observed),axisMax=Math.max(zmax,...observed);
    const raw=(axisMax-axisMin||1)/4,mag=10**Math.floor(Math.log10(raw));
    const step=([1,2,2.5,5,10].find(v=>v*mag>=raw)||10)*mag;
    const low=Math.floor(axisMin/step)*step,high=Math.ceil((axisMax+.05*(axisMax-axisMin||1))/step)*step;
    // Floor is below the first response tick: the response surface stays clear of its projection.
    const floor=low-step*.65,ZT=2.0,Z=v=>(v-floor)/(high-floor)*ZT;
    const yaw=(o.yaw??-35)*Math.PI/180,pitch=(o.pitch??26)*Math.PI/180;
    const cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);
    const proj=(x,y,v)=>({x:x*cy-y*sy,y:-((x*sy+y*cy)*sp+v*cp),depth:(x*sy+y*cy)*cp-v*sp});
    const corners=[[-1,-1],[1,-1],[1,1],[-1,1]],tracked=corners.flatMap(([x,y])=>[proj(x,y,0),proj(x,y,ZT)]);
    const minx=Math.min(...tracked.map(p=>p.x)),maxx=Math.max(...tracked.map(p=>p.x)),miny=Math.min(...tracked.map(p=>p.y)),maxy=Math.max(...tracked.map(p=>p.y));
    const small=w<520,pl=small?65:88,pr=small?58:98,pt=24,pb=small?69:79;
    const scale=Math.min((w-pl-pr)/(maxx-minx),(h-pt-pb)/(maxy-miny));
    const ox=pl+(w-pl-pr-(maxx-minx)*scale)/2-minx*scale,oy=pt+(h-pt-pb-(maxy-miny)*scale)/2-miny*scale;
    const S=p=>[ox+p.x*scale,oy+p.y*scale],P=(x,y,v)=>S(proj(x,y,v));
    const line=(a,b,color='#222',width=1)=>{ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();};
    const polygon=(pts,fill,stroke='#333',width=1)=>{ctx.beginPath();pts.forEach((p,k)=>k?ctx.lineTo(...p):ctx.moveTo(...p));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.stroke();}};
    // Far walls are selected by depth, rather than assuming a fixed viewing quadrant.
    const farX=sy>=0?1:-1,farY=cy>=0?1:-1,nearX=-farX,nearY=-farY;
    polygon(corners.map(([x,y])=>P(x,y,0)),'#606060','#222',1.2);
    polygon([P(farX,-1,0),P(farX,1,0),P(farX,1,ZT),P(farX,-1,ZT)],'#fff','#333',1.15);
    polygon([P(-1,farY,0),P(1,farY,0),P(1,farY,ZT),P(-1,farY,ZT)],'#fff','#333',1.15);
    for(let k=1;k<4;k++){const u=-1+k/2;line(P(farX,u,0),P(farX,u,ZT),'#777',.8);line(P(u,farY,0),P(u,farY,ZT),'#777',.8);}
    for(let v=low;v<=high+step*.01;v+=step){line(P(farX,-1,Z(v)),P(farX,1,Z(v)),'#777',.8);line(P(-1,farY,Z(v)),P(1,farY,Z(v)),'#777',.8);}
    const normX=x=>(x-xv[0])/(xv[nx-1]-xv[0]||1)*2-1,normY=y=>(y-yv[0])/(yv[ny-1]-yv[0]||1)*2-1;
    for(const lv of contourLevels(zmin,zmax,o.levels||7)){
      ctx.beginPath();for(const [a,b] of contourSegments(z,xv,yv,lv)){ctx.moveTo(...P(normX(a[0]),normY(a[1]),0));ctx.lineTo(...P(normX(b[0]),normY(b[1]),0));}
      ctx.strokeStyle=divColor((lv-zmin)/span);ctx.lineWidth=1.35;ctx.stroke();
    }
    const vertices=xv.map((_,i)=>yv.map((_,j)=>proj(-1+2*i/(nx-1),-1+2*j/(ny-1),Z(z[i][j])))),faces=[];
    for(let i=0;i<nx-1;i++)for(let j=0;j<ny-1;j++){
      const p=[vertices[i][j],vertices[i+1][j],vertices[i+1][j+1],vertices[i][j+1]];
      faces.push({p,depth:p.reduce((s,a)=>s+a.depth,0)/4,value:(z[i][j]+z[i+1][j]+z[i+1][j+1]+z[i][j+1])/4,samples:[[xv[i],yv[j],z[i][j]],[xv[i+1],yv[j],z[i+1][j]],[xv[i+1],yv[j+1],z[i+1][j+1]],[xv[i],yv[j+1],z[i][j+1]]]});
    }
    faces.sort((a,b)=>b.depth-a.depth);
    for(const f of faces)polygon(f.p.map(S),divColor((f.value-zmin)/span),'rgba(0,0,0,.62)',.55);
    const fs=small?12:15;
    // Tick offsets follow edge normals, keeping labels outside the base.
    const center=P(0,0,0);
    const normal=(a,b)=>{const dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy)||1;let n=[-dy/len,dx/len];if(n[0]*((a[0]+b[0])/2-center[0])+n[1]*((a[1]+b[1])/2-center[1])<0)n=n.map(v=>-v);return n;};
    const xn=normal(P(-1,nearY,0),P(1,nearY,0)),yn=normal(P(nearX,-1,0),P(nearX,1,0));
    const offset=(p,n,d)=>[p[0]+n[0]*d,p[1]+n[1]*d];
    for(let k=0;k<=4;k++){
      const u=-1+k/2,px=P(u,nearY,0),py=P(nearX,u,0),tx=offset(px,xn,17),ty=offset(py,yn,u===nearY?43:18);
      line(px,offset(px,xn,5));line(py,offset(py,yn,5));figText(ctx,tickLabel(xv[0]+(xv[nx-1]-xv[0])*k/4),...tx,fs);
      figText(ctx,tickLabel(yv[0]+(yv[ny-1]-yv[0])*k/4),...ty,fs,yn[0]>=0?'left':'right');
    }
    const title=(label,a,b,n)=>{const mid=[(a[0]+b[0])/2,(a[1]+b[1])/2],p=offset(mid,n,small?48:54);let angle=Math.atan2(b[1]-a[1],b[0]-a[0]);if(angle>Math.PI/2)angle-=Math.PI;if(angle<-Math.PI/2)angle+=Math.PI;ctx.save();ctx.translate(...p);ctx.rotate(angle);figText(ctx,axisName(label),0,0,small?15:18,'center',true);ctx.restore();};
    title(o.xLabel,P(-1,nearY,0),P(1,nearY,0),xn);title(o.yLabel,P(nearX,-1,0),P(nearX,1,0),yn);
    const left=corners.reduce((a,b)=>P(...a,0)[0]<P(...b,0)[0]?a:b);
    const bottom=P(...left,0),top=P(...left,ZT);line(bottom,top,'#222',1.3);
    for(let v=low;v<=high+step*.01;v+=step){const p=P(...left,Z(v));line([p[0]-5,p[1]],p);figText(ctx,tickLabel(v),p[0]-10,p[1],fs,'right');}
    ctx.save();ctx.translate(bottom[0]-(small?47:67),(P(...left,Z(low))[1]+top[1])/2);ctx.rotate(-Math.PI/2);figText(ctx,responseName(o.unit),0,0,small?16:20,'center',true);ctx.restore();
    // Only requested observations are overlaid; raw responses are never clipped to the surface range.
    if(o.dataPoints)for(const dp of o.dataPoints){const p=P(normX(dp[0]),normY(dp[1]),Z(dp[2]));ctx.beginPath();ctx.arc(...p,3,0,Math.PI*2);ctx.fillStyle='#fff';ctx.fill();ctx.strokeStyle='#222';ctx.lineWidth=1;ctx.stroke();}
    if(o.marker){
      const a=clamp((normX(o.marker.x)+1)/2*(nx-1),0,nx-1),b=clamp((normY(o.marker.y)+1)/2*(ny-1),0,ny-1),i=Math.min(nx-2,Math.floor(a)),j=Math.min(ny-2,Math.floor(b)),u=a-i,v=b-j;
      const val=z[i][j]*(1-u)*(1-v)+z[i+1][j]*u*(1-v)+z[i][j+1]*(1-u)*v+z[i+1][j+1]*u*v;
      const p=P(normX(o.marker.x),normY(o.marker.y),Z(val));ctx.beginPath();ctx.arc(...p,4,0,Math.PI*2);ctx.fillStyle='#c52c2c';ctx.fill();ctx.strokeStyle='#fff';ctx.stroke();
    }
    return {kind:'3d',w,h,faces:faces.map(f=>({screen:f.p.map(S),samples:f.samples})),project:(x,y,value)=>P(normX(x),normY(y),Z(value))};
  }

  return { line, bars, parity, pdp2d, surface3d, divColor, contourLevels };
})();
window.Charts = Charts;
