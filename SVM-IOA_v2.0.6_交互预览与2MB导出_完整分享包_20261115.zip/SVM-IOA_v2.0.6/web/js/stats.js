// ---------- 统计推断：二次多项式（RSM）回归 + 方差分析 + 显著性 ----------
// 说明：SVR 属于黑箱模型，本身没有解析的方差分析；本模块按 Design-Expert
// 的做法拟合二阶多项式，给出 F 检验、p 值、失拟检验、预测区间，
// 并对 SVR 提供交叉验证 + 置换检验的显著性判据。
const STATS = (() => {
  // ================= 矩阵 =================
  function transpose(A) {
    const r = A.length, c = A[0].length, T = [];
    for (let j = 0; j < c; j++) { T.push(new Array(r)); for (let i = 0; i < r; i++) T[j][i] = A[i][j]; }
    return T;
  }
  function matmul(A, B) {
    const n = A.length, m = B[0].length, k = B.length, C = [];
    for (let i = 0; i < n; i++) {
      const row = new Array(m).fill(0);
      for (let j = 0; j < m; j++) { let s = 0; for (let t = 0; t < k; t++) s += A[i][t] * B[t][j]; row[j] = s; }
      C.push(row);
    }
    return C;
  }
  function matvec(A, v) { return A.map(row => row.reduce((s, a, j) => s + a * v[j], 0)); }

  // 高斯-约当求逆（带部分主元）
  function inverse(M) {
    const n = M.length;
    const A = M.map((r, i) => r.concat(Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))));
    for (let col = 0; col < n; col++) {
      let piv = col;
      for (let r = col + 1; r < n; r++) if (Math.abs(A[r][col]) > Math.abs(A[piv][col])) piv = r;
      if (Math.abs(A[piv][col]) < 1e-12) throw new Error('设计矩阵奇异：存在完全共线的项（检查是否因子取值恒定或点数不足）');
      [A[col], A[piv]] = [A[piv], A[col]];
      const p = A[col][col];
      for (let j = 0; j < 2 * n; j++) A[col][j] /= p;
      for (let r = 0; r < n; r++) {
        if (r === col) continue;
        const f = A[r][col];
        if (!f) continue;
        for (let j = 0; j < 2 * n; j++) A[r][j] -= f * A[col][j];
      }
    }
    return A.map(r => r.slice(n));
  }

  // ================= 分布函数 =================
  // 正则化不完全贝塔函数（连分式，Numerical Recipes 6.4）
  function betacf(a, b, x) {
    const MAXIT = 300, EPS = 3e-16, FPMIN = 1e-300;
    const qab = a + b, qap = a + 1, qam = a - 1;
    let c = 1, d = 1 - qab * x / qap;
    if (Math.abs(d) < FPMIN) d = FPMIN;
    d = 1 / d;
    let h = d;
    for (let m = 1; m <= MAXIT; m++) {
      const m2 = 2 * m;
      let aa = m * (b - m) * x / ((qam + m2) * (a + m2));
      d = 1 + aa * d; if (Math.abs(d) < FPMIN) d = FPMIN;
      c = 1 + aa / c; if (Math.abs(c) < FPMIN) c = FPMIN;
      d = 1 / d; h *= d * c;
      aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2));
      d = 1 + aa * d; if (Math.abs(d) < FPMIN) d = FPMIN;
      c = 1 + aa / c; if (Math.abs(c) < FPMIN) c = FPMIN;
      d = 1 / d;
      const del = d * c;
      h *= del;
      if (Math.abs(del - 1) < EPS) break;
    }
    return h;
  }
  function betai(a, b, x) {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    const lbeta = lgamma(a) + lgamma(b) - lgamma(a + b);
    const front = Math.exp(a * Math.log(x) + b * Math.log(1 - x) - lbeta);
    if (x < (a + 1) / (a + b + 2)) return front * betacf(a, b, x) / a;
    return 1 - front * betacf(b, a, 1 - x) / b;
  }
  function lgamma(z) {
    const g = [76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5];
    let x = z, y = z, tmp = x + 5.5;
    tmp -= (x + 0.5) * Math.log(tmp);
    let ser = 1.000000000190015;
    for (let j = 0; j < 6; j++) { y += 1; ser += g[j] / y; }
    return -tmp + Math.log(2.5066282746310005 * ser / x);
  }
  // F 分布上尾概率
  function fP(F, d1, d2) {
    if (!(F > 0)) return 1;
    if (!isFinite(F)) return 0;
    return betai(d2 / 2, d1 / 2, d2 / (d2 + d1 * F));
  }
  // t 分布双尾概率
  function tP(t, df) {
    if (!isFinite(t)) return 0;
    const x = df / (df + t * t);
    return betai(df / 2, 0.5, x);
  }
  // t 分布分位数（二分法，足够 UI 用）
  function tInv(p, df) {
    let lo = 0, hi = 100;
    for (let i = 0; i < 200; i++) {
      const mid = (lo + hi) / 2;
      const twoTail = tP(mid, df);          // P(|T| > mid)
      if (twoTail > 1 - p) lo = mid; else hi = mid;
    }
    return (lo + hi) / 2;
  }

  // ================= 因子编码 =================
  // coded = (x - center) / scale，scale 即步长 Δx（对应 ±1 水平）。
  // 默认按数据范围自动编码；传入 coding = { center:[], scale:[] } 时按用户指定
  // 的中心值 x0 与步长 Δx 编码（与 Design-Expert 的报告口径一致）。
  function codeFactors(X, coding) {
    const n = X.length, d = X[0].length;
    const center = [], scale = [];
    for (let j = 0; j < d; j++) {
      const col = X.map(r => r[j]);
      const lo = Math.min(...col), hi = Math.max(...col);
      let c = (lo + hi) / 2;
      let s = (hi - lo) / 2;
      if (coding && coding.center && coding.scale) {
        const cc = Number(coding.center[j]);
        const ss = Math.abs(Number(coding.scale[j]));
        if (isFinite(cc)) c = cc;
        if (isFinite(ss) && ss > 0) s = ss;
      }
      center.push(c); scale.push(s > 0 ? s : 1);
    }
    const Z = X.map(r => r.map((v, j) => (v - center[j]) / scale[j]));
    return { Z, center, scale };
  }

  function linspace(n) { return Array.from({ length: n }, (_, i) => i); }
  function combos(d) {
    const out = [];
    for (let i = 0; i < d; i++) for (let j = i; j < d; j++) out.push([i, j]);
    return out;
  }

  // 构建模型矩阵：截距 + 线性 + 交互 + 平方
  function designMatrix(Z, terms) {
    const n = Z.length;
    return Z.map(z => terms.map(t => {
      if (t.type === 'intercept') return 1;
      if (t.type === 'linear') return z[t.i];
      if (t.type === 'interaction') return z[t.i] * z[t.j];
      return z[t.i] * z[t.i];
    }));
  }

  function termLabel(t, names) {
    if (t.type === 'intercept') return 'Intercept';
    if (t.type === 'linear') return names[t.i];
    if (t.type === 'interaction') return names[t.i] + names[t.j];
    return names[t.i] + '\u00B2';
  }

  function allTerms(d) {
    const out = [{ type: 'intercept' }];
    for (let i = 0; i < d; i++) out.push({ type: 'linear', i });
    for (const [i, j] of combos(d)) if (i !== j) out.push({ type: 'interaction', i, j });
    for (let i = 0; i < d; i++) out.push({ type: 'quadratic', i });
    return out;
  }

  // 层次约束：低阶项在包含它的高阶项仍在模型中时不能单独删除
  function hasHigher(terms, t) {
    if (t.type !== 'linear') return false;
    return terms.some(o => (o.type === 'interaction' && (o.i === t.i || o.j === t.i)) ||
      (o.type === 'quadratic' && o.i === t.i));
  }

  function ols(Xm, y) {
    if(y.length<=Xm[0].length)throw new Error('二次模型残差自由度不足：需要更多有效试验点或减少因子');
    const Xt = transpose(Xm);
    const XtX = matmul(Xt, Xm);
    const inv = inverse(XtX);
    const Xty = matvec(Xt, y);
    const beta = matvec(inv, Xty);
    const yhat = Xm.map(row => row.reduce((s, v, j) => s + v * beta[j], 0));
    const resid = y.map((v, i) => v - yhat[i]);
    const rss = resid.reduce((s, e) => s + e * e, 0);
    const ybar = y.reduce((a, b) => a + b, 0) / y.length;
    const tss = y.reduce((s, v) => s + (v - ybar) ** 2, 0);
    const n = y.length, k = Xm[0].length;
    const df = n - k;
    const mse = df > 0 ? rss / df : NaN;
    const cov = inv.map(row => row.map(v => v * mse));
    const se = cov.map((r, i) => Math.sqrt(Math.max(r[i], 0)));
    return { beta, se, yhat, resid, rss, tss, df, mse, cov, inv, Xm, n, k };
  }

  function fitOnce(Z, y, terms) {
    const Xm = designMatrix(Z, terms);
    const f = ols(Xm, y);
    return f;
  }

  // 完整分析：可选的向后剔除
  function analyze(Xraw, y, opts = {}) {
    const names = opts.names || Xraw[0].map((_, i) => 'X' + (i + 1));
    const alpha = opts.alpha ?? 0.05;
    const select = opts.select ?? 'backward';
    const d = Xraw[0].length, n = Xraw.length;

    const { Z, center, scale } = codeFactors(Xraw, opts.coding);
    let terms = allTerms(d);
    if (terms.length >= n) throw new Error(`数据点太少：${n} 个样本无法拟合 ${terms.length} 项的二次模型，请减少因子或补充试验点`);

    let full = fitOnce(Z, y, terms);
    let dfRes = full.df;

    // 项显著性（以全模型残差均方为误差项，逐项剔除后的平方和增量）
    const termStats = () => terms.slice(1).map((t, idx) => {
      const i = idx + 1;
      const reduced = terms.filter((_, j) => j !== i);
      const fr = fitOnce(Z, y, reduced);
      const ss = Math.max(fr.rss - full.rss, 0);
      const F = ss / full.mse;
      return { term: t, label: termLabel(t, names), ss, F, p: fP(F, 1, full.df), coef: full.beta[i], se: full.se[i] };
    });

    let stats = termStats();
    const dropped = [];

    if (select === 'backward') {
      let guard = 0;
      while (guard++ < 40) {
        const candidates = terms.slice(1).map((t, idx) => ({ t, idx: idx + 1 }))
          .filter(o => o.t.type === 'interaction' || o.t.type === 'quadratic' ? true : !hasHigher(terms, o.t));
        let worst = null;
        for (const c of candidates) {
          const reduced = terms.filter((_, j) => j !== c.idx);
          const fr = fitOnce(Z, y, reduced);
          const ss = Math.max(fr.rss - full.rss, 0);
          const p = fP(ss / full.mse, 1, full.df);
          if (!worst || p > worst.p) worst = { p, idx: c.idx };
        }
        if (!worst || worst.p <= alpha || terms.length <= 2) break;
        dropped.push({ label: termLabel(terms[worst.idx], names), term: terms[worst.idx], p: worst.p });
        terms = terms.filter((_, j) => j !== worst.idx);
        full = fitOnce(Z, y, terms);
        stats = termStats();
      }
    }

    // 方差膨胀因子：用其余项回归该项，VIF = 1/(1-R²)
    (function attachVif() {
      let Xm;
      try { Xm = designMatrix(Z, terms); } catch (e) { return; }
      stats.forEach((s, idx) => {
        const j = idx + 1;
        try {
          const yj = Xm.map(r => r[j]);
          const Xc = Xm.map(r => r.filter((_, kk) => kk !== j));
          const f = ols(Xc, yj);
          const r2 = 1 - f.rss / f.tss;
          s.vif = r2 >= 1 - 1e-10 ? Infinity : 1 / (1 - r2);
        } catch (e) { s.vif = Infinity; }
      });
    })();

    // 最终模型统计量
    const k = terms.length;
    const dfModel = k - 1;    const dfResid = n - k;
    const ssModel = full.tss - full.rss;
    const ssResid = full.rss;
    const msModel = ssModel / dfModel;
    const msResid = ssResid / dfResid;
    const Fmodel = msModel / msResid;
    const pModel = fP(Fmodel, dfModel, dfResid);
    if(!(full.tss>0))throw new Error('响应值恒定，无法进行方差分析');
    const r2 = 1 - ssResid / full.tss;
    const adjR2 = 1 - (1 - r2) * (n - 1) / dfResid;

    // PRESS / 预测 R²（帽子矩阵对角线）
    const h = full.Xm.map(row => {
      const xi = matvec(full.inv, row);
      return row.reduce((s, v, j) => s + v * xi[j], 0);
    });
    const press = full.resid.reduce((s, e, i) => s + (e / Math.max(1 - h[i], 1e-9)) ** 2, 0);
    const predR2 = 1 - press / full.tss;

    // 模型诊断：Adeq Precision（信噪比）与变异系数 C.V.
    const ybar = y.reduce((a, b) => a + b, 0) / n;
    const cvPct = 100 * Math.sqrt(msResid) / Math.abs(ybar || 1e-12);
    let adeq = NaN;
    try {
      const Xall = designMatrix(Z, terms);
      let seSum = 0, yMin = Infinity, yMax = -Infinity;
      for (let i = 0; i < n; i++) {
        const row = Xall[i];
        const xt = matvec(full.inv, row);
        const lev = row.reduce((s, v, j) => s + v * xt[j], 0);
        seSum += Math.sqrt(Math.max(msResid * lev, 0));
        const yh = row.reduce((s, v, j) => s + v * full.beta[j], 0);
        if (yh < yMin) yMin = yh;
        if (yh > yMax) yMax = yh;
      }
      const meanSe = seSum / n;
      adeq = meanSe > 0 ? (yMax - yMin) / meanSe : NaN;
    } catch (e) { adeq = NaN; }

    // 失拟检验（自动识别重复点）
    const groups = new Map();
    Xraw.forEach((row, i) => {
      const key = JSON.stringify(row);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(i);
    });
    let pe = null;
    const reps = [...groups.values()].filter(g => g.length > 1);
    if (reps.length) {
      let ssPE = 0, dfPE = 0;
      for (const g of reps) {
        const mean = g.reduce((s, i) => s + y[i], 0) / g.length;
        ssPE += g.reduce((s, i) => s + (y[i] - mean) ** 2, 0);
        dfPE += g.length - 1;
      }
      const ssLOF = Math.max(full.rss - ssPE, 0);
      const dfLOF = dfResid - dfPE;
      pe = {
        ssPE, dfPE, ssLOF, dfLOF,
        F: dfLOF > 0 && ssPE > 0 ? (ssLOF / dfLOF) / (ssPE / dfPE) : null,
        p: dfLOF > 0 && ssPE > 0 ? fP((ssLOF / dfLOF) / (ssPE / dfPE), dfLOF, dfPE) : null,
        reason: dfLOF <= 0 ? '失拟自由度不足' : ssPE <= 0 ? '重复点纯误差为零，无法估计失拟 F 检验' : '',
        groups: reps.length, points: reps.reduce((s, g) => s + g.length, 0)
      };
    }

    // 系数表（t 检验 + 95% 置信区间）
    const tcrit = tInv(0.95, dfResid);
    const coefs = terms.map((t, i) => {
      const est = full.beta[i], se = full.se[i];
      const tv = est / se;
      return {
        label: termLabel(t, names), term: t, est, se, t: tv, p: tP(tv, dfResid),
        lo: est - tcrit * se, hi: est + tcrit * se,
        df: dfResid
      };
    });

    // 模型预测（返回原量纲）+ 置信区间
    function predictRaw(x) {
      const z = x.map((v, j) => (v - center[j]) / scale[j]);
      const row = terms.map(t => {
        if (t.type === 'intercept') return 1;
        if (t.type === 'linear') return z[t.i];
        if (t.type === 'interaction') return z[t.i] * z[t.j];
        return z[t.i] * z[t.i];
      });
      const yhat = row.reduce((s, v, j) => s + v * full.beta[j], 0);
      const xt = matvec(full.inv, row);
      const lev = row.reduce((s, v, j) => s + v * xt[j], 0);
      const seMean = Math.sqrt(Math.max(msResid * lev, 0));
      const sePred = Math.sqrt(Math.max(msResid * (1 + lev), 0));
      return {
        yhat, lev, seMean, sePred,
        ciLo: yhat - tcrit * seMean, ciHi: yhat + tcrit * seMean,
        piLo: yhat - tcrit * sePred, piHi: yhat + tcrit * sePred
      };
    }

    return {
      kind: 'quadratic', n, d, names, terms, coefs, termStats: stats, dropped,
      r2, adjR2, predR2, rmse: Math.sqrt(msResid), s: Math.sqrt(msResid),
      ssModel, ssResid, dfModel, dfResid, msModel, msResid, Fmodel, pModel,
      press, alpha, lackOfFit: pe, tcrit, predict: predictRaw, adeq, cvPct,
      coded: { center, scale, mode: opts.coding ? 'manual' : 'auto' }
    };
  }

  // 留一法预测（二次 RSM），用于与 SVR 做同口径对比
  function looRsm(Xraw, y, opts) {
    const n = y.length, pred = new Array(n);
    const base = Object.assign({}, opts || {}, { select: 'none' });
    for (let i = 0; i < n; i++) {
      const Xt = Xraw.filter((_, j) => j !== i);
      const yt = y.filter((_, j) => j !== i);
      const m = analyze(Xt, yt, base);
      pred[i] = m.predict(Xraw[i]).yhat;
    }
    return pred;
  }

  // 正态分布 CDF（用于 Wilcoxon 的 p 值）
  function normCdf(z) {
    const t = 1 / (1 + 0.2316419 * Math.abs(z));
    const d = 0.3989423 * Math.exp(-z * z / 2);
    const p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
    return z > 0 ? 1 - p : p;
  }

  // Wilcoxon 符号秩检验（配对比较两个模型的逐点误差）
  function wilcoxonSignedRank(diffs) {
    const d = diffs.filter(v => isFinite(v) && Math.abs(v) > 1e-12);
    const n = d.length;
    if (n < 5) return { n, p: NaN, W: NaN };
    const abs = d.map(Math.abs);
    const order = abs.map((_, i) => i).sort((a, b) => abs[a] - abs[b]);
    const ranks = new Array(n);
    let i = 0;
    while (i < n) {
      let j = i;
      while (j + 1 < n && Math.abs(abs[order[j + 1]] - abs[order[i]]) < 1e-12) j++;
      const avg = (i + j + 2) / 2;
      for (let k = i; k <= j; k++) ranks[order[k]] = avg;
      i = j + 1;
    }
    let Wp = 0, Wm = 0;
    d.forEach((v, k) => { if (v > 0) Wp += ranks[k]; else Wm += ranks[k]; });
    const W = Math.min(Wp, Wm);
    const mean = n * (n + 1) / 4;
    const sd = Math.sqrt(n * (n + 1) * (2 * n + 1) / 24);
    const z = sd > 0 ? (W - mean) / sd : 0;
    const p = Math.min(1, 2 * (1 - normCdf(Math.abs(z))));
    return { n, W: Math.min(Wp, Wm), Wp, Wm, z, p };
  }

  // ================= 置换检验（给 SVR 用） =================  // fit(Xtr, ytr) -> predict 函数；统计量用 K 折交叉验证的 R²。
  function cvR2(X, y, fit, folds = 5) {
    const n = y.length;
    const idx = linspace(n);
    for (let i = n - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [idx[i], idx[j]] = [idx[j], idx[i]]; }
    const foldSize = Math.ceil(n / folds);
    const pred = new Array(n);
    for (let f = 0; f < folds; f++) {
      const test = idx.slice(f * foldSize, (f + 1) * foldSize);
      const train = idx.filter(i => !test.includes(i));
      if (!test.length || !train.length) continue;
      const p = fit(train.map(i => X[i]), train.map(i => y[i]));
      test.forEach(i => { pred[i] = p(X[i]); });
    }
    const pairs = pred.map((v, i) => [v, y[i]]).filter(p => isFinite(p[0]));
    if (pairs.length < 3) return NaN;
    const mean = pairs.reduce((s, p) => s + p[1], 0) / pairs.length;
    const ssr = pairs.reduce((s, p) => s + (p[0] - p[1]) ** 2, 0);
    const sst = pairs.reduce((s, p) => s + (p[1] - mean) ** 2, 0);
    return 1 - ssr / (sst || 1e-12);
  }

  async function permutationTest(o) {
    const { X, y, fit, perms = 99, folds = 5, onProgress } = o;
    const obs = cvR2(X, y, fit, folds);
    const nulls = [];
    let ge = 0;
    for (let i = 0; i < perms; i++) {
      const yp = y.slice();
      for (let j = yp.length - 1; j > 0; j--) { const k = Math.floor(rnd() * (j + 1)); [yp[j], yp[k]] = [yp[k], yp[j]]; }
      const v = cvR2(X, yp, fit, folds);
      nulls.push(v);
      if (v >= obs) ge++;
      if (onProgress && (i % 5 === 0)) { onProgress((i + 1) / perms); await new Promise(r => setTimeout(r, 0)); }
    }
    nulls.sort((a, b) => a - b);
    return {
      observed: obs,
      p: (ge + 1) / (perms + 1),
      perms,
      nullMean: nulls.reduce((s, v) => s + v, 0) / nulls.length,
      nullMax: nulls[nulls.length - 1],
      nulls
    };
  }

  // 分位数（输入需已升序）
  function percentile(sorted, q) {
    if (!sorted.length) return NaN;
    const pos = (sorted.length - 1) * q;
    const lo = Math.floor(pos), hi = Math.ceil(pos);
    if (lo === hi) return sorted[lo];
    return sorted[lo] + (sorted[hi] - sorted[lo]) * (pos - lo);
  }

  return {
    analyze, permutationTest, cvR2, looRsm, wilcoxonSignedRank, normCdf, percentile,
    // 供界面/测试使用的底层函数
    _math: { inverse, transpose, matmul, betai, fP, tP, tInv, lgamma, codeFactors }
  };
})();

if (typeof window !== 'undefined') window.STATS = STATS;
if (typeof module !== 'undefined' && module.exports) module.exports = STATS;
