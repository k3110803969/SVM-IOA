// PWA 注册：仅在 http(s) 环境下启用（桌面 .app / 直接双击 html 时自动跳过）
(function () {
  if (!('serviceWorker' in navigator)) return;
  if (!/^https?:$/.test(location.protocol)) return;
  window.addEventListener('load', function () {
    navigator.serviceWorker.register('./sw.js').catch(function () { /* 离线缓存不可用时忽略 */ });
  });
})();
