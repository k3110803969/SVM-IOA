// ---------- 偏依赖图（Partial Dependence Plot, PDP）----------
// 不依赖模型具体形式，可直接作用于训练好的 SVM（核方法）等黑盒模型。
// 原理：把感兴趣的一个或两个特征固定在特定取值，其余特征保持原值，
//       对该条件下全体样本的模型预测取平均，即得到该特征组合的平均响应。
const PDP = (() => {

  const yieldNow = () => new Promise(r => setTimeout(r, 0));

  function colRange(X, j) {
    let min = Infinity, max = -Infinity;
    for (let i = 0; i < X.length; i++) {
      const v = X[i][j];
      if (v < min) min = v;
      if (v > max) max = v;
    }
    return { min, max };
  }

  function linGrid(min, max, n) {
    const out = new Array(n);
    const step = (max - min) / (n - 1 || 1);
    for (let i = 0; i < n; i++) out[i] = min + step * i;
    return out;
  }

  // 一维偏依赖：特征 j 的边际效应曲线
  function pdp1d(model, X, j, nGrid) {
    const r = colRange(X, j);
    const vals = linGrid(r.min, r.max, nGrid);
    const dim = X[0].length, N = X.length;
    const buf = new Array(dim);
    const means = vals.map(v => {
      let s = 0;
      for (let i = 0; i < N; i++) {
        for (let d = 0; d < dim; d++) buf[d] = X[i][d];
        buf[j] = v;
        s += model.predict(buf);
      }
      return s / N;
    });
    return { vals, means, min: r.min, max: r.max };
  }

  // 二维偏依赖：特征 (j, k) 的联合效应曲面
  // 用分片 + 让出主线程的方式计算，避免界面卡死
  async function pdp2d(model, X, j, k, nGrid, onProgress) {
    const rj = colRange(X, j), rk = colRange(X, k);
    const xv = linGrid(rj.min, rj.max, nGrid);
    const yv = linGrid(rk.min, rk.max, nGrid);
    const dim = X[0].length, N = X.length;
    const buf = new Array(dim);
    const z = [];
    const total = nGrid * nGrid;
    const chunk = Math.max(1, Math.floor(4000 / Math.max(1, N)));
    let done = 0;

    for (let a = 0; a < nGrid; a++) {
      const row = new Array(nGrid);
      for (let b = 0; b < nGrid; b++) {
        let s = 0;
        for (let i = 0; i < N; i++) {
          for (let d = 0; d < dim; d++) buf[d] = X[i][d];
          buf[j] = xv[a];
          buf[k] = yv[b];
          s += model.predict(buf);
        }
        row[b] = s / N;
        done++;
        if (done % chunk === 0) {
          if (onProgress) onProgress(done / total);
          await yieldNow();
        }
      }
      z.push(row);
    }
    return { xv, yv, z, range: { x: rj, y: rk } };
  }

  function mean(arr) {
    let s = 0;
    for (const v of arr) s += v;
    return s / (arr.length || 1);
  }

  // 固定其余特征于指定取值，只让 (j, k) 两个特征在网格上变化。
  // base：一行完整的特征取值（长度 = 特征数），其中 j、k 会被网格值覆盖。
  // 与 pdp2d 的区别：pdp2d 对所有样本求平均（偏依赖），这里是把其他因子
  // 真正固定住——和 Design-Expert 的等值线语义一致。
  async function surface2d(model, base, j, k, xv, yv, onProgress) {
    const buf = base.slice();
    const z = [];
    let done = 0;
    for (let a = 0; a < xv.length; a++) {
      const row = new Array(yv.length);
      for (let b = 0; b < yv.length; b++) {
        buf[j] = xv[a];
        buf[k] = yv[b];
        row[b] = model.predict(buf);
        done++;
      }
      z.push(row);
      if (onProgress) onProgress((a + 1) / xv.length);
      if (done % 900 === 0) await yieldNow();
    }
    return { xv, yv, z };
  }

  // 交互效应强度 H²（Friedman 交互统计量的两变量形式）
  // H² = Σ(2D偏依赖 − 两个1D主效应 − 常数)² / Σ(2D偏依赖 − 均值)²
  // Return the same non-additive component used to calculate H².
  function interaction(z, pj, pk) {
    const zFlat = [];
    for (const row of z) for (const v of row) zFlat.push(v);
    const zBar = mean(zFlat);
    const aBar = mean(pj.means), bBar = mean(pk.means);
    let num = 0, den = 0;
    const residual = z.map((row, a) => {
      const fx = pj.means[a] - aBar;
      return row.map((value, b) => {
        const fy = pk.means[b] - bBar;
        const t = value - zBar;
        const r = t - fx - fy;
        num += r * r;
        den += t * t;
        return r;
      });
    });
    return { residual, h2: den > 1e-12 ? num / den : 0 };
  }

  function interactionH(z, pj, pk) { return interaction(z, pj, pk).h2; }

  function stats(z) {
    let min = Infinity, max = -Infinity, sum = 0, n = 0;
    for (const row of z) for (const v of row) {
      if (v < min) min = v;
      if (v > max) max = v;
      sum += v; n++;
    }
    return { min, max, mean: sum / (n || 1) };
  }

  return { pdp1d, pdp2d, surface2d, interaction, interactionH, stats, linGrid, colRange };
})();

window.PDP = PDP;
