/* SVM-IOA 2.0.6 computation services. No DOM dependencies. */
const Engine = (() => {
  const VERSION='2.0.6';
  function assert(ok,msg){if(!ok)throw new Error(msg);}
  function hash(value){const s=typeof value==='string'?value:JSON.stringify(value);let h=2166136261;for(let i=0;i<s.length;i++)h=Math.imul(h^s.charCodeAt(i),16777619);return h>>>0;}
  function seed(base,label){const configured=State.settings.seed;setSeed(hash(String(base)+':'+label));State.settings.seed=configured;}
  function pack(m){return JSON.parse(JSON.stringify(m,(k,v)=>typeof v==='function'?undefined:ArrayBuffer.isView(v)?Array.from(v):v));}
  function restore(m){
    assert(m&&Array.isArray(m._X)&&m._X.length===m.beta.length&&m._X.length>1,'模型文件缺少有效支持向量');
    const d=m._X[0].length;
    assert(m._X.every(r=>r.length===d&&r.every(Number.isFinite))&&m.beta.every(Number.isFinite)&&[m.C,m.gamma,m.eps,m.b].every(Number.isFinite)&&m.C>0&&m.gamma>0&&m.eps>=0,'模型参数无效');
    if(m.std)assert(m.xMean?.length===d&&m.xStd?.length===d&&m.xMean.every(Number.isFinite)&&m.xStd.every(v=>Number.isFinite(v)&&v>0)&&Number.isFinite(m.yMean)&&m.yStd>0&&Number.isFinite(m.yStd),'模型标准化参数无效');
    m={...m};const xs=m.std?m._X.map(r=>r.map((v,j)=>(v-m.xMean[j])/m.xStd[j])):m._X;
    m.predict=x=>{assert(x.length===d&&x.every(Number.isFinite),'预测输入维度或数值无效');const q=m.std?x.map((v,j)=>(v-m.xMean[j])/m.xStd[j]):x;let f=m.b;for(let i=0;i<xs.length;i++){if(!m.beta[i])continue;let dis=0;for(let j=0;j<d;j++)dis+=(q[j]-xs[i][j])**2;f+=m.beta[i]*Math.exp(-m.gamma*dis);}return m.std?m.yMean+m.yStd*f:f;};return m;
  }
  function score(y,p){assert(y.length===p.length&&p.every(Number.isFinite),'预测不完整，不能计算指标');const avg=mean(y),e=y.map((v,i)=>p[i]-v),sst=y.reduce((s,v)=>s+(v-avg)**2,0);return {n:y.length,r2:sst>0?1-e.reduce((s,v)=>s+v*v,0)/sst:null,rmse:Math.sqrt(mean(e.map(v=>v*v))),mae:mean(e.map(Math.abs)),maxe:Math.max(...e.map(Math.abs))};}
  function groups(X,grouped=true){const m=new Map();X.forEach((r,i)=>{const k=grouped?JSON.stringify(r):String(i);if(!m.has(k))m.set(k,[]);m.get(k).push(i);});return [...m.values()];}
  function folds(X,k=5,grouped=true){const g=groups(X,grouped);assert(g.length>=2,'至少需要两种不同配比才能划分验证集');const idx=shuffleIdx(g.length),n=Math.min(k,g.length),out=Array.from({length:n},()=>[]);idx.forEach((v,i)=>out[i%n].push(...g[v]));return out;}
  const part=(a,ids)=>ids.map(i=>a[i]);
  const trainIds=(n,test)=>{const t=new Set(test);return Array.from({length:n},(_,i)=>i).filter(i=>!t.has(i));};
  const pause=()=>new Promise(r=>setTimeout(r,0));
  async function grid(X,y,o,progress=()=>{},tag='grid'){
    assert(o.CList?.length&&o.GList?.length&&[...o.CList,...o.GList].every(v=>Number.isFinite(v)&&v>0),'网格参数必须为正数');
    seed(o.seed,tag);const splits=folds(X,o.folds,o.grouped),total=o.CList.length*o.GList.length;let done=0,best=null;
    for(const C of o.CList)for(const gamma of o.GList){
      const pred=new Array(y.length);let worstKKT=0;
      for(const test of splits){const tr=trainIds(y.length,test);assert(tr.length>=2,'交叉验证训练样本不足');const m=ML.trainSVR(part(X,tr),part(y,tr),{C,gamma,eps:o.eps,standardize:o.standardize});worstKKT=Math.max(worstKKT,m.solver.kktViolation);for(const i of test)pred[i]=m.predict(X[i]);}
      const stats=score(y,pred);if(!best||stats.rmse<best.rmse)best={C,gamma,rmse:stats.rmse,worstKKT};
      progress({phase:'选择参数',done:++done,total});await pause();
    }return {...best,folds:splits.length};
  }
  async function fitSelected(X,y,o,progress,tag){const selected=o.grid?await grid(X,y,o,progress,tag):{C:o.C,gamma:o.gamma};return {selected,model:ML.trainSVR(X,y,{C:selected.C,gamma:selected.gamma,eps:o.eps,standardize:o.standardize})};}
  async function crossPredict(X,y,o,progress=()=>{},rsm=false){
    seed(o.seed,'outer-folds');const splits=folds(X,o.folds,o.grouped),pred=new Array(y.length),models=[],foldId=new Array(y.length),selected=[];
    for(let f=0;f<splits.length;f++){
      const test=splits[f],tr=trainIds(y.length,test);let m;
      if(rsm)m=STATS.analyze(part(X,tr),part(y,tr),{select:'none'});
      else {const fit=await fitSelected(part(X,tr),part(y,tr),o,p=>progress({...p,outer:f+1,outerTotal:splits.length}),'inner-'+f);m=fit.model;selected.push(fit.selected);}
      for(const i of test){pred[i]=rsm?m.predict(X[i]).yhat:m.predict(X[i]);foldId[i]=f;}
      models.push({train:tr,test,model:rsm?null:pack(m)});progress({phase:rsm?'RSM 外层验证':'SVR 外层验证',done:f+1,total:splits.length});await pause();
    }return {pred,foldId,models,selected,metrics:score(y,pred)};
  }
  async function train(X,y,o,progress){
    assert(X.length>=6&&X.length<=1000,'建模支持 6～1000 行有效数据；较大数据请先合理抽样');assert(y.some(v=>v!==y[0]),'响应值恒定，无法评估预测关系');
    let validation,evalTrain,evalPred,order,trainCount,selected;
    if(o.split<1){
      seed(o.seed,'holdout');const g=groups(X,o.grouped),idx=shuffleIdx(g.length),ng=Math.max(1,Math.min(g.length-1,Math.round(g.length*(1-o.split))));
      const test=idx.slice(0,ng).flatMap(i=>g[i]),tr=trainIds(y.length,test);assert(tr.length>=4&&test.length>=2,'独立留出样本不足，请改用全部数据加外层交叉验证');
      const fit=await fitSelected(part(X,tr),part(y,tr),o,progress,'holdout-selection');selected=fit.selected;
      const tp=tr.map(i=>fit.model.predict(X[i])),vp=test.map(i=>fit.model.predict(X[i]));
      validation={type:'独立留出验证',metrics:score(part(y,test),vp),train:tr,test,pred:vp,selectionScope:'训练集内选参'};evalTrain=score(part(y,tr),tp);order=[...tr,...test];evalPred=[...tp,...vp];trainCount=tr.length;
    }else{
      const cv=await crossPredict(X,y,o,progress);validation={type:o.grid?'嵌套交叉验证':'固定参数交叉验证',metrics:cv.metrics,pred:cv.pred,foldId:cv.foldId,folds:cv.models.map(m=>({train:m.train,test:m.test})),selected:cv.selected};
      const fit=await fitSelected(X,y,o,progress,'final-selection');selected=fit.selected;order=X.map((_,i)=>i);evalPred=cv.pred;trainCount=0;
    }
    const model=ML.trainSVR(X,y,{C:selected.C,gamma:selected.gamma,eps:o.eps,standardize:o.standardize});
    const fitStats=score(y,X.map(x=>model.predict(x)));if(!evalTrain)evalTrain=fitStats;
    return {model:pack(model),validation,training:evalTrain,finalFit:fitStats,selected,points:{actual:part(y,order),pred:evalPred,trainCount},options:o};
  }
  // Exact signed-rank distribution for small samples, including tied ranks.
  function wilcoxon(diffs){const d=diffs.filter(v=>Number.isFinite(v)&&Math.abs(v)>1e-12),n=d.length;if(!n)return {n:0,p:1,W:0,method:'全部差值为零'};
    const order=d.map((_,i)=>i).sort((a,b)=>Math.abs(d[a])-Math.abs(d[b])),ranks=Array(n);let tie=0;
    for(let i=0;i<n;){let j=i+1;while(j<n&&Math.abs(Math.abs(d[order[j]])-Math.abs(d[order[i]]))<1e-10)j++;for(let k=i;k<j;k++)ranks[order[k]]=(i+j+1)/2;tie+=(j-i)**3-(j-i);i=j;}
    const wp=d.reduce((s,v,i)=>s+(v>0?ranks[i]:0),0),W=Math.min(wp,n*(n+1)/2-wp);
    if(n<=50){const sum=n*(n+1),dp=Array(sum+1).fill(0);dp[0]=1;let used=0;for(const r of ranks){const r2=Math.round(2*r);for(let k=used;k>=0;k--)dp[k+r2]+=dp[k];used+=r2;}const prob=dp.slice(0,Math.floor(2*W+1e-9)+1).reduce((a,b)=>a+b,0)/2**n;return {n,W,p:Math.min(1,2*prob),method:'精确符号秩分布（含并列秩）'};}
    const variance=n*(n+1)*(2*n+1)/24-tie/48,z=Math.max(0,n*(n+1)/4-W-.5)/Math.sqrt(variance);return {n,W,p:Math.min(1,2*(1-STATS.normCdf(z))),method:'并列秩校正的正态近似'};
  }
  function bounds(X){return {lb:X[0].map((_,j)=>Math.min(...X.map(r=>r[j]))),ub:X[0].map((_,j)=>Math.max(...X.map(r=>r[j])))};}
  // Every Frank-Wolfe iterate is a convex combination of allowed observations.
  function hullProject(vertices,target,iterations=70){let best=0,dist=Infinity;for(let i=0;i<vertices.length;i++){const d=vertices[i].reduce((s,v,j)=>s+(v-target[j])**2,0);if(d<dist){dist=d;best=i;}}
    let x=vertices[best].slice(),gap=Infinity;
    for(let k=0;k<iterations;k++){const grad=x.map((v,j)=>v-target[j]);let idx=0,val=Infinity;for(let i=0;i<vertices.length;i++){const v=vertices[i].reduce((s,a,j)=>s+a*grad[j],0);if(v<val){val=v;idx=i;}}
      const delta=vertices[idx].map((v,j)=>v-x[j]);gap=-delta.reduce((s,v,j)=>s+v*grad[j],0);if(gap<1e-12)break;const den=delta.reduce((s,v)=>s+v*v,0);if(!den)break;const t=clamp(gap/den,0,1);x=x.map((v,j)=>v+t*delta[j]);}
    dist=x.reduce((s,v,j)=>s+(v-target[j])**2,0);return {x,dist,lowerBound:Math.max(0,dist-2*gap)};
  }
  function region(X,o={}){
    const b=bounds(X),d=X[0].length,lb=o.lb||b.lb,ub=o.ub||b.ub,type=o.region||'hull',total=o.total;
    assert(lb.length===d&&ub.length===d&&lb.every((v,j)=>Number.isFinite(v)&&Number.isFinite(ub[j])&&v<=ub[j]),'上下界必须与因子数一致，且下界不能大于上界');
    assert(['box','sphere','hull'].includes(type),'未知寻优范围');
    if(total!==null&&total!==undefined)assert(Number.isFinite(total)&&total>=lb.reduce((s,v)=>s+v,0)-1e-9&&total<=ub.reduce((s,v)=>s+v,0)+1e-9,'指定总量与上下界不相容');
    const center=b.lb.map((v,j)=>(v+b.ub[j])/2),scale=b.lb.map((v,j)=>(b.ub[j]-v)/2||1),norm=x=>x.map((v,j)=>(v-center[j])/scale[j]),denorm=x=>x.map((v,j)=>center[j]+v*scale[j]);
    const rad=Math.max(...X.map(x=>Math.hypot(...norm(x))));
    const insideBox=x=>x.every((v,j)=>v>=lb[j]-1e-7*Math.max(1,Math.abs(lb[j]))&&v<=ub[j]+1e-7*Math.max(1,Math.abs(ub[j])));
    let vertices;
    if(type==='hull'){
      vertices=[...new Map(X.filter(insideBox).map(x=>[JSON.stringify(x),x])).values()];assert(vertices.length,'当前边界内没有实测点；请放宽边界或选择箱体范围');
      if(total!==null&&total!==undefined){const sums=vertices.map(x=>x.reduce((s,v)=>s+v,0)),cross=[];
        for(let i=0;i<vertices.length;i++){if(Math.abs(sums[i]-total)<1e-9)cross.push(vertices[i]);for(let j=i+1;j<vertices.length;j++)if((sums[i]-total)*(sums[j]-total)<0){const t=(total-sums[i])/(sums[j]-sums[i]);cross.push(vertices[i].map((v,k)=>v+t*(vertices[j][k]-v)));}}
        assert(cross.length,'总量平面未穿过当前边界内实测点的凸包');assert(cross.length<=30000,'总量约束产生过多交点，请缩小输入数据范围');vertices=cross;
      }
      vertices=vertices.map(norm);
    }
    function sumBox(v){if(total===null||total===undefined)return v.map((a,j)=>clamp(a,lb[j],ub[j]));let lo=Math.min(...v.map((a,j)=>a-ub[j])),hi=Math.max(...v.map((a,j)=>a-lb[j]));for(let k=0;k<70;k++){const mid=(lo+hi)/2,s=v.reduce((s,a,j)=>s+clamp(a-mid,lb[j],ub[j]),0);if(s>total)lo=mid;else hi=mid;}return v.map((a,j)=>clamp(a-(lo+hi)/2,lb[j],ub[j]));}
    function project(x){
      let q;
      if(type==='hull')q=denorm(hullProject(vertices,norm(x)).x);
      else if(type==='box')q=sumBox(x);
      else {
        const ln=norm(lb),un=norm(ub),target=total==null?null:total-center.reduce((s,v)=>s+v,0);
        const boxPlane=v=>{if(target===null)return v.map((a,j)=>clamp(a,ln[j],un[j]));let lo=Math.min(...v.map((a,j)=>(a-un[j])/scale[j])),hi=Math.max(...v.map((a,j)=>(a-ln[j])/scale[j]));for(let k=0;k<75;k++){const mid=(lo+hi)/2,s=v.reduce((s,a,j)=>s+scale[j]*clamp(a-mid*scale[j],ln[j],un[j]),0);if(s>target)lo=mid;else hi=mid;}return v.map((a,j)=>clamp(a-(lo+hi)/2*scale[j],ln[j],un[j]));};
        let n=norm(x),e1=x.map(()=>0),e2=x.map(()=>0);for(let k=0;k<1000;k++){const a=n.map((v,j)=>v+e1[j]),s=boxPlane(a);e1=a.map((v,j)=>v-s[j]);const v=s.map((v,j)=>v+e2[j]),len=Math.hypot(...v),next=len>rad?v.map(a=>a*rad/len):v;e2=v.map((v,j)=>v-next[j]);const diff=Math.hypot(...next.map((v,j)=>v-n[j]));n=next;q=denorm(n);if(diff<1e-10&&insideBox(q)&&(total==null||Math.abs(q.reduce((a,b)=>a+b,0)-total)<1e-7))break;}
      }
      assert(insideBox(q)&&(total==null||Math.abs(q.reduce((a,b)=>a+b,0)-total)<1e-6*Math.max(1,Math.abs(total)))&&(type!=='sphere'||Math.hypot(...norm(q))<=rad+1e-7),'约束无可行交集，或投影未收敛，请检查边界、总量与寻优范围');for(let j=0;j<d;j++)x[j]=q[j];return x;
    }
    project(lb.map((v,j)=>(v+ub[j])/2));
    const describe=type==='hull'?'边界内实测点的凸包':type==='sphere'?'数据包围球（球内仍可能外推）':'箱体（可能包含外推组合）';
    return {lb,ub,project,type,describe,total,retained:type==='hull'?X.filter(insideBox).length:X.length};
  }
  function optimize(m,X,o,progress=()=>{}){
    const r=region(X,o),direction=o.target===-1?-1:1,np=o.np??40,maxIter=o.maxIter??60;
    assert(Number.isInteger(np)&&np>=4&&np<=300&&Number.isInteger(maxIter)&&maxIter>=1&&maxIter<=3000,'种群必须为 4～300，迭代次数为 1～3000');
    seed(o.seed,'optimization-'+(o.algo||'PSO'));
    // Collect actual objective evaluations without consuming randomness or reevaluating the model.
    const trace={version:1,population:np,target:direction===1?'max':'min',generations:[],evaluations:[],evaluationCount:0,limit:50000,truncated:false};
    let seen=direction===1?-Infinity:Infinity;
    const onEvaluation=(generation,individual,fit)=>{const value=direction*fit;seen=direction===1?Math.max(seen,value):Math.min(seen,value);trace.evaluationCount++;if(trace.evaluations.length<trace.limit)trace.evaluations.push([generation,individual+1,value,seen]);else trace.truncated=true;};
    const onGeneration=(generation,fits,best)=>{const values=fits.map(v=>direction*v);let min=Infinity,max=-Infinity,sum=0;for(const v of values){min=Math.min(min,v);max=Math.max(max,v);sum+=v;}trace.generations.push({generation,count:values.length,best:direction===1?max:min,mean:sum/values.length,worst:direction===1?min:max,historicalBest:direction*best});};
    const res=(o.algo==='WSO'?ML.runWSO:ML.runPSO)({...o,lb:r.lb,ub:r.ub,np,maxIter,c1:o.c1??2,c2:o.c2??2,wMax:o.wMax??.9,wMin:o.wMin??.4,project:r.project,onEvaluation,onGeneration,objective:x=>{const v=m.predict(x);assert(Number.isFinite(v),'模型预测为非有限数');return direction*v;},onIter:(it,total,value,best)=>progress({phase:'配比寻优',done:it,total,value:direction*value,best})});
    const result={best:res.best,fitness:direction*res.fitness,history:res.history.map(v=>direction*v),trace,domain:{type:r.type,describe:r.describe,retained:r.retained,total:r.total??null},seed:o.seed};
    if(r.type!=='hull'){const b=bounds(X),c=b.lb.map((v,j)=>(v+b.ub[j])/2),s=b.lb.map((v,j)=>(b.ub[j]-v)/2||1);const hp=hullProject(X.map(row=>row.map((v,j)=>(v-c[j])/s[j])),res.best.map((v,j)=>(v-c[j])/s[j]),2000);result.hullStatus=hp.lowerBound>1e-10?'outside':hp.dist<1e-10?'inside':'uncertain';}else result.hullStatus='inside';
    return result;
  }
  async function compare(X,y,o,progress){const svr=await crossPredict(X,y,o,progress),rsm=await crossPredict(X,y,o,progress,true),full=await fitSelected(X,y,o,progress,'compare-final');
    seed(o.seed,'compare-rsm-fit');const rsmFull=STATS.analyze(X,y,{select:'none'}),rsmOpt=optimize({predict:x=>rsmFull.predict(x).yhat},X,{...o,algo:'PSO'},progress),svrOpt=optimize(full.model,X,{...o,algo:'PSO'},progress);
    const groupDiff=groups(X,o.grouped).map(g=>mean(g.map(i=>Math.abs(y[i]-rsm.pred[i])-Math.abs(y[i]-svr.pred[i]))));
    return {svr:{...svr.metrics,pred:svr.pred},rsm:{...rsm.metrics,pred:rsm.pred},folds:svr.models.map(m=>({train:m.train,test:m.test})),wilcoxon:wilcoxon(groupDiff),svrOpt,rsmOpt};
  }
  async function importance(X,y,o,progress){const cv=await crossPredict(X,y,o,progress),base=cv.metrics,repeat=o.repeats??30,results=[];assert(repeat>=5&&repeat<=200,'重要性重复次数超出范围');seed(o.seed,'importance-shuffle');
    for(let j=0;j<X[0].length;j++){const drops=[];for(let k=0;k<repeat;k++){const pred=new Array(y.length);for(const f of cv.models){const mod=restore(f.model),col=shuffleIdx(f.test.length).map(i=>X[f.test[i]][j]);f.test.forEach((id,i)=>{const x=X[id].slice();x[j]=col[i];pred[id]=mod.predict(x);});}drops.push(score(y,pred).rmse-base.rmse);}const meanDrop=mean(drops),sd=Math.sqrt(mean(drops.map(v=>(v-meanDrop)**2)));results.push({j,mean:meanDrop,sd});progress({phase:'留出集置换重要性',done:j+1,total:X[0].length});await pause();}return {base,results:results.sort((a,b)=>b.mean-a.mean),repeats:repeat};}
  async function permutation(X,y,o,progress){
    assert(groups(X,true).every(g=>g.length===1)||!o.grouped,'检测到同配比重复试验。逐行响应置换不满足当前分组交换假设，已停止；请先在外部按独立试验单位整理数据，或使用分组交叉验证评估，不要把重复点当独立样本做置换显著性结论。');
    const B=o.perms??99;assert(Number.isInteger(B)&&B>=19&&B<=999,'置换次数范围为 19～999');const observed=await crossPredict(X,y,o,progress);let ge=0;const nulls=[];
    for(let k=0;k<B;k++){seed(o.seed,'response-permutation-'+k);const yp=shuffleIdx(y.length).map(i=>y[i]);const cv=await crossPredict(X,yp,o,()=>{});const v=cv.metrics.r2;assert(Number.isFinite(v),'置换检验产生无效指标');nulls.push(v);if(v>=observed.metrics.r2)ge++;progress({phase:'完整流程响应置换',done:k+1,total:B});await pause();}
    return {observed:observed.metrics.r2,p:(ge+1)/(B+1),perms:B,nullMean:mean(nulls),nullMax:Math.max(...nulls)};
  }
  async function bootstrap(X,y,o,progress){
    const B=o.B??200;assert(Number.isInteger(B)&&B>=20&&B<=1000,'Bootstrap 次数应为 20～1000');assert(o.x0?.length===X[0].length,'必须明确选择评估点');
    const m=restore(o.model),cv=await crossPredict(X,y,{...o,grid:false,C:m.C,gamma:m.gamma,standardize:m.std},progress),raw=y.map((v,i)=>v-cv.pred[i]),av=mean(raw),residuals=raw.map(v=>v-av),yh=X.map(x=>m.predict(x)),pred=[],pi=[],optX=[],optY=[];
    seed(o.seed,'residual-bootstrap');for(let k=0;k<B;k++){const yb=yh.map(v=>v+residuals[Math.floor(rnd()*residuals.length)]),mod=ML.trainSVR(X,yb,{C:m.C,gamma:m.gamma,eps:m.eps,standardize:m.std});const p=mod.predict(o.x0);pred.push(p);pi.push(p+residuals[Math.floor(rnd()*residuals.length)]);const opt=optimize(mod,X,{...o,np:24,maxIter:40,seed:hash(o.seed+':boot-opt:'+k)},()=>{});optX.push(opt.best);optY.push(opt.fitness);progress({phase:'残差重采样',done:k+1,total:B});await pause();}
    const ci=a=>{const s=a.slice().sort((a,b)=>a-b);return [STATS.percentile(s,.025),STATS.percentile(s,.975)];};return {B,x0:o.x0,yhat:m.predict(o.x0),predCI:ci(pred),predPI:ci(pi),optYCI:ci(optY),xCI:X[0].map((_,j)=>ci(optX.map(x=>x[j]))),fullOpt:optimize(m,X,o,()=>{}),assumptions:'固定设计、固定超参数、同方差残差重采样；不覆盖选参与试验设计不确定性'};
  }
  function latinHypercube(n,d,randomSeed){assert(Number.isInteger(n)&&n>=6&&n<=500&&Number.isInteger(d)&&d>=1&&d<=6,'LHS 需要 6～500 个点、1～6 个因素');seed(randomSeed,'lhs-design');const rows=Array.from({length:n},()=>Array(d));for(let j=0;j<d;j++){const order=shuffleIdx(n);for(let i=0;i<n;i++)rows[i][j]=(order[i]+rnd())/n;}return rows;}
  async function predictNew(X,y,m,queries,actuals,progress){assert(Array.isArray(queries)&&queries.length>=1&&queries.length<=500,'每批预测需要 1～500 行');assert(queries.every(q=>q.length===X[0].length&&q.every(Number.isFinite)),'预测数据维度或数值无效');assert(!actuals||(actuals.length===queries.length&&actuals.every(v=>v===null||Number.isFinite(v))),'实测响应应为数值或空值');const b=bounds(X),c=b.lb.map((v,j)=>(v+b.ub[j])/2),s=b.lb.map((v,j)=>(b.ub[j]-v)/2||1),norm=q=>q.map((v,j)=>(v-c[j])/s[j]),vertices=X.map(norm),rows=[];
    for(let i=0;i<queries.length;i++){const x=queries[i],pred=m.predict(x);assert(Number.isFinite(pred),'第 '+(i+1)+' 行预测不是有限数');const known=X.some(r=>r.every((v,j)=>Math.abs(v-x[j])<=1e-9*s[j])),outside=x.some((v,j)=>v<b.lb[j]-1e-9*s[j]||v>b.ub[j]+1e-9*s[j]);let hullStatus='inside';if(!known){if(outside)hullStatus='outside';else{const hp=hullProject(vertices,norm(x),2000);hullStatus=hp.dist<1e-10?'inside':hp.lowerBound>1e-10?'outside':'uncertain';}}const actual=actuals?.[i]??null;rows.push({x:x.slice(),pred,actual,error:actual===null?null:pred-actual,known,hullStatus});progress({phase:'新配比预测',done:i+1,total:queries.length});if(i%20===0)await pause();}
    const measured=rows.filter(r=>r.actual!==null);return {rows,nMeasured:measured.length,knownInputs:rows.filter(r=>r.known).length,metrics:measured.length>=2?score(measured.map(r=>r.actual),measured.map(r=>r.pred)):null};
  }
  async function run(task,p,progress=()=>{}){const {X,y,o}=p;assert(Array.isArray(X)&&X.length===y.length&&X.length>1,'计算数据缺失');seed(o.seed,task);
    if(task==='predict')return predictNew(X,y,restore(p.model),p.queries,p.actuals,progress);
    if(task==='train')return train(X,y,o,progress);if(task==='optimize')return optimize(restore(p.model),X,o,progress);if(task==='compare')return compare(X,y,o,progress);if(task==='cv')return crossPredict(X,y,o,progress);if(task==='importance')return importance(X,y,o,progress);if(task==='permutation')return permutation(X,y,o,progress);if(task==='bootstrap')return bootstrap(X,y,o,progress);throw new Error('未知计算任务');}
  return {VERSION,hash,seed,pack,restore,score,groups,folds,grid,crossPredict,train,wilcoxon,bounds,region,hullProject,optimize,latinHypercube,predictNew,run};
})();
window.Engine=Engine;
