/* v2.0.6: real search diagnostics, independent of optimizer decisions. */
const SearchTrace=(()=>{
  const colors={best:'#168267',mean:'#2879df',worst:'#8c96a8',history:'#d94b3c',point:'rgba(45,120,220,.38)'};
  let geometry=null,selection=null,background=null;
  function clearSelection(){selection=null;const canvas=$('#chart-line');if(canvas){delete canvas.dataset.selectedEvaluation;delete canvas.dataset.highlightState;canvas.style.cursor='default';}}
  function valid(r){
    const t=r?.trace;if(!t||t.version!==1||!['max','min'].includes(t.target)||!Array.isArray(t.generations)||!t.generations.length||t.generations.length>3001||!Array.isArray(t.evaluations)||t.evaluations.length>50000||!Number.isSafeInteger(t.evaluationCount))return null;
    if(!t.generations.every((g,i)=>g.generation===i&&Number.isInteger(g.count)&&g.count>0&&['best','mean','worst','historicalBest'].every(k=>Number.isFinite(g[k]))))return null;
    if(!t.evaluations.every(e=>Array.isArray(e)&&e.length===4&&e.every(Number.isFinite)&&Number.isInteger(e[0])&&e[0]>=0&&e[0]<t.generations.length&&Number.isInteger(e[1])&&e[1]>0&&e[1]<=t.population))return null;
    if(t.generations.reduce((n,g)=>n+g.count,0)!==t.evaluationCount||t.evaluationCount<t.evaluations.length||(!t.truncated&&t.evaluationCount!==t.evaluations.length)||t.generations.length!==r.history.length)return null;
    return t;
  }
  function range(values){let low=Infinity,high=-Infinity;for(const v of values){low=Math.min(low,v);high=Math.max(high,v);}const margin=(high-low||Math.max(Math.abs(high)*.05,1))*.09;return [low-margin,high+margin];}
  function render(){
    const r=State.result,canvas=$('#chart-line');if(!r||!canvas)return;
    const t=valid(r),select=$('#trace-view'),mode=select?.value||'generation';
    const notice=$('#trace-notice'),bar=document.querySelector('#dap-iter .iter-bar');
    const hideBar=!!t&&mode!=='history';
    if(bar){bar.hidden=hideBar;bar.style.display=hideBar?'none':'';}
    const wrap=document.querySelector('#dap-iter .iter-wrap');if(wrap)wrap.style.gridTemplateColumns=hideBar?'minmax(0,1fr)':'';
    $('#trace-export').disabled=!t;$('#trace-png').disabled=false;$('#trace-tiff').disabled=false;
    const previous=geometry;
    geometry=null;background=null;
    if(!t||mode==='history'){
      clearSelection();originalDraw(r.history,r.algo,r.bestY);canvas.style.height='300px';$('#trace-legend').textContent='历史最好值：截至该代找到的最好预测值。';
      notice.textContent=t?'':r.trace?'过程记录不完整或格式不受支持，当前仅显示历史最好值。请重新寻优。':'旧结果只保存了历史最好值，无法还原搜索波动。请重新寻优生成过程记录。';
      $('#cap-line').textContent='第0代为初始种群；历史最好值在最大化时只升不降，最小化时只降不升。';
      $('#trace-hover').textContent='当前显示历史最好值。';return;
    }
    const scatter=mode==='evaluation',gens=t.generations,points=t.evaluations;
    $('#trace-legend').innerHTML=(scatter?[['point','每次预测'],['history','截至该次的历史最好值']]:[['best','本代最好'],['mean','本代平均'],['worst','本代最差'],['history','历史最好']]).map(([k,label])=>'<span style="display:inline-block;margin:0 20px 6px 0"><span style="color:'+colors[k]+'">●</span> '+label+'</span>').join('');
    notice.textContent=(scatter?'按评价顺序展示每次真实预测，包含初始化和重复配比，不代表沿空间连续移动。':'每代统计来自这一代个体当前位置的预测值，不是个体历史最优。')+(t.truncated?' 大规模记录：共评价'+t.evaluationCount+'次，散点和明细仅保留前'+points.length+'次；每代统计完整。':'');
    const W=canvas.clientWidth||800,H=370,dpr=window.devicePixelRatio||1;
    canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr);canvas.style.height=H+'px';
    const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#fff';ctx.fillRect(0,0,W,H);
    const pad={l:82,r:22,t:29,b:53},pw=Math.max(1,W-pad.l-pad.r),ph=H-pad.t-pad.b;
    const ys=scatter?points.flatMap(e=>[e[2],e[3]]):gens.flatMap(g=>[g.best,g.mean,g.worst,g.historicalBest]);
    const [low,high]=range(ys),xmin=scatter?1:0,xmax=scatter?Math.max(1,points.length):gens.length-1;
    const X=x=>pad.l+(xmax===xmin?pw/2:(x-xmin)/(xmax-xmin)*pw),Y=v=>pad.t+(high-v)/(high-low)*ph;
    ctx.font='12px "Microsoft YaHei",sans-serif';ctx.textBaseline='middle';
    const number=v=>Math.abs(v)>=1e6||Math.abs(v)>0&&Math.abs(v)<.001?v.toExponential(2):fmt(v,2);
    for(let k=0;k<=5;k++){const value=low+(high-low)*k/5,y=Y(value);ctx.strokeStyle='#e7edf6';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(W-pad.r,y);ctx.stroke();ctx.fillStyle='#61748e';ctx.textAlign='right';ctx.fillText(number(value),pad.l-10,y);}
    ctx.fillStyle='#61748e';ctx.textAlign='left';ctx.fillText('预测响应'+(r.unit?' / '+r.unit:''),pad.l,13);
    const ticks=new Set(Array.from({length:7},(_,k)=>Math.round(xmin+(xmax-xmin)*k/6)));
    for(const x of ticks){ctx.textAlign=x===xmin?'left':x===xmax?'right':'center';ctx.fillText(String(x),X(x),H-pad.b+17);}
    ctx.textAlign='center';ctx.fillText(scatter?'预测评价序号（包含初始化）':'迭代代数（0为初始种群）',pad.l+pw/2,H-12);
    function line(data,key,color,dashed=false){ctx.beginPath();data.forEach((v,i)=>i?ctx.lineTo(X(v[0]),Y(v[1])):ctx.moveTo(X(v[0]),Y(v[1])));ctx.strokeStyle=color;ctx.lineWidth=key==='history'?2.7:1.5;ctx.setLineDash(dashed?[7,4]:[]);ctx.stroke();ctx.setLineDash([]);}
    if(scatter){ctx.fillStyle=colors.point;for(let i=0;i<points.length;i++){ctx.beginPath();ctx.arc(X(i+1),Y(points[i][2]),points.length>10000?1.2:2,0,Math.PI*2);ctx.fill();}line(points.map((e,i)=>[i+1,e[3]]),'history',colors.history);}
    else {for(const key of ['worst','mean','best','history'])line(gens.map(g=>[g.generation,g[key==='history'?'historicalBest':key]]),key,colors[key],key==='history');}
    geometry={scatter,t,xmin,xmax,pad,pw,ph,W,H,dpr,X,Y};
    if(!scatter||previous?.t!==t||!previous?.scatter)clearSelection();
    background=document.createElement('canvas');background.width=canvas.width;background.height=canvas.height;background.getContext('2d').drawImage(canvas,0,0);
    $('#iter-cap').textContent=r.algo+' · '+(gens.length-1)+'次更新 · '+t.evaluationCount+'次预测评价';
    $('#cap-line').textContent=scatter?'散点表示每次预测，红线保留历史最好值。共显示'+points.length+'次评价。':'共'+gens.length+'组统计（含第0代）；最大化时最好取最大值，最小化时最好取最小值。';
    $('#trace-hover').textContent=scatter?'靠近蓝色散点预览，点击高亮并锁定；点击空白处取消选择。':'移动鼠标查看每代最好、平均、最差和历史最好值。';
    if(selection&&scatter)highlight(selection.index,true);
  }
  // Hit testing uses BOTH screen coordinates, with an 8 CSS-pixel tolerance.
  // Restrict the scan to nearby x positions, then pick the nearest actual blue point.
  function hit(event){const g=geometry;if(!g?.scatter)return null;const canvas=$('#chart-line'),box=canvas.getBoundingClientRect();if(!box.width||!box.height)return null;
    const px=event.clientX-box.left,py=event.clientY-box.top,scaleX=box.width/g.W,scaleY=box.height/g.H,radius=8;
    if(px<g.pad.l*scaleX-radius||px>(g.W-g.pad.r)*scaleX+radius||py<g.pad.t*scaleY-radius||py>(g.H-g.pad.b)*scaleY+radius)return null;
    const inverse=x=>g.xmax===g.xmin?1:g.xmin+(x/scaleX-g.pad.l)/g.pw*(g.xmax-g.xmin);
    const first=Math.max(1,Math.floor(inverse(px-radius))),last=Math.min(g.t.evaluations.length,Math.ceil(inverse(px+radius)));
    let best=null,distance=radius*radius;
    for(let n=first;n<=last;n++){const e=g.t.evaluations[n-1],dx=g.X(n)*scaleX-px,dy=g.Y(e[2])*scaleY-py,d=dx*dx+dy*dy;if(d<=distance&&(best===null||d<distance)){best=n-1;distance=d;}}
    return best;
  }
  function restoreBackground(){if(!background||!geometry)return;const ctx=$('#chart-line').getContext('2d');ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,background.width,background.height);ctx.drawImage(background,0,0);ctx.restore();}
  function highlight(index,locked){const g=geometry,e=g?.t.evaluations[index];if(!g?.scatter||!e)return;restoreBackground();const canvas=$('#chart-line'),ctx=canvas.getContext('2d'),x=g.X(index+1),y=g.Y(e[2]);
    ctx.save();ctx.setTransform(g.dpr,0,0,g.dpr,0,0);ctx.strokeStyle=locked?'#b95c00':'#2267b8';ctx.lineWidth=1;ctx.setLineDash([4,4]);ctx.beginPath();ctx.moveTo(g.pad.l,y);ctx.lineTo(g.W-g.pad.r,y);ctx.moveTo(x,g.pad.t);ctx.lineTo(x,g.H-g.pad.b);ctx.stroke();ctx.setLineDash([]);
    ctx.beginPath();ctx.arc(x,y,8,0,Math.PI*2);ctx.fillStyle='#fff';ctx.fill();ctx.strokeStyle=locked?'#d36a00':'#2267b8';ctx.lineWidth=2.5;ctx.stroke();ctx.beginPath();ctx.arc(x,y,3.2,0,Math.PI*2);ctx.fillStyle=locked?'#d36a00':'#2267b8';ctx.fill();
    const label=(locked?'已选中':'预览')+' 第'+(index+1)+'次';ctx.font='12px "Microsoft YaHei",sans-serif';const tw=ctx.measureText(label).width+16,lx=Math.max(g.pad.l,Math.min(g.W-g.pad.r-tw,x+12)),ly=y>g.pad.t+36?y-29:y+13;ctx.fillStyle=locked?'#a95200':'#225e9e';ctx.fillRect(lx,ly,tw,24);ctx.fillStyle='#fff';ctx.textAlign='left';ctx.textBaseline='middle';ctx.fillText(label,lx+8,ly+12);ctx.restore();
    canvas.dataset.selectedEvaluation=String(index+1);canvas.dataset.highlightState=locked?'selected':'hover';
    $('#trace-hover').textContent=(locked?'已选中':'预览')+'：第'+(index+1)+'次评价 · 第'+e[0]+'代 · 个体'+e[1]+' · 本次预测 '+fmt(e[2],4)+' '+(State.result?.unit||'')+' · 截至该次历史最好 '+fmt(e[3],4)+' '+(State.result?.unit||'');
  }
  function rows(r){const t=valid(r);if(!t)return null;return [['软件版本','2.0.6'],['算法',r.algo],['响应单位',r.unit||''],['目标',t.target==='min'?'最小化':'最大化'],['总预测评价次数',t.evaluationCount],['保留评价次数',t.evaluations.length],['明细截断',t.truncated?'是（仅前50000次）':'否'],[],['代数','个体数','本代最好','本代平均','本代最差','历史最好'],...t.generations.map(g=>[g.generation,g.count,g.best,g.mean,g.worst,g.historicalBest]),[],['评价序号','代数','个体编号','预测响应','截至该次历史最好'],...t.evaluations.map((e,i)=>[i+1,...e])];}
  const originalDraw=drawIterChart;
  drawIterChart=function(hist,algo,bestY){if(State.result&&hist===State.result.history)render();else originalDraw(hist,algo,bestY);};
  const originalRender=renderResult;
  renderResult=function(){originalRender();if(State.result)render();};
  const originalExport=exportRunRecord;
  exportRunRecord=function(r){const extra=rows(r);if(!extra){originalExport(r);return;}const resultRows=[['软件版本','2.0.6'],['记录时间',r.createdAt],['试验方案',State.dataset?.name||''],['算法',r.algo],['候选预测值',r.bestY],['单位',r.unit],['随机种子',r.seed],['寻优范围',r.domain?.describe],['总量约束',r.domain?.total??'无'],['参数 JSON',JSON.stringify(r.params||{})],['模型信息 JSON',JSON.stringify(r.modelInfo||{})],...r.bestX.map((v,j)=>[r.headers[r.xIdx[j]],v]),[],...extra];download('svm-ioa-v2.0.6-result.csv',DataIO.toCSV([],resultRows));};
  document.addEventListener('DOMContentLoaded',()=>{
    $('#trace-view').addEventListener('change',render);
    $('#trace-export').addEventListener('click',()=>{const data=rows(State.result);if(data)download('svm-ioa-v2.0.6-search-process.csv',DataIO.toCSV([],data));});
    for (const format of ['png', 'tiff']) {
      $('#trace-' + format).addEventListener('click', async () => {
        if (!State.result) { toast('请先完成寻优'); return; }
        try {
          render();
          await exportCanvasImage($('#chart-line'), 'svm-ioa-search-' + $('#trace-view').value, format);
        } catch (error) {
          toast('图片导出失败：' + error.message);
        }
      });
    }
    const canvas=$('#chart-line');
    canvas.addEventListener('mousemove',event=>{const g=geometry;if(!g)return;
      if(g.scatter){const index=hit(event);canvas.style.cursor=index===null?'default':'pointer';if(selection)return;if(index!==null)highlight(index,false);else{restoreBackground();delete canvas.dataset.selectedEvaluation;delete canvas.dataset.highlightState;$('#trace-hover').textContent='当前位置未命中散点，请靠近蓝色点；点击可高亮并锁定。';}return;}
      const box=canvas.getBoundingClientRect(),px=(event.clientX-box.left)*g.W/box.width,index=Math.max(g.xmin,Math.min(g.xmax,Math.round(g.xmin+(px-g.pad.l)/g.pw*(g.xmax-g.xmin)))),row=g.t.generations[index];if(row)$('#trace-hover').textContent='第'+index+'代 · 最好'+fmt(row.best,4)+' · 平均'+fmt(row.mean,4)+' · 最差'+fmt(row.worst,4)+' · 历史最好'+fmt(row.historicalBest,4)+' '+(State.result?.unit||'');
    });
    canvas.addEventListener('click',event=>{if(!geometry?.scatter)return;const index=hit(event);if(index===null){clearSelection();restoreBackground();$('#trace-hover').textContent='未选中散点。请点击蓝色点附近，命中后会显示高亮圆环和评价序号。';}else{selection={index};highlight(index,true);}});
    canvas.addEventListener('mouseleave',()=>{if(!geometry?.scatter||selection)return;restoreBackground();delete canvas.dataset.selectedEvaluation;delete canvas.dataset.highlightState;$('#trace-hover').textContent='靠近蓝色散点预览，点击高亮并锁定；点击空白处取消选择。';});
    if(State.result)render();else {$('#trace-export').disabled=true;$('#trace-png').disabled=true;$('#trace-tiff').disabled=true;}
  });
  return {valid,render,rows};
})();
