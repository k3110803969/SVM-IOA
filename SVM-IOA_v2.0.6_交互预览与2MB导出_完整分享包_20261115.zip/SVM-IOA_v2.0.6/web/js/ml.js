// ---------- 机器学习核心：ε-SVR（SMO 求解）+ 智能优化算法 ----------
const ML = (() => {
  let _lastSweeps = 0;

  // ================= 核函数 =================
  function rbfMatrix(X, gamma) {
    const n = X.length, K = [];
    for (let i = 0; i < n; i++) K.push(new Float64Array(n));
    for (let i = 0; i < n; i++) {
      for (let j = i; j < n; j++) {
        let s = 0;
        for (let d = 0; d < X[i].length; d++) { const t = X[i][d] - X[j][d]; s += t * t; }
        const v = Math.exp(-gamma * s);
        K[i][j] = v; K[j][i] = v;
      }
    }
    return K;
  }
  function rbfRow(X, x, gamma) {
    return X.map(xi => {
      let s = 0;
      for (let d = 0; d < xi.length; d++) { const t = xi[d] - x[d]; s += t * t; }
      return Math.exp(-gamma * s);
    });
  }

  // ================= ε-SVR 的 SMO 求解 =================
  // 对偶问题： min 1/2 βᵀKβ + ε|β|₁ − yᵀβ , s.t. Σβ=0, |βi|≤C
  // 其中 β = α − α* ，最终 f(x)=ΣβiK(xi,x)+b
  function objDelta(d, gi, gj, eta, bi, bj, abi, abj, eps) {
    const s = bi + d, t = bj - d;
    return (gi - gj) * d + 0.5 * eta * d * d
         + eps * ((s < 0 ? -s : s) - abi)
         + eps * ((t < 0 ? -t : t) - abj);
  }

  function solveSMO(K, y, C, eps, maxSweeps = 3000, tol = 1e-6) {
    const n = y.length;
    const beta = new Float64Array(n);
    const G = new Float64Array(n);           // G = Kβ − y
    for (let i = 0; i < n; i++) G[i] = -y[i];
    const bp = new Float64Array(4);

    function updatePair(i, j) {
      const bi = beta[i], bj = beta[j];
      const eta = K[i][i] + K[j][j] - 2 * K[i][j];
      // Identical inputs still need coefficient transfers when responses differ.
      const lo = Math.max(-C - bi, bj - C);
      const hi = Math.min(C - bi, bj + C);
      if (hi - lo <= 1e-12) return 0;
      const gi = G[i], gj = G[j];
      const abi = bi < 0 ? -bi : bi, abj = bj < 0 ? -bj : bj;
      const k1 = -bi, k2 = bj;
      let m = 0;
      bp[m++] = lo; bp[m++] = hi;
      if (k1 > lo + 1e-12 && k1 < hi - 1e-12) bp[m++] = k1;
      if (k2 > lo + 1e-12 && k2 < hi - 1e-12) bp[m++] = k2;
      for (let a = 1; a < m; a++) {          // 插入排序
        const v = bp[a]; let b = a - 1;
        while (b >= 0 && bp[b] > v) { bp[b + 1] = bp[b]; b--; }
        bp[b + 1] = v;
      }
      let bestD = 0, bestV = 0;
      for (let a = 0; a < m - 1; a++) {
        const A = bp[a], B = bp[a + 1];
        if (B - A < 1e-13) continue;
        const mid = (A + B) * 0.5;
        const sm = bi + mid, tm = bj - mid;
        const s1 = sm > 0 ? 1 : sm < 0 ? -1 : 0;
        const s2 = tm > 0 ? 1 : tm < 0 ? -1 : 0;
        let d = eta > 1e-12 ? ((gj - gi) - eps * (s1 - s2)) / eta : ((gi - gj) + eps * (s1 - s2) > 0 ? A : B);
        if (d < A) d = A; else if (d > B) d = B;
        const v = objDelta(d, gi, gj, eta, bi, bj, abi, abj, eps);
        if (v < bestV - 1e-15) { bestV = v; bestD = d; }
      }
      let v = objDelta(lo, gi, gj, eta, bi, bj, abi, abj, eps);
      if (v < bestV - 1e-15) { bestV = v; bestD = lo; }
      v = objDelta(hi, gi, gj, eta, bi, bj, abi, abj, eps);
      if (v < bestV - 1e-15) { bestV = v; bestD = hi; }
      if (bestD < 1e-11 && bestD > -1e-11) return 0;
      beta[i] += bestD; beta[j] -= bestD;
      const Ki = K[i], Kj = K[j];
      for (let k = 0; k < n; k++) G[k] += bestD * (Ki[k] - Kj[k]);
      return bestD;
    }

    let sweep = 0, maxDelta = Infinity;
    while (sweep < maxSweeps && maxDelta > tol) {
      maxDelta = 0; sweep++;
      for (let i = 0; i < n; i++)
        for (let j = i + 1; j < n; j++) {
          const d = updatePair(i, j);
          const ad = d < 0 ? -d : d;
          if (ad > maxDelta) maxDelta = ad;
        }
    }
    _lastSweeps = sweep;
    return beta;
  }

  function computeB(K, beta, y, C, eps) {
    let lo=-Infinity, hi=Infinity, total=0, count=0;
    for(let i=0;i<y.length;i++) {
      const r=y[i]-beta.reduce((s,v,k)=>s+v*K[i][k],0),v=beta[i],tol=Math.min(1e-7,C*1e-6);
      if(v>tol && v<C-tol) {total+=r-eps;count++;}
      else if(v<-tol && v>-C+tol) {total+=r+eps;count++;}
      else if(v>=C-tol) hi=Math.min(hi,r-eps);
      else if(v<=-C+tol) lo=Math.max(lo,r+eps);
      else {lo=Math.max(lo,r-eps);hi=Math.min(hi,r+eps);}
    }
    if(count)return total/count;
    if(isFinite(lo)&&isFinite(hi))return (lo+hi)/2;
    return isFinite(lo)?lo:isFinite(hi)?hi:0;
  }

  // ================= 训练 / 预测 =================
  function trainSVR(X, y, opt = {}) {
    const C = opt.C ?? 1.1487, gamma = opt.gamma ?? 0.5, eps = opt.eps ?? 0.0001;
    if(!Array.isArray(X)||X.length<2||X.length!==y.length||!Array.isArray(X[0])||!X[0].length||X.some(r=>r.length!==X[0].length||r.some(v=>!Number.isFinite(v)))||y.some(v=>!Number.isFinite(v)))throw new Error('SVR 输入必须是等长有限数值，至少两行');
    if(!(C>0&&gamma>0&&eps>=0&&[C,gamma,eps].every(Number.isFinite)))throw new Error('要求 C>0、γ>0、ε≥0');
    const std = opt.standardize !== false;
    const dim = X[0].length, n = X.length;
    let xs = X, ys = y.slice(), xMean, xStd, yMean, yStd;
    if (std) {
      xMean = [], xStd = [];
      for (let d = 0; d < dim; d++) {
        const col = X.map(r => r[d]);
        const m = mean(col), s = std0(col) || 1;
        xMean.push(m); xStd.push(s);
      }
      ys = y.slice();
      yMean = mean(y); yStd = std0(y) || 1;
      xs = X.map(r => r.map((v, d) => (v - xMean[d]) / xStd[d]));
      ys = y.map(v => (v - yMean) / yStd);
    }
    const K = rbfMatrix(xs, gamma);
    const beta = solveSMO(K, ys, C, eps / (std ? yStd : 1));
    const b = computeB(K, beta, ys, C, eps / (std ? yStd : 1));
    const svIdx = [];
    for (let i = 0; i < n; i++) if (Math.abs(beta[i]) > 1e-8) svIdx.push(i);

    function predict(x) {
      let xi = x;
      if (std) xi = x.map((v, d) => (v - xMean[d]) / xStd[d]);
      const k = rbfRow(xs, xi, gamma);
      let f = 0;
      for (let i = 0; i < n; i++) if (beta[i]) f += beta[i] * k[i];
      f += b;
      return std ? yMean + yStd * f : f;
    }
    const ee=eps/(std?yStd:1);let kkt=0;
    for(let i=0;i<n;i++) { const r=beta.reduce((s,v,k)=>s+v*K[i][k],0)+b-ys[i], v=beta[i], tt=Math.min(C*1e-6,1e-7);
      const violation=v>=C-tt?Math.max(0,r+ee):v<=-C+tt?Math.max(0,-r+ee):v>tt?Math.abs(r+ee):v<-tt?Math.abs(r-ee):Math.max(0,Math.abs(r)-ee);
      kkt=Math.max(kkt,violation);
    }
    return { predict, beta, b, C, gamma, eps, svIdx, n, std, xMean, xStd, yMean, yStd, _X:X.map(r=>r.slice()), solver:{sweeps:_lastSweeps,kktViolation:kkt,converged:kkt<1e-3} };
  }

  function std0(a) {
    const m = mean(a);
    return Math.sqrt(a.reduce((s, v) => s + (v - m) * (v - m), 0) / a.length);
  }
  function r2(actual, pred) {
    const m = mean(actual);
    let ssr = 0, sst = 0;
    for (let i = 0; i < actual.length; i++) { ssr += (actual[i] - pred[i]) ** 2; sst += (actual[i] - m) ** 2; }
    return 1 - ssr / (sst || 1e-12);
  }
  function rmse(actual, pred) {
    return Math.sqrt(actual.reduce((s, v, i) => s + (v - pred[i]) ** 2, 0) / actual.length);
  }

  // ================= 网格搜索 + 交叉验证 =================
  function gridSearchCV(X, y, o) {
    const folds = o.folds || 5, eps = o.eps ?? 0.0001;
    const idx = shuffleIdx(X.length);
    const foldSize = Math.ceil(X.length / folds);
    let best = { rmse: Infinity, C: o.CList[0], gamma: o.GList[0] };
    o.CList.forEach(C => o.GList.forEach(g => {
      let tot = 0, cnt = 0;
      for (let f = 0; f < folds; f++) {
        const test = idx.slice(f * foldSize, (f + 1) * foldSize);
        const train = idx.filter(i => !test.includes(i));
        if (!train.length || !test.length) continue;
        const m = trainSVR(train.map(i => X[i]), train.map(i => y[i]), { C, gamma: g, eps, standardize: o.standardize !== false });
        test.forEach(i => { const p = m.predict(X[i]); tot += (p - y[i]) ** 2; cnt++; });
      }
      const cvRmse = Math.sqrt(tot / (cnt || 1));
      if (cvRmse < best.rmse) best = { rmse: cvRmse, C, gamma: g };
    }));
    return best;
  }

  // ================= PSO =================
  function runPSO(o) {
    const dim = o.lb.length, n = o.np;
    const X = [], V = [], pb = [], pbf = [];
    for (let i = 0; i < n; i++) {
      const x = o.lb.map((l, d) => l + rnd() * (o.ub[d] - l));
      if (o.project) o.project(x);
      X.push(x); V.push(x.map(() => 0)); pb.push(x.slice());
      pbf.push(o.objective(x));
      if(o.onEvaluation)o.onEvaluation(0,i,pbf[i]);
    }
    let gi = 0; pbf.forEach((f, i) => { if (f > pbf[gi]) gi = i; });
    let gbest = pb[gi].slice(), gbestF = pbf[gi];
    const history = [gbestF];
    if(o.onGeneration)o.onGeneration(0,pbf,gbestF);
    for (let t = 0; t < o.maxIter; t++) {
      const current=[];
      const w = o.wMax - (o.wMax - o.wMin) * t / o.maxIter;
      for (let i = 0; i < n; i++) {
        for (let d = 0; d < dim; d++) {
          V[i][d] = w * V[i][d]
                  + o.c1 * rnd() * (pb[i][d] - X[i][d])
                  + o.c2 * rnd() * (gbest[d] - X[i][d]);
          X[i][d] = clamp(X[i][d] + V[i][d], o.lb[d], o.ub[d]);
        }
        if (o.project) o.project(X[i]);
        const f = o.objective(X[i]);
        current.push(f);if(o.onEvaluation)o.onEvaluation(t+1,i,f);
        if (f > pbf[i]) { pbf[i] = f; pb[i] = X[i].slice(); }
        if (f > gbestF) { gbestF = f; gbest = X[i].slice(); }
      }
      history.push(gbestF);
      if(o.onGeneration)o.onGeneration(t+1,current,gbestF);
      if (o.onIter) o.onIter(t + 1, o.maxIter, gbestF, gbest);
      if (o.shouldStop && o.shouldStop()) break;
    }
    return { best: gbest, fitness: gbestF, history };
  }

  // ================= WSO（白鲨优化算法） =================
  // 参考 Braik et al. (2022) 及 Zhu et al. (2026)
  function runWSO(o) {
    const dim = o.lb.length, n = o.np;
    const pmin = o.pmin ?? 0.5, pmax = o.pmax ?? 2.5, a0 = o.a0 ?? 6, a1 = o.a1 ?? 100, a2 = o.a2 ?? 0.0005, tau = 4.125;
    const mu = 2 / Math.abs(2 - tau - Math.sqrt(tau * tau - 4 * tau));
    const X = [], V = [], pb = [], pbf = [];
    for (let i = 0; i < n; i++) {
      const x = o.lb.map((l, d) => l + rnd() * (o.ub[d] - l));
      if (o.project) o.project(x);
      X.push(x); V.push(x.map(() => rnd()));
      pb.push(x.slice()); pbf.push(o.objective(x));
      if(o.onEvaluation)o.onEvaluation(0,i,pbf[i]);
    }
    let gi = 0; pbf.forEach((f, i) => { if (f > pbf[gi]) gi = i; });
    let gbest = pb[gi].slice(), gbestF = pbf[gi];
    const history = [gbestF], T = o.maxIter;
    if(o.onGeneration)o.onGeneration(0,pbf,gbestF);

    for (let t = 0; t < T; t++) {
      const current=[];
      const Mv = 1 / (a0 + Math.exp((T / 2 - t) / a1));
      const Ss = Math.abs(1 - Math.exp(-a2 * t / T));
      const e = Math.exp(-Math.pow(4 * t / T, 2));
      const p1 = pmax + (pmax - pmin) * e;
      const p2 = pmin + (pmax - pmin) * e;
      for (let i = 0; i < n; i++) {
        for (let d = 0; d < dim; d++) {
          V[i][d] = mu * (V[i][d] + p1 * (pb[i][d] - X[i][d]) * rnd()
                                  + p2 * (gbest[d] - X[i][d]) * rnd());
        }
        const r0 = rnd();
        if (r0 < Mv) {
          // 随机边界探索
          for (let d = 0; d < dim; d++) X[i][d] = o.lb[d] + rnd() * (o.ub[d] - o.lb[d]);
        } else {
          const f = 0.07 + (0.75 - 0.07) * rnd();
          for (let d = 0; d < dim; d++) X[i][d] = X[i][d] + V[i][d] / f;
          if (rnd() < Ss) {
            // 群体协作：向邻近最优个体靠拢
            let eta = 0;
            for (let d = 0; d < dim; d++) eta += (X[i][d] - gbest[d]) ** 2;
            eta = Math.sqrt(eta);
            for (let d = 0; d < dim; d++) {
              const next = gbest[d] + rnd() * eta * Math.sign(rnd() - 0.5);
              X[i][d] = X[i][d] + next / (2 * (r0 || 1e-6));
            }
          }
        }
        for (let d = 0; d < dim; d++) X[i][d] = clamp(X[i][d], o.lb[d], o.ub[d]);
        if (o.project) o.project(X[i]);
        const fit = o.objective(X[i]);
        current.push(fit);if(o.onEvaluation)o.onEvaluation(t+1,i,fit);
        if (fit > pbf[i]) { pbf[i] = fit; pb[i] = X[i].slice(); }
        if (fit > gbestF) { gbestF = fit; gbest = X[i].slice(); }
      }
      history.push(gbestF);
      if(o.onGeneration)o.onGeneration(t+1,current,gbestF);
      if (o.onIter) o.onIter(t + 1, T, gbestF, gbest);
      if (o.shouldStop && o.shouldStop()) break;
    }
    return { best: gbest, fitness: gbestF, history };
  }

  return { trainSVR, rbfMatrix, gridSearchCV, r2, rmse, runPSO, runWSO,
           get lastSweeps() { return _lastSweeps; } };
})();

window.ML = ML;
