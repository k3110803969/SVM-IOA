// ---------- 通用工具 ----------
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

const State = {
  dataset: null,   // { headers, rows, xIdx:[], yIdx, name, unit }
  model: null,     // { predict, C, gamma, eps, r2, rmse, sv, points, xMean, xStd, yMean, yStd }
  result: null,    // { algo, best, history, algoParams, elapsed }
  algo: 'PSO',
  meta: { name: '软土复合固化剂配比试验', unit: 'kPa', type: '固化剂配比' },
  settings: { seed: null, decimals: 2, exportPrefix: 'svm-ioa', animation: true },
  sig: null,       // 二次多项式（RSM）显著性分析结果
  sigPerm: null,   // SVM 置换检验结果
  notices: []
};

// ---------- 可复现随机数（设置里可指定随机种子） ----------
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
let _rng = Math.random;
function rnd() { return _rng(); }
function setSeed(seed) {
  if (seed === null || seed === undefined || String(seed).trim() === '' || isNaN(Number(seed))) {
    _rng = Math.random; State.settings.seed = null; return null;
  }
  const s = Number(seed) >>> 0;
  _rng = mulberry32(s); State.settings.seed = s; return s;
}

function toast(msg, ms = 2200) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), ms);
}

function fmt(v, d) {
  if (v === null || v === undefined || !isFinite(v)) return '--';
  const n = (d === undefined) ? (State.settings ? State.settings.decimals : 2) : d;
  return Number(v).toFixed(n);
}

function mean(a) { return a.reduce((s, v) => s + v, 0) / a.length; }
function std(a) {
  const m = mean(a);
  return Math.sqrt(a.reduce((s, v) => s + (v - m) * (v - m), 0) / a.length) || 1;
}
function clamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }
function shuffleIdx(n) {
  const a = Array.from({ length: n }, (_, i) => i);
  for (let i = n - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function download(filename, text, mime = 'text/csv;charset=utf-8') {
  // Android 外壳：直接写入系统「下载」目录
  if (window.AndroidHost && window.AndroidHost.saveFile) {
    window.AndroidHost.saveFile(filename, text); return;
  }
  // 桌面窗口版：通过原生桥接调用系统「保存」对话框
  const bridge = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.saveFile;
  if (bridge) { bridge.postMessage({ filename: filename, content: text }); return; }
  const blob = new Blob(['\ufeff' + text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// 导出图片等二进制内容（dataURL 形式传入）
function downloadBinary(filename, dataUrl, mime = 'image/png') {
  const b64 = String(dataUrl).split(',')[1] || '';
  if (window.AndroidHost && window.AndroidHost.saveFileBase64) {
    window.AndroidHost.saveFileBase64(filename, b64, mime); return;
  }
  const bridge = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.saveFile;
  if (bridge) { bridge.postMessage({ filename: filename, base64: b64 }); return; }
  const a = document.createElement('a');
  a.href = dataUrl; a.download = filename;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
}

// 生成示例数据：3 组分掺入比 -> 7d 无侧限抗压强度 qu
function makeDemoDataset() {
  const headers = ['水泥掺入比 w1(%)', '矿粉掺入比 w2(%)', '石膏掺入比 w3(%)', 'qu(7d) (kPa)'];
  const rows = [
    [5.85, 5.51, 6.45, 1090.55], [4.58, 4.10, 1.09, 628.06], [6.20, 5.80, 5.10, 1042.40],
    [5.00, 4.50, 3.20, 812.30], [6.50, 6.20, 7.10, 1120.80], [4.20, 3.80, 2.40, 596.40],
    [5.60, 5.20, 4.80, 985.20], [6.80, 6.50, 6.20, 1156.06], [4.90, 4.30, 3.60, 742.10],
    [5.40, 4.90, 4.10, 903.60], [6.10, 5.60, 5.80, 1064.50], [4.50, 4.00, 1.80, 618.70],
    [5.90, 5.40, 6.00, 1078.90], [6.30, 5.90, 6.60, 1109.30], [5.20, 4.70, 3.00, 848.20],
    [6.00, 5.50, 5.30, 1024.70], [4.70, 4.20, 2.10, 664.90], [5.70, 5.20, 4.40, 956.80]
  ];
  return { headers, rows, xIdx: [0, 1, 2], yIdx: 3, numericIdx: [0, 1, 2, 3],
           name: '软土复合固化剂配比试验', unit: 'kPa' };
}

window.$ = $; window.$$ = $$; window.State = State; window.toast = toast;
window.fmt = fmt; window.mean = mean; window.std = std; window.clamp = clamp;
window.shuffleIdx = shuffleIdx; window.download = download; window.makeDemoDataset = makeDemoDataset;
window.rnd = rnd; window.setSeed = setSeed;
window.downloadBinary = downloadBinary;
